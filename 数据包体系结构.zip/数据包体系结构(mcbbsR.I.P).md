- [原版模组体系结构](#原版模组体系结构)
- [数据包体系结构](#数据包体系结构)
  - [逻辑结构](#逻辑结构)
    - [函数/命令](#函数命令)
  - [数据结构](#数据结构)
    - [战利品表](#战利品表)
    - [物品修饰器](#物品修饰器)
    - [标签](#标签)
    - [谓词](#谓词)
    - [进度](#进度)
    - [配方](#配方)
  - [世界生成](#世界生成)
    - [结构](#结构)
    - [维度类型](#维度类型)
    - [维度](#维度)
    - [自定义世界生成](#自定义世界生成)
- [资源包体系结构](#资源包体系结构)
  - [着色器](#着色器)
  - [模型](#模型)
  - [纹理](#纹理)
  - [字体](#字体)
- [其他](#其他)
  - [视频教程](#视频教程)
  - [实例教程](#实例教程)
  - [有用的工具和参考](#有用的工具和参考)


`TODO：索引帖需要修改引用`
`需要查找失效链接`

## 原版模组体系结构

[Minecraft 原版模组入门教程 ](https://zhangshenxing.gitee.io/vanillamodtutorial/#数据包) ~~(坛内)~~

[数据包 - Minecraft Wiki](https://zh.minecraft.wiki/w/%E6%95%B0%E6%8D%AE%E5%8C%85)[（Bwiki镜像）](https://wiki.biligame.com/mc/数据包)  
[资源包 - Minecraft Wiki](https://zh.minecraft.wiki/w/%E8%B5%84%E6%BA%90%E5%8C%85)[（Bwiki镜像）](https://wiki.biligame.com/mc/资源包)  
[命令 - Minecraft Wiki](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4)[（Bwiki镜像）](https://wiki.biligame.com/mc/命令)

本文体系结构为上述教程的引用和补充。因此不再给出以上教程的有关链接。

读者清楚：数据包、资源包相关知识首先请查阅上述资料。



[~~数据包/资源包常见问题索引以及一点资源(JE~~](save/1233623.html)

## 数据包体系结构

### 逻辑结构

#### 函数/命令

- 古典思潮

  - [~~[CBL∫2b]指令方块进阶教程——模块（面向过程） §索引~~](save/460476.html)（索引内部链接已失效）
  - [[CBL]|秋一1.13函数命令系统：当命令脱离命令方块](save/691100.html)
  - [~~引言 · 命令进阶 (oschina.io)~~](https://mc-command.oschina.io/command-tutorial/output/)（疑似无法访问）
- 命令执行操作
  - [/execute](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/execute)
    - [【教程】[1.15] execute 命令入门教程 ](save/989501.html)
    - (不推荐) [[1.13+]新版execute命令详解](save/901364.html) 
    - (不推荐)[玩转1.13的新/execute](save/770738.html) 
    - [【CBL|SYL】【1.13】新版本execute嵌套的改变](save/770198.html)
  - 子命令：
    - 执行者 `as` 

    - 朝向 `rotated | rotated as | facing | facing entity`

    - 局部基准点 `anchored`

    - 维度 `in`

    - 执行位置 `at | positioned | positioned as`

    - 执行位置取整 `align`
      - [(二) 命令tp与相对，局部坐标与朝向锚]([save/1174656.html](https://www.bilibili.com/read/cv34840247)) 
    - [坐标 - Minecraft Wiki](https://zh.minecraft.wiki/w/%E5%9D%90%E6%A0%87)
      - 绝对坐标
      - 局部坐标 `^ ^ ^`
      - 相对坐标 `~ ~ ~`
    - 条件子命令 `if|unless`
      - [【教程】[1.15] execute 命令入门教程 ](save/989501.html)
    - [存储子命令`store`](#execute_store)

- 命令逻辑
  
  - 命令方块 (淘汰)
      [1.12 连锁命令方块(CCB)新机制研究](save/687963.html)
  - 数据包结构逻辑
      ~~[https://www.mcbbs.net/thread-1143275-1-1.html]~~

- 强制区块运行 [/forceload](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/forceload)
  - [(八) 区块与强制加载命令/forceload](https://www.bilibili.com/opus/937515275404705808)

- 函数运行 [/function](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/function)
  - 定时函数运行 [/schedule]()
    - 由/schedule执行的函数，是由服务器执行，执行坐标是世界重生点
    - [【1.15+】极简的定时器，利用schedule实现任意时刻的定时器](save/1022317.html)
- 数据操作
  - [NBT](https://zh.minecraft.wiki/w/NBT%E6%A0%BC%E5%BC%8F)(数据储存/修改) 
    - 古典教程 
      - [【CBL|SYL】NBT标签实战教程—索引贴(基本完工) ](save/78479.html)
      - [~~2.2 NBT及结构 · 命令进阶 (oschina.io)~~](https://mc-command.oschina.io/command-tutorial/output/common-format/nbt/nbt.html)（疑似无法访问）
    - （不太）现代教程 
      - [~~( X ) 我就不信不能用大白话讲清楚NBT~~](save/1190947.html) 
      - [教程/NBT命令标签](https://zh.minecraft.wiki/w/教程/NBT命令标签)
      - [(十一)NBT通俗演义（雾）](https://www.bilibili.com/opus/947507675726348296)
    - ~~物品NBT~~ [物品组件](https://zh.minecraft.wiki/w/%E7%89%A9%E5%93%81%E5%A0%86%E5%8F%A0%E7%BB%84%E4%BB%B6)

    - [方块实体NBT](https://zh.minecraft.wiki/w/%E6%96%B9%E5%9D%97%E5%AE%9E%E4%BD%93%E6%95%B0%E6%8D%AE%E6%A0%BC%E5%BC%8F)

    - NBT路径
      - [【CBL|SPG】[1.14] NBT 路径：从入门到胡了)](https://github.com/SPGoding/mcbbs-threads/blob/master/tutorials/nbt-path/markdown.md)

    - 返回值类型
      - [Minecraft：Java 版命令返回值列表 ](https://spgoding.com/command/2021/03/26/command-result-value.html) [(坛内(R.I.P))](save/808124.html)
    - [/data](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/data) 以下教程互为补充
      - [【教程】[1.15] 常见的数据操作方法：入门教程](save/993805.html)
      - [(十二) 数据运算三方法之一修改NBT/data](https://www.bilibili.com/read/cv36068052)
      - [~~data 命令中数据的筛选~~](save/1220434.html)

    - `/data storage`
      - ~~(https://www.mcbbs.net/thread-1143275-1-1.html)~~

    - <span id="execute_store">`/execute store`</span>
      - [【教程】[1.15] execute 命令入门教程 ](save/989501.html)

  - ~~原始JSON文本(数据输出)~~ [文本组件](https://zh.minecraft.wiki/w/%E6%96%87%E6%9C%AC%E7%BB%84%E4%BB%B6)
    - 例：
      - ​	{"text":"Hello"}
      - 1.14以后，转义不需要\\"直接'" "'
    - 工具：
      - [Minecraft Tool](https://minecraft.tools/en/tellraw.php)
      - [[1.14-1.16]JText Studio 聊天成书所见即所得|全新交互](https://www.mcbbs.net/thread-986663-1-1.html)
      - [[1.14+]JText Studio Minus轻量级JSON文本编辑器](https://www.mcbbs.net/thread-1103385-1-1.html)
    - 古典教程：
      - [【CB圣典计划】JSON圣典-最全面JSON教程](https://www.mcbbs.net/thread-431678-1-1.html)
      - [2.1 JSON文本 · 命令进阶 (oschina.io)](https://mc-command.oschina.io/command-tutorial/output/common-format/json/json.html)
      - [原始JSON文本格式 - Minecraft Wiki](https://zh.minecraft.wiki/w/%E6%96%87%E6%9C%AC%E7%BB%84%E4%BB%B6)
      - [教程/原始JSON文本 - Minecraft Wiki](https://zh.minecraft.wiki/w/Tutorial:%E6%96%87%E6%9C%AC%E7%BB%84%E4%BB%B6)
      - [教程/NBT与JSON - Minecraft Wiki](https://zh.minecraft.wiki/w/Tutorial:NBT%E4%B8%8EJSON)
      - [原始json文本中“子对象”的使用](save/1076989.html)
    - [纯文本与翻译文本](https://zh.minecraft.wiki/w/%E6%96%87%E6%9C%AC%E7%BB%84%E4%BB%B6#%E7%BA%AF%E6%96%87%E6%9C%AC)
    - [文本组件样式 "bold" | "italic" | "underlined" | "strikethrough" | "obfuscated" | "color"](https://zh.minecraft.wiki/w/%E6%96%87%E6%9C%AC%E7%BB%84%E4%BB%B6#%E6%96%87%E6%9C%AC%E7%BB%84%E4%BB%B6%E6%A0%B7%E5%BC%8F)
    - 字体颜色 "color"（见上） / [格式化代码](https://zh.minecraft.wiki/w/%E6%A0%BC%E5%BC%8F%E5%8C%96%E4%BB%A3%E7%A0%81)
      - [用彩色字给物品命名](teen/【1.14-1.16.1】用彩色字给物品命名%20_%20获取玩家头颅%20-%20Minecraft(我的世界)中文论坛%20-%20Powered%20by%20Discuz!.html)
    - [键位信息"keybind"](https://zh.minecraft.wiki/w/%E6%96%87%E6%9C%AC%E7%BB%84%E4%BB%B6#%E6%8C%89%E9%94%AE%E7%BB%91%E5%AE%9A)
    - [数据引用 "nbt"-"block"/"entity"/"storage"](https://zh.minecraft.wiki/w/%E6%96%87%E6%9C%AC%E7%BB%84%E4%BB%B6#NBT%E6%A0%87%E7%AD%BE%E5%80%BC)
    - [分数引用 "score"](https://zh.minecraft.wiki/w/%E6%96%87%E6%9C%AC%E7%BB%84%E4%BB%B6#%E8%AE%B0%E5%88%86%E6%9D%BF%E5%88%86%E6%95%B0)
    - [实体名称（选择器）"selector"](https://zh.minecraft.wiki/w/%E6%96%87%E6%9C%AC%E7%BB%84%E4%BB%B6#NBT%E6%A0%87%E7%AD%BE%E5%80%BC)
    - [字体"font"](https://zh.minecraft.wiki/w/%E6%96%87%E6%9C%AC%E7%BB%84%E4%BB%B6#%E5%AD%97%E4%BD%93)
      - [【1.13】地图制作技巧——字体艺术](save/835539.html)
      - [~~关于字体资源包强制使用等宽字符的问题~~](save/1275778.html)
    - 解析"interpret"
      - [【CBL|SPG】[1.15+] JSON 文本中的 interpret ](save/921501.html)
    - 分隔符 "separator"
    - 事件

      - 插入聊天框事件 "insertion"

      - [点击事件 "clickEvent"](https://zh.minecraft.wiki/w/%E6%96%87%E6%9C%AC%E7%BB%84%E4%BB%B6#%E7%82%B9%E5%87%BB%E4%BA%8B%E4%BB%B6)
        - |     **action**      |     描述     |     **value**      |       可用性       |
          | :-----------------: | :----------: | :----------------: | :----------------: |
          |     "open_url"      |   打开网页   | http://example.com |     聊天、成书     |
          |    "run_command"    |   发送命令   |       String       | 聊天、成书、告示牌 |
          |    "change_page"    |   切换页码   |        Int         |        成书        |
          |  "suggest_command"  |   输入命令   |       String       |        聊天        |
          | "copy_to_clipboard" | 复制至剪贴板 |       String       |     聊天、成书     |

      - [悬浮事件 "hoverEvent"](https://zh.minecraft.wiki/w/%E6%96%87%E6%9C%AC%E7%BB%84%E4%BB%B6#%E6%82%AC%E5%81%9C%E4%BA%8B%E4%BB%B6)
        - |  **action**   |   描述   |            **value**             |               content               |
          | :-----------: | :------: | :------------------------------: | :---------------------------------: |
          |  "show_text"  | 显示文字 |             JSON文本             |              JSON文本               |
          |  "show_item"  | 显示物品 |     '{id:"",Count:,tag:{}}'      |    {"id":"","count":"","tag":""}    |
          | "show_entity" | 显示实体 | '{type:"",id:"",name:"",tag:{}}' | {"name":JSON文本,"type":"","id":""} |

    - [聊天栏](https://zh.minecraft.wiki/w/%E8%81%8A%E5%A4%A9)

      - 私密信息 [/tell](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/tell) [/msg](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/msg) [/w](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/w)

        - tell <*玩家|目标选择器*> <*信息…*>

      - 所在队伍信息 [/teammsg](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/teammsg) [/tm](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/tm)

        - teammsg <*信息*>

      - 所有玩家信息 [/say](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/say)

        - say <*信息*>

      - JSON文本信息 [/tellraw](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/tellraw)
        - [~~【CBL|SYL】Json/tellraw教程索引贴~~](save/205332.html)

      - 显示自己的信息 [/me](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/me)
        - me <*动作…*>

    - 标题 [/title](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/title)
      - [M1.8：指令方块新的/title教程](save/276456.html)

      - 标题 `title`

      - 副标题 `subtitle`

      - 活动栏 `actionbar`
        - [~~【原版模组】【前置】1.16.X 玩家栏~~](save/1156574.html)
        - [~~[1.16+]状态栏数值化条形显示数据包 - 让你的血量数字化~~](save/1209691.html)
        - [马大哈——小猫咪被我看得一清二楚！！！](save/1047712.html)`（非物质文化遗产）`

    - Boss栏 [/bossbar](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/bossbar)
      - [1.13Bossbar指令全用法](save/781746.html)
      - [~~玩家分离bossbar，每个玩家可以单独编辑了~~](save/1179992.html)
      - [[1.14]如何把bossbar和scoreboard联系在一起](save/864877.html)
        - /execute store result bossbar <boss栏id> value run scoreboard players get <实体> <计分板id>
      - [[18w05a]新命令/bossbar 自定义boss血条实现指向效果 [已稳定]](save/778336.html)

    - 分数栏 [/scoreboard](#scoreboard) objectives setdisplay <*槽位*> [*记分板ID*]
      - 侧边栏 `sidebar`
      - 人物名称 `below`
      - 玩家名单 `list`

    - 成书(值会被解析) 
      - {pages:["first page","second page",'["",JSON文本]']}

    - 书与笔(值不会被解析，为String)
      - {pages:["first page","second page",'["",JSON文本]']}
      - [~~命令书~~](save/1190418.html)

    - 告示牌(值会被解析)
      - {Text1:"第一行文本",Text2:'{"text":"第二行文本"},Text3:"",Text4:""}
      - [【水教程】[1.14+] 告示牌黑科技 / 用战利品表实现 ](save/1101560.html)

    - 实体名字 `CustomName`
      - {CustomName:'{"text":"僵尸"}'}

    - 物品命名/注释~~display - Name / Lore~~ `"minecraft:item_name"/"minecraft:custom_name"/"minecraft:lore"`
      - ~~{display:{Name:'{"text":"钻石剑","color":"dark_red","italic":false}',Lore:"diamond_sword"}}~~

  - 记分板(数据运算)<span id="scoreboard"></span>
    - [/scoreboard](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/scoreboard)
      - [[1.8+]记分板完整教程应用](save/274969.html)
      - [(五) 记分板与/scoreboard](https://www.bilibili.com/read/cv34854289)
    - [/trigger](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/trigger)

- 方块操作

  - [结构方块](https://zh.minecraft.wiki/w/%E7%BB%93%E6%9E%84%E6%96%B9%E5%9D%97) 
    - [【1.10新特性】结构方块从入门到放弃](save/585095.html)
    - [[1.14+] 组合结构的随机生成及修饰](save/899638.html)
    - [如何使用结构方块](save/652937.html)
    - [【新手向】建筑党也能愉快享用结构方块-图文并茂教会你使用结构方块](save/801350.html)
  - 加载结构 
      ```mcfunction
      execute at @p run setblock ~ ~ ~ structure_block{name:"woodland_mansion/1x1_a3",mode:"LOAD",powered:0}
      execute at @p run setblock ~ ~-1 ~ redstone_block 
      ```

  - 放置方块 [/setblock](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/setblock) 
    - [(十)简单又新手（雾）的方块指令/setblock](https://www.bilibili.com/opus/942368755971784728)
  - 复制区域 [/clone](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/clone) 
    - [(十五)复制一片区域：复制命令/clone](https://www.bilibili.com/read/cv38861264/)
  - 填充区域 [/fill](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/fill) 
    - [(十四) 最接近神的一次：填充命令/fill](https://www.bilibili.com/read/cv37972439/)



- 物品操作

  - 清除物品 [/clear](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/clear)

  - 给予物品 [/give](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/give)

  - 置入战利品表 [/loot](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/loot)
    - [rua影盒](https://zhangshenxing.github.io/VanillaModTutorial/#%E4%BF%AE%E6%94%B9%E7%8E%A9%E5%AE%B6%E8%83%8C%E5%8C%85) 
    - [[1.14]如何使用loot replace](save/874755.html)

  - 附魔物品 [/enchant](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/enchant)

  - 修改物品栈
    - 1.17 [/item](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/item)
    - 1.16 [/replaceitem](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/replaceitem) 

- 实体操作

  - [目标选择器](https://zh.minecraft.wiki/w/%E7%9B%AE%E6%A0%87%E9%80%89%E6%8B%A9%E5%99%A8)
    - [(一) 指令，选择器，与命令方块](https://www.bilibili.com/read/cv34839498)
    - [(六) /tag指令，与进阶选择器参数](https://www.bilibili.com/opus/937149730721366018)
    - [[1.14.4] 追根溯「源」——实体选择器 ](save/891687.html)

  - 实体生成 [/summon](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/summon)
    - [ [TCP|Jokey]关于summon时隐藏的实体和隐形矿车那些事](save/926441.html)

  - 实体清除 [/kill](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/kill)

  - 粒子生成 [/particle](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/particle)
    - [particle指令（粒子指令）的大小、颜色、格式变化以及扩展](save/625963.html)
    - [【原版】particle指令参数对颗粒行为的影响](save/852420.html)

  - 传送
    - 随机传送 [/spreadplayers](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/spreadplayers)
      - `spreadplayers <*x*> <*z*> <*分散间距*> <*最大范围*> [*under* *最大高度*] <*考虑队伍*> <*传送目标…*>`

    - 传送 [/teleport](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/teleport) [/tp](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/tp)
      - [teleport 相对坐标 本地坐标 省略选择器](save/1114273.html)

  - 状态效果 [/effect](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/effect)
    - [[1.13+]状态效果——effect命令详细介绍 - 游戏技巧 - Minecraft(我的世界)中文论坛 - (mcbbs.net)](save/1068146.html)
    - [~~请问effect 里面负级指令怎么调~~](save/1201497.html)

  - 属性 [/attribute](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/attribute)
    - [ [20w17a]attribute指令详解](save/1026841.html)
    - [（十三）属性管理，/attribute](https://www.bilibili.com/opus/957257796958552103)

  - 队伍 [/team](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/team)
    - [(四) 有关队伍命令/team的……差不多一切](https://www.bilibili.com/opus/936409278375264260)

  - 标签 [/tag](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/tag)
    - [(六) /tag指令，与进阶选择器参数](https://www.bilibili.com/opus/937149730721366018)

  - 其他
    
    - 经验 /experience /xp 
    - 旁观实体 [/spectate](https://www.mcbbs.net/forum.php?mod=viewthread&tid=1182418&page=1#pid21460488)
      
- 音效

  - 播放 /playsound

    - playsound <*声音 entity.pig.ambient*> <*来源*> <*玩家名|目标选择器*> [<*方位x y z*>] [<*音量*>] [<*音调0.0~2.0*>] [<*最小音量0.0~1.0*>]
      来源：master,music,record,weather,block,hostile,neutral,player,ambient,voice

  - 停止 /stopsound

    - stopsound <*玩家名|目标选择器*> [*来源*] [*声音*]
          来源：可以*

- 世界操作

  - [游戏模式](https://www.mcbbs.net/forum.php?mod=viewthread&tid=1176251&page=1#pid21292376)
    
    - 世界模式 [/defaultgamemode](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/defaultgamemode)
    - 玩家模式 [/gamemode](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/gamemode)

  - 游戏难度 [/difficulty](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/difficulty)

  - 游戏规则 [/gamerule](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/gamerule) 

  - 结构位置 [/locate](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/locate) 

  - 生物群系位置 [/locatebiome](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/locatebiome)

  - 世界种子 [/seed](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/seed)

  - [出生点](https://www.mcbbs.net/forum.php?mod=viewthread&tid=1182418&page=1#pid21460488) 
    
    - 世界出生点 [/setworldspawn](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/setworldspawn)
    - 玩家出生点 [/spawnpoint](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/spawnpoint)

  - 世界时间 [/time](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/time)

  - 主世界天气 [/weather](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/weather)

  - 世界边界 [/worldborder](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/worldborder)

- 外部命令
    
  - | 命令      | 描述                                   |
    | --------- | -------------------------------------- |
    | [/datapack](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/datapack) | 控制加载的数据包。                     |
    | [/debug](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/debug)    | 开始或结束调试会话。                   |
    | [/reload](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/reload)   | 从硬盘中重新加载战利品表、进度和函数。 |

- 服务器操作
    
  - | 命令            | 描述                           | 语法                                                         |
    | --------------- | ------------------------------ | ------------------------------------------------------------ |
    | /ban            | 将玩家加入封禁列表。           | ban <*玩家名\|UUID*> [<*理由…*>]                             |
    | /ban-ip         | 将IP地址加入封禁列表。         | ban-ip <*玩家名\|IP地址*> [<*理由…*>]                        |
    | /banlist        | 显示封禁列表。                 | banlist ips <br />banlist players                            |
    | /deop           | 撤销玩家的管理员权限。         | deop <*玩家*>                                                |
    | /kick           | 将玩家踢出服务器。             | kick <*玩家名\|目标选择器*> [*原因*]                         |
    | /list           | 列出服务器中的玩家。           | list [*uuids*]                                               |
    | /op             | 授予玩家管理员权限。           | op <*玩家名\|目标选择器）*>                                  |
    | /pardon         | 从封禁列表中移除玩家封禁项目。 | pardon <*玩家名*>                                            |
    | /pardon-ip      | 从封禁列表中移除IP封禁项目。   | pardon-ip <*IP地址*>                                         |
    | /publish        | 向局域网开放单人游戏世界。     | publish [*端口0~65536*]                                      |
    | /save-all       | 保存服务器世界状态到硬盘。     | save-all [flush]<br />flush:服务器会立即保存所有的区块数据   |
    | /save-off       | 关闭服务器自动保存。           | save-off                                                     |
    | /save-on        | 开启服务器自动保存。           | save-on                                                      |
    | /setidletimeout | 设置无操作玩家被踢出的延时。   | setidletimeout <*空闲分钟数0~2147483647*>                    |
    | /stop           | 关闭服务器。                   | stop                                                         |
    | /whitelist      | 管理服务器白名单。             | whitelist add <*玩家*><br />whitelist remove <*玩家*><br />whitelist <list\|off\|on\|reload><br /> |


### 数据结构
  - 工具（通用）：
    - [[1.15-1.17] Data Pack Generators for Minecraft —— 数据包 JSON 文件生成器！](save/897487)
    - https://misode.github.io/

#### 战利品表
  - [战利品表 - Minecraft Wiki](https://zh.minecraft.wiki/w/战利品表)
  - [【CBL|SPG】[1.16] 战利品表 —— 数据包的组成文件之一](save/831542.html)
  - 远古教程：[[CBL∫2b]Loottable - 创造一个看脸讲玄的世界 总索引](https://www.mcbbs.net/forum.php?mod=viewthread&tid=619468)

#### 物品修饰器
  - [物品修饰器 - Minecraft Wiki](https://zh.minecraft.wiki/w/物品修饰器)
  - [~~物品修饰器的简单介绍~~](save/1187947.html)
  - [Minecraft 原版模组入门教程-物品修饰器](https://zhangshenxing.gitee.io/vanillamodtutorial/#物品修饰器)

#### 标签
  - [标签 - Minecraft Wiki](https://zh.minecraft.wiki/w/标签)
  - [【UIN】数据包——标签分类](save/775667.html)
  - [Minecraft 原版模组入门教程-标签](https://zhangshenxing.gitee.io/vanillamodtutorial/#标签)
  - [哪些命令中的哪些部分可以使用标签 ](save/963143.html) 
  - [数据包标签的使用问题](save/989540.html)

#### 谓词
  - [谓词 - Minecraft Wiki](https://zh.minecraft.wiki/w/谓词)
  - [【CBL|SPG】[1.16] ㄆㄧㄉㄧㄎㄞㄊㄜ —— 数据包的组成文件之一 ](save/914817.html)

#### 进度
- 工具
  - VSCode插件：[Minecarft Json Viewer——基于vscode的数据包进度仿真插件](https://www.mcbbs.net/thread-1109032-1-1.html)。
- [进度 - Minecraft Wiki](https://zh.minecraft.wiki/w/进度)
- [【烯方的那一套理论】猴子都能学会的自定义advancement！](save/685310.html)
- [【教程】[1.14] 自定义进度：从入门到弃坑](save/892563.html)
- [[20w20a]来看看最新的进度触发器](save/1045395.html)
- [[1.15] 新的进度触发器](save/936174.html)

#### 配方
- 工具：
  - [~~mc-recipe-editor——数据包配方编辑器~~](save/1222437.html)
- [配方 - Minecraft Wiki](https://zh.minecraft.wiki/w/配方)
- [Minecraft 原版模组入门教程-配方](https://zhangshenxing.gitee.io/vanillamodtutorial/#配方)

### 世界生成

#### 结构

- 工具：
  - VSCode插件：NBT Viewer
- [Minecraft 原版模组入门教程 -结构](https://zhangshenxing.gitee.io/vanillamodtutorial/#结构)

#### 维度类型

#### 维度
[维度 - Minecraft Wiki](https://zh.minecraft.wiki/w/维度数据格式)

#### 自定义世界生成
- [自定义世界生成 - Minecraft Wiki](https://zh.minecraft.wiki/w/自定义世界生成)
- 工具：
      [[1.16] Multi Noise Visualizer —— 实时预览多重噪声生物群系源的生成情况 ](https://www.mcbbs.net/forum.php?mod=viewthread&tid=1080570&highlight=)
      ​	[worldgen——在线自定义世界生成器](https://www.mcbbs.net/forum.php?mod=viewthread&tid=1129292&highlight=)
      https://misode.github.io/

- **生物群系**

- **雕刻**

- **地物**

- **结构特征**
  - [minecraft1.20版本自定义结构生成教程](https://www.bilibili.com/opus/987615832663130118)

- **地表生成器**

- **噪声设置**

- **方块处理器**

- **拼图**
    - [[VCS] 拼图方块与拼图池教程（1.16.2+）](https://www.mcbbs.net/thread-1093331-1-1.html)
    - [[1.17.1\] 拼图池运用与结构生成](https://www.mcbbs.net/thread-1273515-1-1.html)
    - [[转载\][1.17+]如何用好拼图方块、拼图池、模板池](https://www.mcbbs.net/forum.php?mod=viewthread&tid=1231185)



## 资源包体系结构

### 着色器
  - [着色器 - Minecraft Wiki](https://zh.minecraft.wiki/w/着色器)
  - [原版着色器指导](save/916150.html) [<u>(网站)</u>](https://spgoding.com/translation/2021/03/12/guite-to-vanilla-shader.html)
  - [几个原版着色器示例](save/917679.html)
  - [原版资源包着色器与动画研究心得](save/863730.html)
  - [不会有人看的深度缓冲着色器分析&用途](save/1056196.html)
  - [~~核心着色器浅析~~](save/1181123.html)

### 模型
  - [模型 - Minecraft Wiki](https://zh.minecraft.wiki/w/模型)
  - 方块状态
  - 方块模型
  - 物品模型
    - override

### 纹理
  - [纹理 - Minecraft Wiki](https://zh.minecraft.wiki/w/纹理)
  - 纹理
  - 皮肤

### 字体
  - [字体 - Minecraft Wiki](https://zh.minecraft.wiki/w/字体)
  - [自定义字体 - Minecraft Wiki](https://zh.minecraft.wiki/w/自定义字体)

## 其他

### 视频教程
### 实例教程
### 有用的工具和参考