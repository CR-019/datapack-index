<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="force-rendering" content="webkit">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>提示信息 -  Minecraft(我的世界)中文论坛 - </title>
<meta name="force-rendering" content="webkit">
<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta itemprop="image" content="https://www.mcbbs.net/template/mcbbs/image/logo_sc.png" />
<script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?affdf09dddabcdf2d681acefa474b973";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
</script>
<style>
.fastlg {
display:none;
}
</style>
<meta name="keywords" content="" />
<meta name="description" content=",Minecraft(我的世界)中文论坛" />
<meta name="generator" content="Discuz! X3.5" />
<meta name="author" content="我的世界中文论坛" />
<meta name="copyright" content="2001-2013 Comsenz Inc." />
<meta name="MSSmartTagsPreventParsing" content="True" />
<meta http-equiv="MSThemeCompatible" content="Yes" />
<base href="https://www.mcbbs.net/" />
<link rel="manifest" href="manifest.json"/><link rel="stylesheet" type="text/css" href="data/cache/style_30_common.css?cM7" /><link rel="stylesheet" type="text/css" href="data/cache/style_30_home_task.css?cM7" /><link rel="stylesheet" id="css_extstyle" type="text/css" href="./template/mcbbs/style/nether/style.css" /><script type="text/javascript">var STYLEID = '30', STATICURL = 'static/', IMGDIR = 'template/mcbbs/image', VERHASH = 'cM7', charset = 'UTF-8', discuz_uid = '0', cookiepre = 'ZxYQ_8cea_', cookiedomain = '.mcbbs.net', cookiepath = '/', showusercard = '1', attackevasive = '0', disallowfloat = 'newthread|tradeorder|nav|usergroups', creditnotice = '1|人气|点,2|金粒|粒,3|金锭|块,4|宝石|颗,5|下界之星|枚,6|贡献|份,7|爱心|心,8|钻石|颗', defaultstyle = './template/mcbbs/style/nether', REPORTURL = 'aHR0cHM6Ly93d3cubWNiYnMubmV0L2hvbWUucGhwP21vZD10YXNrJmRvPWFwcGx5JmlkPTEw', SITEURL = 'https://www.mcbbs.net/', JSPATH = 'data/cache/', CSSPATH = 'data/cache/style_', DYNAMICURL = '';</script>
<script src="data/cache/common.js?cM7" type="text/javascript"></script>
<meta name="application-name" content="Minecraft(我的世界)中文论坛" />
<meta name="msapplication-tooltip" content="Minecraft(我的世界)中文论坛" />
<meta name="msapplication-task" content="name=首页;action-uri=https://www.mcbbs.net/portal.php;icon-uri=https://www.mcbbs.net/template/mcbbs/image/portal.ico" /><meta name="msapplication-task" content="name=论坛;action-uri=https://www.mcbbs.net/forum.php;icon-uri=https://www.mcbbs.net/template/mcbbs/image/bbs.ico" />
<meta name="msapplication-task" content="name=小组;action-uri=https://www.mcbbs.net/group.php;icon-uri=https://www.mcbbs.net/template/mcbbs/image/group.ico" /><script src="data/cache/home.js?cM7" type="text/javascript"></script>
            <!--<link rel="stylesheet" href="template/mcbbs/common/xw.css"/>-->
<script src="template/mcbbs/common/jquery.min.js" type="text/javascript"></script>
<script type="text/javascript">
var jq = jQuery.noConflict();
</script>

</head>

<body id="nv_home" class="pg_task" onkeydown="if(event.keyCode==27) return false;">
    <div id="body_fixed_bg"></div>
<div id="append_parent"></div><div id="ajaxwaitid"></div>
<div id="toptb" class="cl">
<div class="new_wp wp">
<div class="z light">
                                        <a href="https://minecraft.net" title="我的世界（国际版）官方网站" target="_blank" >我的世界官网</a>                                        <a href="https://minecraft.fandom.com/zh/wiki/Minecraft_Wiki" title="Minecraft Wiki，设立于Fandom" target="_blank" >中文百科</a>                                        <a href="forum-server-1.html" target="_blank"  style="font-weight: bold;">Java版服务器列表</a>                                        <a href="forum-peserver-1.html" target="_blank"  style="font-weight: bold;">基岩版服务器列表</a>                                                                                                                                                                                                                                                                                                                                                                        </div>
<div class="y">
                    <!--<div class="y_search">
                        <form id="scbar_form" method="post" autocomplete="off" onsubmit="searchFocus($('scbar_txt'))" action="search.php?searchsubmit=yes" target="_blank">
                            <input type="hidden" name="mod" id="scbar_mod" value="search" />
                            <input type="hidden" name="formhash" value="5b05441d" />
                            <input type="hidden" name="srchtype" value="title" />
                            <input type="hidden" name="srhfid" value="0" />
                            <input type="hidden" name="srhlocality" value="home::task" />
                            &lt;!&ndash;&ndash;&gt;
                                <div class="y_search_btn"><button type="submit" name="searchsubmit" id="scbar_btn" sc="1" class="pn pnc" value="true"><strong class="xi2">搜索</strong></button></div>
                                <div class="y_search_inp"><input type="text" name="srchtxt" id="scbar_txt" value="" placeholder="请输入搜索内容" autocomplete="off" x-webkit-speech speech  title=""/></div>



</form>
                    </div>--><div class="cl y_search">
<form id="scbar_form" method="post" autocomplete="off" onsubmit="searchFocus($('scbar_txt'))" action="search.php?searchsubmit=yes" target="_blank">
<input type="hidden" name="mod" id="scbar_mod" value="search" />
<input type="hidden" name="formhash" value="5b05441d" />
<input type="hidden" name="srchtype" value="title" />
<input type="hidden" name="srhfid" value="0" />
<input type="hidden" name="srhlocality" value="home::task" />
<table cellspacing="0" cellpadding="0">
<tr>
<!--<td class="scbar_icon_td"></td>-->
<td class="y_search_btn"><button type="submit" name="searchsubmit" id="scbar_btn" sc="1" class="pn pnc" value="true"><strong class="xi2">搜索</strong></button></td>
<td class="y_search_inp"><input type="text" name="srchtxt" id="scbar_txt" value="请输入搜索内容" autocomplete="off" x-webkit-speech speech /></td>
<td class="scbar_type_td"><a href="javascript:;" id="scbar_type" class="xg1" onclick="showMenu(this.id)" hidefocus="true" style="height: 26px">搜索</a></td>

<!--	<td class="scbar_hot_td">
<div id="scbar_hot">
&lt;!&ndash;&ndash;&gt;
</div>
</td>-->
</tr>
</table>
</form>
</div>
<ul id="scbar_type_menu" class="p_pop" style="display: none;"><li><a href="javascript:;" rel="user">用户</a></li></ul>
<script type="text/javascript">
initSearchmenu('scbar', '');
</script>
<div class="user_menu"> 
<!--<a id="switchblind" href="javascript:;" onclick="toggleBlind(this)" title="开启辅助访问" class="switchblind">开启辅助访问</a>-->
</div>
<!--
<div id="user_login_menu" style="display: none">
<script src="data/cache/logging.js?cM7" type="text/javascript"></script>
<form method="post" autocomplete="off" id="lsform" action="member.php?mod=logging&amp;action=login&amp;loginsubmit=yes&amp;infloat=yes&amp;lssubmit=yes" onsubmit="return lsSubmit();">
<ul class="user_info_menu_info">
<li><label for="ls_username">!account!</label><input type="text" name="username" id="ls_username" class="px vm xg1"  value="用户名/Email" onfocus="if(this.value == '用户名/Email'){this.value = '';this.className = 'px vm';}" onblur="if(this.value == ''){this.value = '用户名/Email';this.className = 'px vm xg1';}" tabindex="901" /></li>
<li><label for="ls_password">!password!</label><input type="password" name="password" id="ls_password" class="px vm" autocomplete="off" tabindex="902" /></li>
<li><label for="ls_cookietime"><input type="checkbox" name="cookietime" id="ls_cookietime" class="pc" value="2592000" tabindex="903" />自动登录</label></li>
<li><button type="submit" tabindex="914" style="width:220px;height:45px;cursor:pointer;border:0;background:url('template/mcbbs/image/dl.png') 0 0 no-repeat;display: inherit;"></button></li>
</ul>
</form>
</div>
-->
<div class="avt y light" id="user_login" onmouseover="showMenu({'ctrlid':this.id})">
<a href="member.php?mod=register">注册</a>
<a href="member.php?mod=logging&amp;action=login">登录</a>
<div class="avt y hd_t_a" style="z-index:0">
<a href="member.php?mod=logging&amp;action=login"><img src="template/mcbbs/image/special_photo_bg.png"></a>
</div>
</div>
</div>
</div>
</div>
        
<div id="user_info_menu" style="display: none">
<ul class="user_info_menu_info">
<li><p class="username"></p>
</li>
<li><a class="rank" href="home.php?mod=spacecp&amp;ac=usergroup&amp;gid=7">游客</a></li>
<li><a id="rank" href="home.php?mod=spacecp&amp;ac=usergroup&amp;gid=7" target="_blank"></a>
</li>
<li><span class="autowidth pbg2" ><span class="pbr2" style="width:%;"></span></span></li>
<li><a class="extcredits" title="金粒" href="home.php?mod=spacecp&amp;ac=credit"><em class="gold_nugget"></em>  </a> <a class="extcredits" title="绿宝石" href="home.php?mod=spacecp&amp;ac=credit"><em class="emerald"></em>  </a></li>

</ul>
<ul class="user_info_menu_btn">
<li><a href="home.php?mod=spacecp" target="_blank">账号设置</a></li>
<li><a href="forum.php?mod=guide&amp;view=my" target="_blank">我的帖子</a></li>
<li><a href="home.php?mod=space&amp;do=favorite&amp;view=me" target="_blank">我的收藏</a></li>

<li><a href="member.php?mod=logging&amp;action=logout&amp;formhash=5b05441d" onclick="showDialog('你确定要退出登录吗？', 'confirm', '退出登录', function(){
top.window.location.href = 'member.php?mod=logging&action=logout&formhash=5b05441d';
}, 1, null, '', '', '', '', 0);return false;">退出登录</a></li>

</ul>
</div>
<!--消息通知--> 
<div id="qmenu_menu" class="p_pop blk" style="display: none;">
<div class="ptm pbw hm">
请 <a href="javascript:;" class="xi2" onclick="lsSubmit()"><strong>登录</strong></a> 后使用快捷导航<br />没有帐号？<a href="member.php?mod=register" class="xi2 xw1">注册(register)</a>
</div>
<div id="fjump_menu" class="btda"></div></div>    <!--整个主体div-->
    <div class="mc_map_wp">
<!--头部公用 用户状态信息-->
        <div class="new_wp" style="padding: 28px 0 26px 0;">
<div class="hdc cl"><h2 style="padding:0;float: left;"><a href="portal.php" title="Minecraft(我的世界)中文论坛"><img src="template/mcbbs/image/logo_sc.png" alt="Minecraft(我的世界)中文论坛" border="0" /></a></h2><script src="data/cache/logging.js?cM7" type="text/javascript"></script>
<form method="post" autocomplete="off" id="lsform" action="member.php?mod=logging&amp;action=login&amp;loginsubmit=yes&amp;infloat=yes&amp;lssubmit=yes" onsubmit="return lsSubmit();">
<div class="fastlg cl">
<span id="return_ls" style="display:none"></span>
<div class="y pns">
<table cellspacing="0" cellpadding="0">
<tr>
<td><label for="ls_username">帐号</label></td>
<td><input type="text" name="username" id="ls_username" class="px vm xg1"  value="用户名/Email" onfocus="if(this.value == '用户名/Email'){this.value = '';this.className = 'px vm';}" onblur="if(this.value == ''){this.value = '用户名/Email';this.className = 'px vm xg1';}" tabindex="901" /></td>
<td class="fastlg_l"><label for="ls_cookietime"><input type="checkbox" name="cookietime" id="ls_cookietime" class="pc" value="2592000" tabindex="903" />自动登录</label></td>
<td>&nbsp;<a href="member.php?mod=logging&amp;action=login&amp;viewlostpw=1">找回密码</a></td>
</tr>
<tr>
<td><label for="ls_password">密码</label></td>
<td><input type="password" name="password" id="ls_password" class="px vm" autocomplete="off" tabindex="902" /></td>
<td class="fastlg_l"><button type="submit" class="pn vm" tabindex="904" style="width: 75px;"><em>登录</em></button></td>
<td>&nbsp;<a href="member.php?mod=register" class="xi2 xw1">注册(register)</a></td>
</tr>
</table>
<input type="hidden" name="quickforward" value="yes" />
<input type="hidden" name="handlekey" value="ls" />
</div>
</div>
</form>

<div id="po0hh8" class="y">
<script>(function(i){var l="2.73";if(i.support==undefined){i.support={opacity:!(i.browser.msie)}}function a(q){if(i.fn.cycle.debug){f(q)}}function f(){if(window.console&&window.console.log){window.console.log("[cycle] "+Array.prototype.join.call(arguments," "))}}i.fn.cycle=function(r,q){var s={s:this.selector,c:this.context};if(this.length===0&&r!="stop"){if(!i.isReady&&s.s){f("DOM not ready, queuing slideshow");i(function(){i(s.s,s.c).cycle(r,q)});return this}f("terminating; zero elements found by selector"+(i.isReady?"":" (DOM not ready)"));return this}return this.each(function(){var w=m(this,r,q);if(w===false){return}if(this.cycleTimeout){clearTimeout(this.cycleTimeout)}this.cycleTimeout=this.cyclePause=0;var x=i(this);var y=w.slideExpr?i(w.slideExpr,this):x.children();var u=y.get();if(u.length<2){f("terminating; too few slides: "+u.length);return}var t=k(x,y,u,w,s);if(t===false){return}var v=t.continuous?10:h(t.currSlide,t.nextSlide,t,!t.rev);if(v){v+=(t.delay||0);if(v<10){v=10}a("first timeout: "+v);this.cycleTimeout=setTimeout(function(){e(u,t,0,!t.rev)},v)}})};function m(q,t,r){if(q.cycleStop==undefined){q.cycleStop=0}if(t===undefined||t===null){t={}}if(t.constructor==String){switch(t){case"stop":q.cycleStop++;if(q.cycleTimeout){clearTimeout(q.cycleTimeout)}q.cycleTimeout=0;i(q).removeData("cycle.opts");return false;case"pause":q.cyclePause=1;return false;case"resume":q.cyclePause=0;if(r===true){t=i(q).data("cycle.opts");if(!t){f("options not found, can not resume");return false}if(q.cycleTimeout){clearTimeout(q.cycleTimeout);q.cycleTimeout=0}e(t.elements,t,1,1)}return false;case"prev":case"next":var u=i(q).data("cycle.opts");if(!u){f('options not found, "prev/next" ignored');return false}i.fn.cycle[t](u);return false;default:t={fx:t}}return t}else{if(t.constructor==Number){var s=t;t=i(q).data("cycle.opts");if(!t){f("options not found, can not advance slide");return false}if(s<0||s>=t.elements.length){f("invalid slide index: "+s);return false}t.nextSlide=s;if(q.cycleTimeout){clearTimeout(q.cycleTimeout);q.cycleTimeout=0}if(typeof r=="string"){t.oneTimeFx=r}e(t.elements,t,1,s>=t.currSlide);return false}}return t}function b(q,r){if(!i.support.opacity&&r.cleartype&&q.style.filter){try{q.style.removeAttribute("filter")}catch(s){}}}function k(y,J,u,t,E){var C=i.extend({},i.fn.cycle.defaults,t||{},i.metadata?y.metadata():i.meta?y.data():{});if(C.autostop){C.countdown=C.autostopCount||u.length}var r=y[0];y.data("cycle.opts",C);C.$cont=y;C.stopCount=r.cycleStop;C.elements=u;C.before=C.before?[C.before]:[];C.after=C.after?[C.after]:[];C.after.unshift(function(){C.busy=0});if(!i.support.opacity&&C.cleartype){C.after.push(function(){b(this,C)})}if(C.continuous){C.after.push(function(){e(u,C,0,!C.rev)})}n(C);if(!i.support.opacity&&C.cleartype&&!C.cleartypeNoBg){g(J)}if(y.css("position")=="static"){y.css("position","relative")}if(C.width){y.width(C.width)}if(C.height&&C.height!="auto"){y.height(C.height)}if(C.startingSlide){C.startingSlide=parseInt(C.startingSlide)}if(C.random){C.randomMap=[];for(var H=0;H<u.length;H++){C.randomMap.push(H)}C.randomMap.sort(function(L,w){return Math.random()-0.5});C.randomIndex=0;C.startingSlide=C.randomMap[0]}else{if(C.startingSlide>=u.length){C.startingSlide=0}}C.currSlide=C.startingSlide=C.startingSlide||0;var x=C.startingSlide;J.css({position:"absolute",top:0,left:0}).hide().each(function(w){var L=x?w>=x?u.length-(w-x):x-w:u.length-w;i(this).css("z-index",L)});i(u[x]).css("opacity",1).show();b(u[x],C);if(C.fit&&C.width){J.width(C.width)}if(C.fit&&C.height&&C.height!="auto"){J.height(C.height)}var D=C.containerResize&&!y.innerHeight();if(D){var v=0,B=0;for(var F=0;F<u.length;F++){var q=i(u[F]),K=q[0],A=q.outerWidth(),I=q.outerHeight();if(!A){A=K.offsetWidth}if(!I){I=K.offsetHeight}v=A>v?A:v;B=I>B?I:B}if(v>0&&B>0){y.css({width:v+"px",height:B+"px"})}}if(C.pause){y.hover(function(){this.cyclePause++},function(){this.cyclePause--})}if(c(C)===false){return false}var s=false;t.requeueAttempts=t.requeueAttempts||0;J.each(function(){var N=i(this);this.cycleH=(C.fit&&C.height)?C.height:N.height();this.cycleW=(C.fit&&C.width)?C.width:N.width();if(N.is("img")){var L=(i.browser.msie&&this.cycleW==28&&this.cycleH==30&&!this.complete);var O=(i.browser.mozilla&&this.cycleW==34&&this.cycleH==19&&!this.complete);var M=(i.browser.opera&&((this.cycleW==42&&this.cycleH==19)||(this.cycleW==37&&this.cycleH==17))&&!this.complete);var w=(this.cycleH==0&&this.cycleW==0&&!this.complete);if(L||O||M||w){if(E.s&&C.requeueOnImageNotLoaded&&++t.requeueAttempts<100){f(t.requeueAttempts," - img slide not loaded, requeuing slideshow: ",this.src,this.cycleW,this.cycleH);setTimeout(function(){i(E.s,E.c).cycle(t)},C.requeueTimeout);s=true;return false}else{f("could not determine size of image: "+this.src,this.cycleW,this.cycleH)}}}return true});if(s){return false}C.cssBefore=C.cssBefore||{};C.animIn=C.animIn||{};C.animOut=C.animOut||{};J.not(":eq("+x+")").css(C.cssBefore);if(C.cssFirst){i(J[x]).css(C.cssFirst)}if(C.timeout){C.timeout=parseInt(C.timeout);if(C.speed.constructor==String){C.speed=i.fx.speeds[C.speed]||parseInt(C.speed)}if(!C.sync){C.speed=C.speed/2}while((C.timeout-C.speed)<250){C.timeout+=C.speed}}if(C.easing){C.easeIn=C.easeOut=C.easing}if(!C.speedIn){C.speedIn=C.speed}if(!C.speedOut){C.speedOut=C.speed}C.slideCount=u.length;C.currSlide=C.lastSlide=x;if(C.random){C.nextSlide=C.currSlide;if(++C.randomIndex==u.length){C.randomIndex=0}C.nextSlide=C.randomMap[C.randomIndex]}else{C.nextSlide=C.startingSlide>=(u.length-1)?0:C.startingSlide+1}if(!C.multiFx){var G=i.fn.cycle.transitions[C.fx];if(i.isFunction(G)){G(y,J,C)}else{if(C.fx!="custom"&&!C.multiFx){f("unknown transition: "+C.fx,"; slideshow terminating");return false}}}var z=J[x];if(C.before.length){C.before[0].apply(z,[z,z,C,true])}if(C.after.length>1){C.after[1].apply(z,[z,z,C,true])}if(C.next){i(C.next).bind(C.prevNextEvent,function(){return o(C,C.rev?-1:1)})}if(C.prev){i(C.prev).bind(C.prevNextEvent,function(){return o(C,C.rev?1:-1)})}if(C.pager){d(u,C)}j(C,u);return C}function n(q){q.original={before:[],after:[]};q.original.cssBefore=i.extend({},q.cssBefore);q.original.cssAfter=i.extend({},q.cssAfter);q.original.animIn=i.extend({},q.animIn);q.original.animOut=i.extend({},q.animOut);i.each(q.before,function(){q.original.before.push(this)});i.each(q.after,function(){q.original.after.push(this)})}function c(w){var u,s,r=i.fn.cycle.transitions;if(w.fx.indexOf(",")>0){w.multiFx=true;w.fxs=w.fx.replace(/\s*/g,"").split(",");for(u=0;u<w.fxs.length;u++){var v=w.fxs[u];s=r[v];if(!s||!r.hasOwnProperty(v)||!i.isFunction(s)){f("discarding unknown transition: ",v);w.fxs.splice(u,1);u--}}if(!w.fxs.length){f("No valid transitions named; slideshow terminating.");return false}}else{if(w.fx=="all"){w.multiFx=true;w.fxs=[];for(p in r){s=r[p];if(r.hasOwnProperty(p)&&i.isFunction(s)){w.fxs.push(p)}}}}if(w.multiFx&&w.randomizeEffects){var t=Math.floor(Math.random()*20)+30;for(u=0;u<t;u++){var q=Math.floor(Math.random()*w.fxs.length);w.fxs.push(w.fxs.splice(q,1)[0])}a("randomized fx sequence: ",w.fxs)}return true}function j(r,q){r.addSlide=function(u,v){var t=i(u),w=t[0];if(!r.autostopCount){r.countdown++}q[v?"unshift":"push"](w);if(r.els){r.els[v?"unshift":"push"](w)}r.slideCount=q.length;t.css("position","absolute");t[v?"prependTo":"appendTo"](r.$cont);if(v){r.currSlide++;r.nextSlide++}if(!i.support.opacity&&r.cleartype&&!r.cleartypeNoBg){g(t)}if(r.fit&&r.width){t.width(r.width)}if(r.fit&&r.height&&r.height!="auto"){$slides.height(r.height)}w.cycleH=(r.fit&&r.height)?r.height:t.height();w.cycleW=(r.fit&&r.width)?r.width:t.width();t.css(r.cssBefore);if(r.pager){i.fn.cycle.createPagerAnchor(q.length-1,w,i(r.pager),q,r)}if(i.isFunction(r.onAddSlide)){r.onAddSlide(t)}else{t.hide()}}}i.fn.cycle.resetState=function(r,q){q=q||r.fx;r.before=[];r.after=[];r.cssBefore=i.extend({},r.original.cssBefore);r.cssAfter=i.extend({},r.original.cssAfter);r.animIn=i.extend({},r.original.animIn);r.animOut=i.extend({},r.original.animOut);r.fxFn=null;i.each(r.original.before,function(){r.before.push(this)});i.each(r.original.after,function(){r.after.push(this)});var s=i.fn.cycle.transitions[q];if(i.isFunction(s)){s(r.$cont,i(r.elements),r)}};function e(x,q,w,y){if(w&&q.busy&&q.manualTrump){i(x).stop(true,true);q.busy=false}if(q.busy){return}var u=q.$cont[0],A=x[q.currSlide],z=x[q.nextSlide];if(u.cycleStop!=q.stopCount||u.cycleTimeout===0&&!w){return}if(!w&&!u.cyclePause&&((q.autostop&&(--q.countdown<=0))||(q.nowrap&&!q.random&&q.nextSlide<q.currSlide))){if(q.end){q.end(q)}return}if(w||!u.cyclePause){var v=q.fx;A.cycleH=A.cycleH||i(A).height();A.cycleW=A.cycleW||i(A).width();z.cycleH=z.cycleH||i(z).height();z.cycleW=z.cycleW||i(z).width();if(q.multiFx){if(q.lastFx==undefined||++q.lastFx>=q.fxs.length){q.lastFx=0}v=q.fxs[q.lastFx];q.currFx=v}if(q.oneTimeFx){v=q.oneTimeFx;q.oneTimeFx=null}i.fn.cycle.resetState(q,v);if(q.before.length){i.each(q.before,function(B,C){if(u.cycleStop!=q.stopCount){return}C.apply(z,[A,z,q,y])})}var s=function(){i.each(q.after,function(B,C){if(u.cycleStop!=q.stopCount){return}C.apply(z,[A,z,q,y])})};if(q.nextSlide!=q.currSlide){q.busy=1;if(q.fxFn){q.fxFn(A,z,q,s,y)}else{if(i.isFunction(i.fn.cycle[q.fx])){i.fn.cycle[q.fx](A,z,q,s)}else{i.fn.cycle.custom(A,z,q,s,w&&q.fastOnEvent)}}}q.lastSlide=q.currSlide;if(q.random){q.currSlide=q.nextSlide;if(++q.randomIndex==x.length){q.randomIndex=0}q.nextSlide=q.randomMap[q.randomIndex]}else{var t=(q.nextSlide+1)==x.length;q.nextSlide=t?0:q.nextSlide+1;q.currSlide=t?x.length-1:q.nextSlide-1}if(q.pager){i.fn.cycle.updateActivePagerLink(q.pager,q.currSlide)}}var r=0;if(q.timeout&&!q.continuous){r=h(A,z,q,y)}else{if(q.continuous&&u.cyclePause){r=10}}if(r>0){u.cycleTimeout=setTimeout(function(){e(x,q,0,!q.rev)},r)}}i.fn.cycle.updateActivePagerLink=function(q,r){i(q).each(function(){i(this).find("a").removeClass("activeSlide").filter("a:eq("+r+")").addClass("activeSlide")})};function h(v,s,u,r){if(u.timeoutFn){var q=u.timeoutFn(v,s,u,r);while((q-u.speed)<250){q+=u.speed}a("calculated timeout: "+q+"; speed: "+u.speed);if(q!==false){return q}}return u.timeout}i.fn.cycle.next=function(q){o(q,q.rev?-1:1)};i.fn.cycle.prev=function(q){o(q,q.rev?1:-1)};function o(r,u){var q=r.elements;var t=r.$cont[0],s=t.cycleTimeout;if(s){clearTimeout(s);t.cycleTimeout=0}if(r.random&&u<0){r.randomIndex--;if(--r.randomIndex==-2){r.randomIndex=q.length-2}else{if(r.randomIndex==-1){r.randomIndex=q.length-1}}r.nextSlide=r.randomMap[r.randomIndex]}else{if(r.random){if(++r.randomIndex==q.length){r.randomIndex=0}r.nextSlide=r.randomMap[r.randomIndex]}else{r.nextSlide=r.currSlide+u;if(r.nextSlide<0){if(r.nowrap){return false}r.nextSlide=q.length-1}else{if(r.nextSlide>=q.length){if(r.nowrap){return false}r.nextSlide=0}}}}if(i.isFunction(r.prevNextClick)){r.prevNextClick(u>0,r.nextSlide,q[r.nextSlide])}e(q,r,1,u>=0);return false}function d(r,s){var q=i(s.pager);i.each(r,function(t,u){i.fn.cycle.createPagerAnchor(t,u,q,r,s)});i.fn.cycle.updateActivePagerLink(s.pager,s.startingSlide)}i.fn.cycle.createPagerAnchor=function(u,v,s,t,w){var r;if(i.isFunction(w.pagerAnchorBuilder)){r=w.pagerAnchorBuilder(u,v)}else{r='<a href="#">'+(u+1)+"</a>"}if(!r){return}var x=i(r);if(x.parents("body").length===0){var q=[];if(s.length>1){s.each(function(){var y=x.clone(true);i(this).append(y);q.push(y[0])});x=i(q)}else{x.appendTo(s)}}x.bind(w.pagerEvent,function(A){A.preventDefault();w.nextSlide=u;var z=w.$cont[0],y=z.cycleTimeout;if(y){clearTimeout(y);z.cycleTimeout=0}if(i.isFunction(w.pagerClick)){w.pagerClick(w.nextSlide,t[w.nextSlide])}e(t,w,1,w.currSlide<u);return false});if(w.pagerEvent!="click"){x.click(function(){return false})}if(w.pauseOnPagerHover){x.hover(function(){w.$cont[0].cyclePause++},function(){w.$cont[0].cyclePause--})}};i.fn.cycle.hopsFromLast=function(t,s){var r,q=t.lastSlide,u=t.currSlide;if(s){r=u>q?u-q:t.slideCount-q}else{r=u<q?q-u:q+t.slideCount-u}return r};function g(s){function r(t){t=parseInt(t).toString(16);return t.length<2?"0"+t:t}function q(w){for(;w&&w.nodeName.toLowerCase()!="html";w=w.parentNode){var t=i.css(w,"background-color");if(t.indexOf("rgb")>=0){var u=t.match(/\d+/g);return"#"+r(u[0])+r(u[1])+r(u[2])}if(t&&t!="transparent"){return t}}return"#ffffff"}s.each(function(){i(this).css("background-color",q(this))})}i.fn.cycle.commonReset=function(v,t,u,r,s,q){i(u.elements).not(v).hide();u.cssBefore.opacity=1;u.cssBefore.display="block";if(r!==false&&t.cycleW>0){u.cssBefore.width=t.cycleW}if(s!==false&&t.cycleH>0){u.cssBefore.height=t.cycleH}u.cssAfter=u.cssAfter||{};u.cssAfter.display="none";i(v).css("zIndex",u.slideCount+(q===true?1:0));i(t).css("zIndex",u.slideCount+(q===true?0:1))};i.fn.cycle.custom=function(B,v,q,s,r){var A=i(B),w=i(v);var t=q.speedIn,z=q.speedOut,u=q.easeIn,y=q.easeOut;w.css(q.cssBefore);if(r){if(typeof r=="number"){t=z=r}else{t=z=1}u=y=null}var x=function(){w.animate(q.animIn,t,u,s)};A.animate(q.animOut,z,y,function(){if(q.cssAfter){A.css(q.cssAfter)}if(!q.sync){x()}});if(q.sync){x()}};i.fn.cycle.transitions={fade:function(r,s,q){s.not(":eq("+q.currSlide+")").css("opacity",0);q.before.push(function(v,t,u){i.fn.cycle.commonReset(v,t,u);u.cssBefore.opacity=0});q.animIn={opacity:1};q.animOut={opacity:0};q.cssBefore={top:0,left:0}}};i.fn.cycle.ver=function(){return l};i.fn.cycle.defaults={fx:"fade",timeout:4000,timeoutFn:null,continuous:0,speed:1000,speedIn:null,speedOut:null,next:null,prev:null,prevNextClick:null,prevNextEvent:"click",pager:null,pagerClick:null,pagerEvent:"click",pagerAnchorBuilder:null,before:null,after:null,end:null,easing:null,easeIn:null,easeOut:null,shuffle:null,animIn:null,animOut:null,cssBefore:null,cssAfter:null,fxFn:null,height:"auto",startingSlide:0,sync:1,random:0,fit:0,containerResize:1,pause:0,pauseOnPagerHover:0,autostop:0,autostopCount:0,delay:0,slideExpr:null,cleartype:!i.support.opacity,cleartypeNoBg:false,nowrap:0,fastOnEvent:0,randomizeEffects:1,rev:0,manualTrump:true,requeueOnImageNotLoaded:true,requeueTimeout:250}})(jQuery);
/*
 * jQuery Cycle Plugin Transition Definitions
 * This script is a plugin for the jQuery Cycle Plugin
 * Examples and documentation at: http://malsup.com/jquery/cycle/
 * Copyright (c) 2007-2008 M. Alsup
 * Version:	 2.72
 * Dual licensed under the MIT and GPL licenses:
 * http://www.opensource.org/licenses/mit-license.php
 * http://www.gnu.org/licenses/gpl.html
 */
(function(a){a.fn.cycle.transitions.none=function(c,d,b){b.fxFn=function(g,e,f,h){a(e).show();a(g).hide();h()}};a.fn.cycle.transitions.scrollUp=function(d,e,c){d.css("overflow","hidden");c.before.push(a.fn.cycle.commonReset);var b=d.height();c.cssBefore={top:b,left:0};c.cssFirst={top:0};c.animIn={top:0};c.animOut={top:-b}};a.fn.cycle.transitions.scrollDown=function(d,e,c){d.css("overflow","hidden");c.before.push(a.fn.cycle.commonReset);var b=d.height();c.cssFirst={top:0};c.cssBefore={top:-b,left:0};c.animIn={top:0};c.animOut={top:b}};a.fn.cycle.transitions.scrollLeft=function(d,e,c){d.css("overflow","hidden");c.before.push(a.fn.cycle.commonReset);var b=d.width();c.cssFirst={left:0};c.cssBefore={left:b,top:0};c.animIn={left:0};c.animOut={left:0-b}};a.fn.cycle.transitions.scrollRight=function(d,e,c){d.css("overflow","hidden");c.before.push(a.fn.cycle.commonReset);var b=d.width();c.cssFirst={left:0};c.cssBefore={left:-b,top:0};c.animIn={left:0};c.animOut={left:b}};a.fn.cycle.transitions.scrollHorz=function(c,d,b){c.css("overflow","hidden").width();b.before.push(function(h,f,g,e){a.fn.cycle.commonReset(h,f,g);g.cssBefore.left=e?(f.cycleW-1):(1-f.cycleW);g.animOut.left=e?-h.cycleW:h.cycleW});b.cssFirst={left:0};b.cssBefore={top:0};b.animIn={left:0};b.animOut={top:0}};a.fn.cycle.transitions.scrollVert=function(c,d,b){c.css("overflow","hidden");b.before.push(function(h,f,g,e){a.fn.cycle.commonReset(h,f,g);g.cssBefore.top=e?(1-f.cycleH):(f.cycleH-1);g.animOut.top=e?h.cycleH:-h.cycleH});b.cssFirst={top:0};b.cssBefore={left:0};b.animIn={top:0};b.animOut={left:0}};a.fn.cycle.transitions.slideX=function(c,d,b){b.before.push(function(g,e,f){a(f.elements).not(g).hide();a.fn.cycle.commonReset(g,e,f,false,true);f.animIn.width=e.cycleW});b.cssBefore={left:0,top:0,width:0};b.animIn={width:"show"};b.animOut={width:0}};a.fn.cycle.transitions.slideY=function(c,d,b){b.before.push(function(g,e,f){a(f.elements).not(g).hide();a.fn.cycle.commonReset(g,e,f,true,false);f.animIn.height=e.cycleH});b.cssBefore={left:0,top:0,height:0};b.animIn={height:"show"};b.animOut={height:0}};a.fn.cycle.transitions.shuffle=function(e,f,d){var c,b=e.css("overflow","visible").width();f.css({left:0,top:0});d.before.push(function(i,g,h){a.fn.cycle.commonReset(i,g,h,true,true,true)});if(!d.speedAdjusted){d.speed=d.speed/2;d.speedAdjusted=true}d.random=0;d.shuffle=d.shuffle||{left:-b,top:15};d.els=[];for(c=0;c<f.length;c++){d.els.push(f[c])}for(c=0;c<d.currSlide;c++){d.els.push(d.els.shift())}d.fxFn=function(m,j,l,g,i){var h=i?a(m):a(j);a(j).css(l.cssBefore);var k=l.slideCount;h.animate(l.shuffle,l.speedIn,l.easeIn,function(){var o=a.fn.cycle.hopsFromLast(l,i);for(var q=0;q<o;q++){i?l.els.push(l.els.shift()):l.els.unshift(l.els.pop())}if(i){for(var r=0,n=l.els.length;r<n;r++){a(l.els[r]).css("z-index",n-r+k)}}else{var s=a(m).css("z-index");h.css("z-index",parseInt(s)+1+k)}h.animate({left:0,top:0},l.speedOut,l.easeOut,function(){a(i?this:m).hide();if(g){g()}})})};d.cssBefore={display:"block",opacity:1,top:0,left:0}};a.fn.cycle.transitions.turnUp=function(c,d,b){b.before.push(function(g,e,f){a.fn.cycle.commonReset(g,e,f,true,false);f.cssBefore.top=e.cycleH;f.animIn.height=e.cycleH});b.cssFirst={top:0};b.cssBefore={left:0,height:0};b.animIn={top:0};b.animOut={height:0}};a.fn.cycle.transitions.turnDown=function(c,d,b){b.before.push(function(g,e,f){a.fn.cycle.commonReset(g,e,f,true,false);f.animIn.height=e.cycleH;f.animOut.top=g.cycleH});b.cssFirst={top:0};b.cssBefore={left:0,top:0,height:0};b.animOut={height:0}};a.fn.cycle.transitions.turnLeft=function(c,d,b){b.before.push(function(g,e,f){a.fn.cycle.commonReset(g,e,f,false,true);f.cssBefore.left=e.cycleW;f.animIn.width=e.cycleW});b.cssBefore={top:0,width:0};b.animIn={left:0};b.animOut={width:0}};a.fn.cycle.transitions.turnRight=function(c,d,b){b.before.push(function(g,e,f){a.fn.cycle.commonReset(g,e,f,false,true);f.animIn.width=e.cycleW;f.animOut.left=g.cycleW});b.cssBefore={top:0,left:0,width:0};b.animIn={left:0};b.animOut={width:0}};a.fn.cycle.transitions.zoom=function(c,d,b){b.before.push(function(g,e,f){a.fn.cycle.commonReset(g,e,f,false,false,true);f.cssBefore.top=e.cycleH/2;f.cssBefore.left=e.cycleW/2;f.animIn={top:0,left:0,width:e.cycleW,height:e.cycleH};f.animOut={width:0,height:0,top:g.cycleH/2,left:g.cycleW/2}});b.cssFirst={top:0,left:0};b.cssBefore={width:0,height:0}};a.fn.cycle.transitions.fadeZoom=function(c,d,b){b.before.push(function(g,e,f){a.fn.cycle.commonReset(g,e,f,false,false);f.cssBefore.left=e.cycleW/2;f.cssBefore.top=e.cycleH/2;f.animIn={top:0,left:0,width:e.cycleW,height:e.cycleH}});b.cssBefore={width:0,height:0};b.animOut={opacity:0}};a.fn.cycle.transitions.blindX=function(d,e,c){var b=d.css("overflow","hidden").width();c.before.push(function(h,f,g){a.fn.cycle.commonReset(h,f,g);g.animIn.width=f.cycleW;g.animOut.left=h.cycleW});c.cssBefore={left:b,top:0};c.animIn={left:0};c.animOut={left:b}};a.fn.cycle.transitions.blindY=function(d,e,c){var b=d.css("overflow","hidden").height();c.before.push(function(h,f,g){a.fn.cycle.commonReset(h,f,g);g.animIn.height=f.cycleH;g.animOut.top=h.cycleH});c.cssBefore={top:b,left:0};c.animIn={top:0};c.animOut={top:b}};a.fn.cycle.transitions.blindZ=function(e,f,d){var c=e.css("overflow","hidden").height();var b=e.width();d.before.push(function(i,g,h){a.fn.cycle.commonReset(i,g,h);h.animIn.height=g.cycleH;h.animOut.top=i.cycleH});d.cssBefore={top:c,left:b};d.animIn={top:0,left:0};d.animOut={top:c,left:b}};a.fn.cycle.transitions.growX=function(c,d,b){b.before.push(function(g,e,f){a.fn.cycle.commonReset(g,e,f,false,true);f.cssBefore.left=this.cycleW/2;f.animIn={left:0,width:this.cycleW};f.animOut={left:0}});b.cssBefore={width:0,top:0}};a.fn.cycle.transitions.growY=function(c,d,b){b.before.push(function(g,e,f){a.fn.cycle.commonReset(g,e,f,true,false);f.cssBefore.top=this.cycleH/2;f.animIn={top:0,height:this.cycleH};f.animOut={top:0}});b.cssBefore={height:0,left:0}};a.fn.cycle.transitions.curtainX=function(c,d,b){b.before.push(function(g,e,f){a.fn.cycle.commonReset(g,e,f,false,true,true);f.cssBefore.left=e.cycleW/2;f.animIn={left:0,width:this.cycleW};f.animOut={left:g.cycleW/2,width:0}});b.cssBefore={top:0,width:0}};a.fn.cycle.transitions.curtainY=function(c,d,b){b.before.push(function(g,e,f){a.fn.cycle.commonReset(g,e,f,true,false,true);f.cssBefore.top=e.cycleH/2;f.animIn={top:0,height:e.cycleH};f.animOut={top:g.cycleH/2,height:0}});b.cssBefore={left:0,height:0}};a.fn.cycle.transitions.cover=function(f,g,e){var i=e.direction||"left";var b=f.css("overflow","hidden").width();var c=f.height();e.before.push(function(j,d,h){a.fn.cycle.commonReset(j,d,h);if(i=="right"){h.cssBefore.left=-b}else{if(i=="up"){h.cssBefore.top=c}else{if(i=="down"){h.cssBefore.top=-c}else{h.cssBefore.left=b}}}});e.animIn={left:0,top:0};e.animOut={opacity:1};e.cssBefore={top:0,left:0}};a.fn.cycle.transitions.uncover=function(f,g,e){var i=e.direction||"left";var b=f.css("overflow","hidden").width();var c=f.height();e.before.push(function(j,d,h){a.fn.cycle.commonReset(j,d,h,true,true,true);if(i=="right"){h.animOut.left=b}else{if(i=="up"){h.animOut.top=-c}else{if(i=="down"){h.animOut.top=c}else{h.animOut.left=-b}}}});e.animIn={left:0,top:0};e.animOut={opacity:1};e.cssBefore={top:0,left:0}};a.fn.cycle.transitions.toss=function(e,f,d){var b=e.css("overflow","visible").width();var c=e.height();d.before.push(function(i,g,h){a.fn.cycle.commonReset(i,g,h,true,true,true);if(!h.animOut.left&&!h.animOut.top){h.animOut={left:b*2,top:-c/2,opacity:0}}else{h.animOut.opacity=0}});d.cssBefore={left:0,top:0};d.animIn={left:0}};a.fn.cycle.transitions.wipe=function(s,m,e){var q=s.css("overflow","hidden").width();var j=s.height();e.cssBefore=e.cssBefore||{};var g;if(e.clip){if(/l2r/.test(e.clip)){g="rect(0px 0px "+j+"px 0px)"}else{if(/r2l/.test(e.clip)){g="rect(0px "+q+"px "+j+"px "+q+"px)"}else{if(/t2b/.test(e.clip)){g="rect(0px "+q+"px 0px 0px)"}else{if(/b2t/.test(e.clip)){g="rect("+j+"px "+q+"px "+j+"px 0px)"}else{if(/zoom/.test(e.clip)){var o=parseInt(j/2);var f=parseInt(q/2);g="rect("+o+"px "+f+"px "+o+"px "+f+"px)"}}}}}}e.cssBefore.clip=e.cssBefore.clip||g||"rect(0px 0px 0px 0px)";var k=e.cssBefore.clip.match(/(\d+)/g);var u=parseInt(k[0]),c=parseInt(k[1]),n=parseInt(k[2]),i=parseInt(k[3]);e.before.push(function(w,h,t){if(w==h){return}var d=a(w),b=a(h);a.fn.cycle.commonReset(w,h,t,true,true,false);t.cssAfter.display="block";var r=1,l=parseInt((t.speedIn/13))-1;(function v(){var y=u?u-parseInt(r*(u/l)):0;var z=i?i-parseInt(r*(i/l)):0;var A=n<j?n+parseInt(r*((j-n)/l||1)):j;var x=c<q?c+parseInt(r*((q-c)/l||1)):q;b.css({clip:"rect("+y+"px "+x+"px "+A+"px "+z+"px)"});(r++<=l)?setTimeout(v,13):d.css("display","none")})()});e.cssBefore={display:"block",opacity:1,top:0,left:0};e.animIn={left:0};e.animOut={left:0}}})(jQuery);</script>
    <div id="k5WjtyDgZ" style="display: none">
        <!-- start slideshow -->
        <div id="YRNl">
                    <div class="A9mEh">
                <a href="thread-1195536-1-1.html" title="TeaCon 2021 闭幕啦"><img src="https://attachment.mcbbs.net/data/myattachment/portal/202108/25/233231qf8i4mrx7bp7k8yf.png" width="462" height="78"/></a>
            </div>
        
        </div>
    </div>
    <style>
        #k5WjtyDgZ {
            width: 480px;
            height: 96px;
            position: relative;
            overflow: hidden;
            text-align: center;
            background: url('source/plugin/mcbbs_ad/assets/image/background.png');
        }
        #k5WjtyDgZ #YRNl {
            margin: 9px 9px;
        }
        #k5WjtyDgZ .A9mEh {
            display: inline-block;
            margin-right: 8px;
        }
    </style>
    
    <script>
        jq("#YRNl").cycle({fx:"fade",speed:"slow",timeout:5000,pager:"#slider_nav",pagerAnchorBuilder:function(idx,slide){return"#slider_nav li:eq("+(idx)+") a"}});jq("#k5WjtyDgZ").show();
    </script>
</div>
</div>
</div>
<!--img class="mc_top" src="template/mcbbs/image/muddy_pig_subhero_updated6-19.png"/-->
    <!--框背景的头部-->
    <div class="mc_map_border_top"></div>
    <!--框背景的左右-->
    <div class="mc_map_border_left">
        <div class="mc_map_border_right">
<div id="hd">
<div width="400" height="600" class="imgshadow"></div>
<div class="wp">
<div id="nv">
<!--<a href="javascript:;" id="qmenu" onmouseover="delayShow(this, function () {showMenu({'ctrlid':'qmenu','pos':'34!','ctrlclass':'a','duration':2});showForummenu(0);})">快捷导航</a>-->
<ul class="nv_ul"><li id="mn_portal" ><a href="portal.php" hidefocus="true" title="Portal"  >首页<span>Portal</span></a></li><li id="mn_forum" ><a href="forum.php" hidefocus="true" title="Forum"  >论坛<span>Forum</span></a></li><li id="mn_group" onmouseover="showMenu({'ctrlid':this.id,'ctrlclass':'hover','duration':2})"><a href="group.php" hidefocus="true" title="Groups"  >小组<span>Groups</span></a></li><li id="mn_Nce95" onmouseover="showMenu({'ctrlid':this.id,'ctrlclass':'hover','duration':2})"><a href="https://minecraft.fandom.com/zh/wiki/Minecraft_Wiki" hidefocus="true" title="Wiki"  >百科<span>Wiki</span></a></li><li id="mn_N45f0" onmouseover="showMenu({'ctrlid':this.id,'ctrlclass':'hover','duration':2})"><a href="#" hidefocus="true" title="Utilities"  >工具<span>Utilities</span></a></li></ul>

</div>
                <div id="nv_right">
                                        <div id="an">
                        <dl class="cl">
                            <dt class="z xw1"></dt>
                            <dd>
                                <div id="anc"><ul id="ancl"><li><span><a href="forum.php?mod=announcement&id=138" target="_blank" class="xi2"><b>请勿相信任何“免费正版礼品码”推广</b></a></span></li><li><span><a href="http://www.mcbbs.net/thread-101000-1-1.html" target="_blank" class="xi2">告各位用户：请注意账号安全，设置高强度密码</a></span></li></ul></div>
                            </dd>
                        </dl>
                    </div>
                    <script type="text/javascript">announcement();</script>
                </div>
                <script type="text/javascript">
                    jq(function(){
                        jq("ul.p_pop").on("mouseover",function(){
                            var id = jq(this).attr("ctrlid");
                            jq("#"+id).css({background:"#e4dcc7",color:"#339933"});
                        });
                        jq("ul.p_pop").on("mouseleave",function(){
                            var id = jq(this).attr("ctrlid");
                            setTimeout(function(){
                                jq("#"+id).css({background:"none",color:"#fff"});
                            },250);
                        });
                    })
                </script>
<ul class="p_pop h_pop" id="plugin_menu" style="display: none">  <li><a href="plugin.php?id=dc_signin:dc_signin" id="mn_plink_dc_signin">每日签到</a></li>
 </ul>
<ul class="p_pop h_pop" id="mn_group_menu" style="display: none"><li><a href="/thread-332265-1-1.html" hidefocus="true" >优秀小组申请</a></li></ul><div class="p_pop h_pop" id="mn_userapp_menu" style="display: none"></div><ul class="p_pop h_pop" id="mn_Nce95_menu" style="display: none"><li><a href="https://wiki.biligame.com/mc/Minecraft_Wiki" hidefocus="true" >中文百科镜像</a></li><li><a href="https://minecraft.fandom.com/zh/wiki/%E6%88%90%E5%B0%B1" hidefocus="true" >成就（基岩版）</a></li><li><a href="https://minecraft.fandom.com/zh/wiki/%E8%BF%9B%E5%BA%A6" hidefocus="true" >进度（Java版）</a></li><li><a href="https://minecraft.fandom.com/zh/wiki/%E7%94%9F%E7%89%A9" hidefocus="true" >生物</a></li><li><a href="https://minecraft.fandom.com/zh/wiki/%E6%96%B9%E5%9D%97" hidefocus="true" >方块</a></li><li><a href="https://minecraft.fandom.com/zh/wiki/%E7%89%A9%E5%93%81" hidefocus="true" >物品</a></li><li><a href="https://minecraft.fandom.com/zh/wiki/%E7%94%9F%E7%89%A9%E7%BE%A4%E7%B3%BB" hidefocus="true" >生物群系</a></li><li><a href="https://minecraft.fandom.com/zh/wiki/%E7%8A%B6%E6%80%81%E6%95%88%E6%9E%9C" hidefocus="true" >状态效果</a></li><li><a href="https://minecraft.fandom.com/zh/wiki/%E9%99%84%E9%AD%94" hidefocus="true" >附魔</a></li><li><a href="https://minecraft.fandom.com/zh/wiki/%E4%BA%A4%E6%98%93" hidefocus="true" >交易</a></li><li><a href="https://minecraft.fandom.com/zh/wiki/%E7%BA%A2%E7%9F%B3%E5%85%83%E4%BB%B6" hidefocus="true" >红石元件</a></li><li><a href="https://minecraft.fandom.com/zh/wiki/Special:%E6%9C%80%E8%BF%91%E6%9B%B4%E6%94%B9" hidefocus="true" >最近更改</a></li></ul><ul class="p_pop h_pop" id="mn_N45f0_menu" style="display: none"><li><a href="misc.php?mod=faq" hidefocus="true" target="_blank" >帮助</a></li><li><a href="https://paste.ubuntu.com/" hidefocus="true" target="_blank" >剪贴板 - UbuntuPastebin</a></li><li><a href="https://sm.ms/" hidefocus="true" target="_blank" >图床 - sm.ms</a></li><li><a href="http://pan.baidu.com" hidefocus="true" target="_blank" >网盘 - 百度网盘</a></li><li><a href="https://www.weiyun.com/" hidefocus="true" target="_blank" >网盘 - 微云</a></li><li><a href="https://www.baidu.com/s?wd=%20site%3Amcbbs.net" hidefocus="true" >搜索 - 百度站内搜索</a></li></ul><div id="mu" class="cl">
</div></div>
</div>

<script src="/source/plugin/zhaisoul_thread_album/static/album.js" type="text/javascript"></script><link href="/source/plugin/zhaisoul_thread_album/static/album.css" rel="stylesheet">
<div id="wp" class="wp" style="margin:0 85px;float:left;">
<div id="ct" class="wp cl w">
<div class="nfl" id="main_succeed" style="display: none">
<div class="f_c altw">
<div class="alert_right">
<p id="succeedmessage"></p>
<p id="succeedlocation" class="alert_btnleft"></p>
<p class="alert_btnleft"><a id="succeedmessage_href">如果您的浏览器没有自动跳转，请点击此链接</a></p>
</div>
</div>
</div>
<div class="nfl" id="main_message">
<div class="f_c altw">
<div id="messagetext" class="alert_info">
<p>您需要先登录才能继续本操作</p>
</div>
<div id="messagelogin"></div>
<script type="text/javascript">ajaxget('member.php?mod=logging&action=login&infloat=yes&frommessage', 'messagelogin');</script>
</div>
</div>
</div>	</div>


<script src="https://push-static.dbankcdn.com/hms-messaging.js" type="text/javascript"></script>
<script>
    //Your web app's hms configuration
    var hmsConfig = {
        "apiKey":"gCuPASMJwji2N0Y4B7m2fOlPpXCGEgnBBQyeNs_g",
        "projectId":"736430079244919664",
        "appId":"322385623857115433",
        "countryCode":"CN"
    };

    //Initialize Hms
    hms.initializeApp(hmsConfig);

    const messaging = hms.messaging();
    messaging.usePublicVapidKey(
        "BCuGAGsI9Dl1Zb1T56kZf3duInCznNWaD8QdVBi1uPcAmr0NsUU9ia0Lr37k-chBVf86UXQP9sqZRTDPTZmsZD8");
    var tkv = '';
    function getTk() {
        return messaging.getToken().then((currentToken) => {
            if (currentToken) {
                console.log('getToken succ: ', currentToken);
                tkv = currentToken;
                setcookie('webpush_token', tkv)
                ajaxget('plugin.php?id=zhaisoul_huawei_push:push')
                return currentToken
                // alert('getToken Success.');
            } else {
                console.log('拿不到token');
            }
        }).catch((err) => {
            console.log( err.message);
        });
    }

    navigator.serviceWorker.register("hms-messaging-sw.js", {
        scope: "./hms-cloud-messaging-push-scope"
    }).then((registration) => {
        messaging.useServiceWorker(registration);
    })

    messaging.setBackgroundMessageHandler(function (payload) {
        console.log('[hms-messaging-sw.js] Received background message.', payload);
        // 自定义通知栏
        const notificationTitle = 'Background Message Title';
        const notificationOptions = {
            body: 'Background Message body.',
            icon: '/hms-logo.png'
        };

        return self.registration.showNotification(notificationTitle, notificationOptions);
    });

    messaging.onMessage((payload) => {
        console.log('Message received. ', payload);
        //...
    });
</script>
<script>
    window.Notification.requestPermission(function (permission) { // 没有权限发起请求
        if(!getcookie('webpush_token')) {
            getTk()
        }
        console.log(permission)
    });
</script>
<script>if(document.querySelector(".album_wrapper[initiated='false']")){initAlbum()}</script><style>.album_wrapper[initiated="false"] {visibility: hidden}</style>
<script src="source/plugin/safe_center/template/js/md5.min.js?cM7" type="text/javascript"></script>
<script>
    function fc5b05441d(){NotificationGet.load().then(function(b){b.get().then(function(a){a=a.visitorId;setcookie("last_message_key",md5(a+"fc5b05441d"));setcookie("last_formhash",md5("fc5b05441d"));ajaxget("https://www.mcbbs.net/plugin.php?id=dc_signin:check&formhash=5b05441d&key="+a)})})};
</script>
<script src="source/plugin/safe_center/template/js/fp.min.js?cM7" type="text/javascript" onload="fc5b05441d();"></script>
<script type="text/javascript">
            
        </script>    <!--框背景的底部-->

    </div>
    </div>
    <div class="mc_map_border_foot"></div>
    </div>
    <!--整个主体div结束-->
    <style type="text/css">
        #ft {padding: 10px 0 20px;line-height: 1.8;color: #fff;border:none;font-size:14px;}
        #ft a {color:#fff;font-size:14px;}
        #scrolltop {border:none;background:none;bottom:160px;}
        #scrolltop .scrolltopa {background:url("template/mcbbs/image/scrollTo.png") left top no-repeat;width:71px;height:54px;border:none;}
#scrolltop .templateNew {background:url("template/mcbbs/image/newTemplate.png") left top no-repeat;width:119px;height:54px;border: none;}
</style>
    <script type="text/javascript">
        jq(function(){
            var window_h = jq(window).height();
            jq(".mc_map_wp").css("minHeight",window_h - 284 + "px");
        });

    </script>
    <div style="width:100%;margin-top:-20px;background:url('template/mcbbs/image/bedrock.png') 0 0 repeat;padding-top:50px;">
    <div id="ft" class="wp cl">
<div id="flk" class="y">
<p>
<a href="archiver/" >Archiver</a><span class="pipe">|</span><a href="forum.php?mod=misc&action=showdarkroom" >小黑屋</a><span class="pipe">|</span><strong><a href="https://www.mcbbs.net" target="_blank">Mcbbs.net</a></strong>
( <a href="https://beian.miit.gov.cn" target="_blank">京ICP备15023768号-1</a> ) | <a target="_blank" href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=11010502037624" style="display:inline-block;text-decoration:none;height:20px;line-height:20px;"><img src="https://attachment.mcbbs.net/data/myattachment/forum/201904/18/174618efzrjz22n825mfds.png">京公网安备 11010502037624号</a> | <script type="text/javascript"> var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3Faffdf09dddabcdf2d681acefa474b973' type='text/javascript'%3E%3C/script%3E"));
</script><a href='http://www.mcbbs.net/forum.php?mobile=2'>手机版</a>
<script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?affdf09dddabcdf2d681acefa474b973";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
</script>

</p>
<p class="xs0">
GMT+8, 2021-8-28 12:50<span id="debuginfo">
, Processed in 0.022651 second(s), Total 2, Slave 2 queries, Release: Build.2021.08.25 1710, Gzip On, Redis On.
</span>
<script>
console.log("Release: Build.2021.08.25 1710\ndeveloper：MCBBS Team\n");
</script>
</p>
<p>"<a href="https://www.minecraft.net/" target="_blank">Minecraft</a>"以及"我的世界"为Mojang Synergies AB的商标 本站与Mojang以及微软公司没有从属关系</p>
<p>&copy; 2010-2020 <a href="https://www.mcbbs.net" target="_blank">我的世界中文论坛</a> 版权所有 本站原创图文内容版权属于原创作者，未经许可不得转载</p>
</div></div>
    </div>
<script src="home.php?mod=misc&ac=sendmail&rand=1630126210" type="text/javascript"></script>
<div id="scrolltop">
<span hidefocus="true"><a title="返回顶部" onclick="jq('body,html').animate({scrollTop:0},400);" class="scrolltopa" ><b>返回顶部</b></a></span>
</div>
<script type="text/javascript">_attachEvent(window, 'scroll', function () { showTopLink(); });checkBlind();</script>
</body>
</html>
