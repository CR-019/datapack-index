execute as @n[type=item,distance=..10,predicate=kks:from_hoe] at @s run function kks:place_hoe_feature

advancement revoke @s from kks:area_tillage