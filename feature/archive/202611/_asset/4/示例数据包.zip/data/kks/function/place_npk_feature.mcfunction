place feature kks:used_npk

kill @s