execute as @n[type=item,distance=..10,predicate=kks:from_npk] at @s run function kks:place_npk_feature

advancement revoke @s from kks:used_npk