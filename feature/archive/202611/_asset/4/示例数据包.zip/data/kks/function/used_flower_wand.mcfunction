execute as @n[type=item,distance=..10,predicate=kks:from_flower_wand] at @s run function kks:place_flower_wand_feature with entity @s Item.components."minecraft:custom_data"

advancement revoke @s from kks:used_flower_wand