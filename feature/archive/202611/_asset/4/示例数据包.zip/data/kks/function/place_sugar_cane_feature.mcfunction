place feature kks:used_sugar_cane_ripener

kill @s