particle happy_villager ~ ~ ~ 0.3 0.3 0.3 0.2 12

$place feature {type:"minecraft:disk",state_provider:{type:"minecraft:weighted",entries:[{weight:1,data:"$(type)"},{weight:4,data:"minecraft:air"}]},radius:2,half_height:0,target:{type:"minecraft:all_of",predicates:[{type:"minecraft:would_survive",state:"minecraft:poppy"},{type:"minecraft:any_of",predicates:[{type:"minecraft:matching_blocks",blocks:"#minecraft:air"},{type:"minecraft:replaceable"}]}]}}

kill @s