execute as @n[type=item,distance=..10,predicate=kks:from_sugar_cane_ripener] at @s run function kks:place_sugar_cane_feature

advancement revoke @s from kks:used_sugar_cane_ripener