execute if predicate \
    {type:entity_properties,entity:this,predicate:{slots:{contents:{components:{custom_model_data:{floats:[1.0f]}}}}}} run \
        place feature kks:area_tillage_lvl_1

execute if predicate \
    {type:entity_properties,entity:this,predicate:{slots:{contents:{components:{custom_model_data:{floats:[2.0f]}}}}}} run \
        place feature kks:area_tillage_lvl_2

execute if predicate \
    {type:entity_properties,entity:this,predicate:{slots:{contents:{components:{custom_model_data:{floats:[3.0f]}}}}}} run \
        place feature kks:area_tillage_lvl_3



kill @s