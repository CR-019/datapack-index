// ---- 太阳模式 ----
// 0 = 与原版一致（太阳保持原版世界位置/渲染，相机视角移动它正确移动）
// 1 = 天空盒，随时间滚动（世界锚定 + 盒体方位随游戏时间旋转）
// 2 = 天空盒，世界锚定 + 时间定格
#define SUN_MODE 2

// ---- 模式 2 专用 ----
// 定格时刻（MC 刻/天，0..24000；6000=正午，12000=日落，18000=午夜，0=日出）
#define SKY_FIXED_TIME 6000.0
// 定格旋向：1.0 或 -1.0
#define SKY_TIME_DIR 1.0
// 时间旋转轴：0=X 1=Y 2=Z
#define SKY_FIX_AXIS 0
// 时间旋转速率倍率
#define SKY_TIME_RATE 1.0

#define SKY_DEBUG_AXES 0

// ---- 公共 ----
#define SUN_SCALE 30.0       // 太阳识别缩放
#define NEAR_PLANE 100.0     // 天空盒所在视空间距离
#define SKY_ROLL_FIX_DEG 180.0  // 天球系倾角校正（模式 1/2）：0/±90/180
#define CELL_MARGIN 0.0      // 块内采样边距（0=铺满整块，不裁边）
#define ALPHA_DISCARD 0.01   // 空隙 alpha 阈值
