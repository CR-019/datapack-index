#version 330

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:skybox_config.glsl>

uniform sampler2D Sampler0;

in vec2 texCoord0;
in vec3 oPosition;
in float isSunV;
in vec3 sunRayView;
in vec2 uPair;
in vec2 vPair;

out vec4 fragColor;

mat3 rot_x(float radians) {
    float c = cos(radians);
    float s = sin(radians);
    return mat3(1.0, 0.0, 0.0,
                0.0, c, -s,
                0.0, s, c);
}

mat3 rot_y(float radians) {
    float c = cos(radians);
    float s = sin(radians);
    return mat3(c, 0.0, -s,
                0.0, 1.0, 0.0,
                s, 0.0, c);
}

mat3 rot_z(float radians) {
    float c = cos(radians);
    float s = sin(radians);
    return mat3(c, -s, 0.0,
                s, c, 0.0,
                0.0, 0.0, 1.0);
}

mat3 rot_fix_axis(float radians) {
    #if SKY_FIX_AXIS == 0
    return rot_x(radians);
    #elif SKY_FIX_AXIS == 1
    return rot_y(radians);
    #else
    return rot_z(radians);
    #endif
}

vec2 sample_cell(vec2 origin, vec2 size, vec2 faceUV) {
    return origin + (faceUV * (1.0 - 2.0 * CELL_MARGIN) + CELL_MARGIN) * size;
}

void main() {
    if (isSunV < 0.5) {
        vec4 color = texture(Sampler0, texCoord0);
        if (color.a == 0.0) {
            discard;
        }
        fragColor = color;
        return;
    }
    #if SUN_MODE == 0
    vec4 color = texture(Sampler0, texCoord0);
    if (color.a == 0.0) {
        discard;
    }
    fragColor = color * ColorModulator;

    #else

    float t = clamp(0.5 * (oPosition.x + 1.0), 0.0, 1.0);
    float s = clamp(0.5 * (oPosition.z + 1.0), 0.0, 1.0);
    float u0 = uPair.x / max(1.0 - t, 1e-4);
    float u1 = uPair.y / max(t, 1e-4);
    float v0 = vPair.x / max(1.0 - s, 1e-4);
    float v1 = vPair.y / max(s, 1e-4);

    vec3 dirView = normalize(sunRayView);

    mat3 m = mat3(ModelViewMat);
    vec3 c0 = normalize(m[0]);
    vec3 c1 = normalize(m[1]);
    vec3 c2 = normalize(m[2]);
    vec3 dir = normalize(transpose(mat3(c0, c1, c2)) * dirView);

    dir = rot_x(radians(SKY_ROLL_FIX_DEG)) * dir;

    #if SUN_MODE == 2

    float dayFrac  = GameTime;
    float fixFrac  = fract(SKY_FIXED_TIME / 24000.0);
    float delta    = (fixFrac - dayFrac) * 6.28318530718 * SKY_TIME_RATE; // 2π × 速率倍率
    dir = rot_fix_axis(SKY_TIME_DIR * delta) * dir;
    #endif

    vec3 ad = abs(dir);
    vec2 cellOrigin;
    vec2 cellSize;
    vec2 faceUV;
    if (ad.y >= ad.x && ad.y >= ad.z) {
        if (dir.y > 0.0) {
            // +Y 顶：u=x/|y|, v=z/|y|
            cellOrigin = vec2(0.25, 0.50);
            cellSize   = vec2(0.25, 0.25);
            faceUV = vec2(0.5 + 0.5 * dir.x / ad.y, 0.5 + 0.5 * dir.z / ad.y);
        } else {
            // -Y 底：u=x/|y|, v=-z/|y|
            cellOrigin = vec2(0.25, 0.00);
            cellSize   = vec2(0.25, 0.25);
            faceUV = vec2(0.5 + 0.5 * dir.x / ad.y, 0.5 - 0.5 * dir.z / ad.y);
        }
    } else if (ad.z >= ad.x) {
        if (dir.z > 0.0) {
            // +Z 前：u=x/|z|, v=-y/|z|
            cellOrigin = vec2(0.25, 0.25);
            cellSize   = vec2(0.25, 0.25);
            faceUV = vec2(0.5 + 0.5 * dir.x / ad.z, 0.5 - 0.5 * dir.y / ad.z);
        } else {
            // -Z 后：u=-x/|z|, v=-y/|z|
            cellOrigin = vec2(0.75, 0.25);
            cellSize   = vec2(0.25, 0.25);
            faceUV = vec2(0.5 - 0.5 * dir.x / ad.z, 0.5 - 0.5 * dir.y / ad.z);
        }
    } else {
        if (dir.x > 0.0) {
            // +X 右：u=-z/|x|, v=-y/|x|
            cellOrigin = vec2(0.50, 0.25);
            cellSize   = vec2(0.25, 0.25);
            faceUV = vec2(0.5 - 0.5 * dir.z / ad.x, 0.5 - 0.5 * dir.y / ad.x);
        } else {
            // -X 左：u=z/|x|, v=-y/|x|
            cellOrigin = vec2(0.00, 0.25);
            cellSize   = vec2(0.25, 0.25);
            faceUV = vec2(0.5 + 0.5 * dir.z / ad.x, 0.5 - 0.5 * dir.y / ad.x);
        }
    }

    //方向校准（烘焙固定值）：对全部六个面统一做 v→1−v。
    faceUV.y = 1.0 - faceUV.y;

    vec2 localUV = sample_cell(cellOrigin, cellSize, faceUV);
    vec2 atlasUV = vec2(u0 + (u1 - u0) * localUV.x, v0 + (v1 - v0) * localUV.y);

    #if SKY_DEBUG_AXES == 1
    vec3 axisColor = abs(dir) * 0.5 + 0.5;
    fragColor = vec4(axisColor, 1.0);
    #else
    vec4 sky = texture(Sampler0, atlasUV);
    if (sky.a < ALPHA_DISCARD) {
        discard;
    }
    fragColor = vec4(sky.xyz, 1.0);
    #endif
    #endif
}
