#version 330

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:skybox_config.glsl>

in vec3 Position;
in vec2 UV0;

out vec2 texCoord0;
out vec3 oPosition;
out float isSunV;
out vec3 sunRayView;
out vec2 uPair;
out vec2 vPair;


void main() {

    float celestialScale = length(ModelViewMat[0].xyz);
    bool isCelestial = abs(Position.y) < 1e-4
                    && abs(Position.x) <= 1.0
                    && abs(Position.z) <= 1.0;
    bool isSun = isCelestial && abs(celestialScale - SUN_SCALE) < 1.5;
    vec3 viewPos;
    if (isSun && SUN_MODE != 0) {
        float halfW = NEAR_PLANE / ProjMat[0][0];
        float halfH = NEAR_PLANE / ProjMat[1][1];
        viewPos = vec3(Position.x * halfW, Position.z * halfH, -NEAR_PLANE);
        sunRayView = viewPos;
        uPair = (Position.x < 0.0) ? vec2(UV0.x, 0.0) : vec2(0.0, UV0.x);
        vPair = (Position.z < 0.0) ? vec2(UV0.y, 0.0) : vec2(0.0, UV0.y);
        isSunV = 1.0;
    } else {
        viewPos = (ModelViewMat * vec4(Position, 1.0)).xyz;
        sunRayView = vec3(0.0);
        uPair = vec2(0.0);
        vPair = vec2(0.0);
        isSunV = isSun ? 1.0 : 0.0;
    }
    gl_Position = ProjMat * vec4(viewPos, 1.0);
    texCoord0 = UV0;
    oPosition = Position;
}
