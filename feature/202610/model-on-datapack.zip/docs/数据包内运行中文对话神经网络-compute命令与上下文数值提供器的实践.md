# 数据包内运行中文对话神经网络：基于 Java 版 26.3 /compute 命令与上下文数值提供器的实践

**古镇天Gugle，咕咕咕鸽Gugle\***

（\* 通讯作者）

---

**摘要**：Minecraft Java 版 26.3 引入的 `/compute` 命令与数据驱动的上下文数值提供器（context number provider）注册表，使数据包首次具备了完整的浮点算术表达力。本文探讨以此在**纯原版数据包**中运行真实神经网络推理的可行性，并给出一个完整实现：一个字节级（byte-level）微型 Transformer（2 层、d_model=64、2 注意力头、87,552 参数，嵌入与输出头权重绑定），在 38 条中文问答语料上过拟合训练后，编译为 2,776 个 `context_float_provider` 注册表项与 24 个函数；推理时由 `schedule` 驱动的逐 token 生成循环执行前向传播，全部矩阵乘、LayerNorm 与 softmax 均由 `/compute` 求值完成，KV cache 以 NBT 列表追加实现，词嵌入查表与贪心解码由 mcfunction 分派完成，输入输出编解码完全在游戏内以 `data modify ... set string` 与 NBT 匹配完成。离线语义模拟器与游戏内实测一致表明：模型可逐字节复现语料回答，单 token 推理约 2.4 秒。本文同时给出数据包神经网络的规模-成本模型（每参数约 160 字节 JSON），并记录了 26.3 新机制的三处实测陷阱：谓词 dispatch 键名变更、`set string` 越界异常与 scheduled 函数的执行者上下文。

**关键词**：Minecraft Java 版；数据包；/compute 命令；数值提供器；Transformer；神经网络推理

---

## 1 引言

在数据包内实现"人工智能"是 Minecraft 技术社区反复出现的话题。此前版本的数值提供器仅有 `constant`、`uniform`、`binomial`、`score`、`storage` 等少数类型，不具备算术组合能力；一切计算必须退化为计分板四则运算链，写一个矩阵乘法即需成百上千条命令，神经网络推理只存在于概念验证级别的极小规模实验中。

Java 版 26.3 改变了这一前提。该版本加入 `/compute` 命令[1]，可在指定战利品上下文中对数值提供器求值；与之配套，数值提供器系统被重构为两个数据驱动注册表（`context_float_provider` 与 `context_int_provider`），并新增了完整的算术类型：`add`、`sub`、`mul`、`div`、`mod`、`pow`、`sqrt`、`sin`、`cos`、`min`、`max`、`avg`、`abs`、`negate`、取整族、`conditional`（按谓词分支）、`storage`（读命令存储 NBT 路径）、`score`（读计分板）等[2][3]。数值提供器由此成为一个**以 JSON 书写的纯函数表达式语言**，而 `/compute` 是它的求值入口。

一个自然的问题是：这套机制的表达能力与性能，是否足以承载真实的神经网络前向推理？本文给出肯定回答，并实现了一个可在游戏内进行中文对话的微型 Transformer——玩家输入 `/function nnchat:ask {text:"问:你好|答:"}`，数据包自行完成文本编码、逐 token 推理与中文渲染输出。本文第 2 节介绍机制背景；第 3 节给出方案设计；第 4 节详述实现；第 5 节介绍验证方法与实测数据；第 6 节讨论规模上限与已知限制；第 7 节总结。

## 2 背景

### 2.1 /compute 命令与上下文数值提供器

26.3 的 `/compute` 语法为 `/compute <default|block <pos>|entity <target>> <float|integer> <provider> [<scale>]`，对提供器求值后返回 `floor(value × scale)` 的整数作为命令返回值[1][2]，可被 `execute store result` 捕获。同时，`data modify <target> <path> set compute ...` 允许把求值结果以 float32 原值直接写入 NBT，跳过整数量化——这是本文激活值回写的最终选择。

提供器可内联于命令，也可作为注册表项置于 `data/<命名空间>/context_float_provider/*.json` 并以 ID 引用[2][3]。`add`/`mul` 等聚合类型的 `inputs` 接受任意长度的提供器列表，因此一个 64 维点积可写成一个扁平节点而非深层嵌套树。求值语义经反编译确认为 float32 顺序累加（`Sum.getFloatUnsafe` 逐项 `+=`），幂运算为 `(float) Math.pow(base, exponent)`。

### 2.2 数据包计算的结构性约束

与通用编程语言相比，数据包计算存在四条硬约束，方案设计必须围绕它们展开：

1. **无循环**：提供器树是静态 JSON，网络结构必须完全展开；
2. **计算图内无动态寻址**：NBT 路径必须是字面量。函数宏（function macro）可以把运行时求得的值代入路径——先用 `execute store` 把下标写入 storage，再 `function <f> with storage <id>` 调用形如 `$data get storage s t[$(i)]` 的宏函数，即可实现运行时按下标读写。但宏是 mcfunction 的机制，**提供器 JSON 内部的 `storage` 路径无法宏化**——算术计算图无法动态寻址，必须静态展开，运行时下标只能在图外（控制流侧）完成查表与数据搬运；
3. **无跨命令浮点状态**：提供器求值是无副作用的纯函数，中间结果要复用必须落盘到命令存储或计分板；
4. **命令链上限**：单次函数调用链受 `max_command_sequence_length` 限制（默认 65,536），长任务必须切分为逐游戏刻的 `schedule` 调度。

### 2.3 相关工作

计分板算术长期以来是数据包数值计算的唯一手段[4]；命令存储（command storage）自 1.15 起提供持久化 NBT[5]，1.19.4 起 `data modify ... set string` 提供子串截取能力——后文将看到，这两条机制分别构成了本方案的"内存系统"与"字符串系统"。Transformer 架构本身遵循 Vaswani 等人的标准定义[6]，训练实现参照 nanoGPT 的最小化风格[7]。

## 3 方案设计

### 3.1 总体结构

系统分为离线与在线两段：

```
离线: 语料(corpus.txt) → numpy 训练器 → weights.json
        → 编译器(gen_datapack.py) → 数据包(2,776 提供器 + 24 函数)
在线: /function nnchat:ask {text:"..."}
        → 编码(文本→UTF-8 字节) → feed(提示词逐 token 前向, 填充 KV cache)
        → gen(逐 token 生成) → 解码(字节→中文渲染)
```

关键分工是：**纯算术全部交给提供器，控制流与动态索引全部交给 mcfunction**。前者是后者的约 2,800 倍命令量，这一比例决定了整体设计。

### 3.2 模型选型

模型规模受 JSON 体积直接约束：每个权重对应点积中的一个 `mul` 节点（约 160 字节），百万参数即约 160 MB，加载时间不可接受。取 87,552 参数（提供器总量 14.5 MB，可接受），具体为：字节级词表 256（UTF-8 编码，token 0 保留为 EOS，任何中文文本均可表示且无需训练分词器）、上下文 64、2 层、d_model=64、2 头（d_head=32）、FFN 128（ReLU）、学习式位置编码、LayerNorm、嵌入与输出头权重绑定。训练目标为**过拟合**——在小语料上"背诵"问答对，字节级小模型即可逐字复现；泛化不是本方案的目标。

### 3.3 计算图到提供器树的映射

设计原则一：**每个需要复用的标量 = 一个命名提供器 + 一次求值回写**。提供器之间不互相引用——求值是无记忆的树遍历，引用即重算，softmax 分母被 64 个分子引用意味着 64 倍重算。因此所有提供器只读 storage 与常量，形成"求值 → 落盘 → 后续提供器读盘"的显式数据流。

设计原则二：**静态结构按最大上下文展开，运行时状态用掩码屏蔽**。注意力分数提供器按 64 个键位全部静态生成，未填充的槽位由 `conditional` 提供器屏蔽：

```json
{
  "type": "conditional",
  "condition": {"type": "int_value_check",
    "value": {"type": "score", "target": {"type": "fixed", "name": "#t"}, "score": "nn"},
    "test": {"min": 5}},
  "on_true": { "...": "点积×1/√32" },
  "on_false": -1e30
}
```

掩码值 -1e30 经 `pow(e, x-max)` 后自然归零，softmax 分母不受影响。KV cache 未填充槽位的 storage 读取由提供器的 `fallback` 机制兜底为 0，配合掩码无害。

### 3.4 动态性的实现

三类动态操作在 mcfunction 侧解决：

- **KV cache**：每层的 K/V 缓存是 NBT 列表，`data modify ... append from` 追加当前行即完成"按位置写入"；注意力提供器对 0..63 个槽位静态展开读取（提供器内无法宏化，见 2.2）；
- **词嵌入/位置嵌入查表**：利用函数宏的运行时下标——把 token 与位置写入 storage 后，宏函数执行 `$data modify ... set from storage <w> E[$(i)]` 直接取行，两次宏调用完成查表（取代早期的 320 行逐一比较分派）；
- **贪心解码**：256 个 logit 经 `/compute` 取整写入计分板后逐一比较，宏函数记录最优 token。

### 3.5 游戏内编解码

**编码**（文本→字节）：`data modify ... set string <源> <路径> <start> <end>` 按宏代入的下标截取单字符，`execute if data` 以 NBT 匹配分派到对应 UTF-8 字节追加（约 830 行，字符表从语料自动提取：215 汉字 + 92 ASCII）。**解码**（字节→中文）：ASCII 字节比分数，CJK 字节读 3 个组成 `{b0,b1,b2}` 复合标签匹配，命中后经宏拼接 `{"text":"字"}` 组件数组，最终以 `tellraw` 的 `"interpret":true` 宽松 JSON 解析渲染。玩家全程无需离开游戏。

## 4 实现

### 4.1 训练器

纯 numpy 手写前向/反向传播（约 400 行），Adam 优化、余弦学习率、梯度裁剪，批 16 × 3,000 步（约 2 分钟）。反向传播经 float64 数值梯度检查（抽样 36 点，相对误差 < 0.01%）。训练用掩码与推理语义严格一致：因果掩码、键长掩码、EOS 监督。

### 4.2 编译器

`gen_datapack.py` 读取 weights.json 生成全部产物。要点包括：

- **点积生成**：输出维 i 的提供器为 `add(mul(W[j][i], X[j]) × n, bias[i], residual?)`；权重路径 `W[j][i]` 与训练布局（`y = x @ W`）一致；
- **softmax**：`mx = max(s[0..63])`，`e[j] = pow(2.718281828, s[j]-mx)`，`p[j] = e[j]/dn`；
- **LayerNorm**：`avg` 求均值，`pow(var+1e-5, -0.5)` 求逆标准差，逐维仿射；
- **激活回写**：`data modify storage <s> <path> set compute default float <id>`，float32 直写无量化；
- **推理驱动**：`feed`/`gen` 每游戏刻处理一个位置并以 `schedule function ... 1t` 续接，单链约 3,400 条命令，远低于默认链上限；
- **HUD 与自动化**：`minecraft:load` 函数标签自动注入权重并挂载 sidebar 进度计分板（状态/总长/位置/已生成）。

### 4.3 工程健壮性

实测排错沉淀为编译器与函数的防御设计：`ask` 自建计分板目标（未初始化也可安全调用）；编码循环以"先置空再截取"检测字符串结束，并以 `#pos ≥ 63` 强制兜底；`nnchat:stop` 可清除全部 scheduled 任务；空输入直接报错中止。

## 5 验证

### 5.1 离线语义模拟器

无游戏环境下，验证依赖一个与生成代码**逐操作对应**的 numpy 模拟器：float32 顺序累加、`pow` 幂、掩码 -1e30、KV cache 追加、logit 取整比较、贪心选词，全部按数据包语义复刻。5 条测试提示在该模拟器下逐字节复现语料答案；`execute store` 量化（floor(v×10000)/10000）与 `set compute` 直写两种模式均通过。数据包侧另有静态自检：2,776 个提供器 JSON 全部可解析、201,989 处 storage 路径越界检查、函数-提供器引用完整性、括号平衡。

### 5.2 游戏内实测

在 26.3 Release Candidate 1 实测：数据包 16.1 MB / 2,802 文件，首次加载约一分钟；单 token 前向（2,776 次求值 + 约 600 条控制命令）实测约 2.4 秒；一次"提示 15 token + 生成 28 token"的完整对话约 100 秒，模型正确回答并自行输出 EOS 终止，中文经游戏内解码器渲染输出。实测同时暴露了 26.3 新机制的三处文档未载行为，已在编译器中修复：

| 陷阱 | 行为 | 对策 |
| --- | --- | --- |
| 谓词 dispatch 键名 | 26.3 内联谓词类型键由旧版 `condition` 改为 `type`（`LootItemCondition.DIRECT_CODEC` 按默认键 dispatch），旧写法报 `No key type` | 编译器统一生成 `type` |
| `set string` 越界 | `end > length` 抛 `invalid_substring` 异常且不修改目标，直接用于循环终止判断会造成死循环 | 先置空再截取，越界即得空串 |
| scheduled 函数上下文 | `schedule` 触发的函数执行者为服务器、无 `@s` 实体，`tellraw @s` 静默失败 | 跨刻消息一律 `@a` |

## 6 讨论

### 6.1 规模-成本模型

以本方案的结构估算，每参数成本约 160 字节 JSON（`mul` + 两个 `storage` 节点），每 token 推理成本约 O(L·d·(d+T)) 次 `/compute` 求值（本模型 2,776 次）。按加载时间一分钟 / 16 MB 外推，**百万参数级模型（约 160 MB）处于可用性的边界**：加载时间将达十分钟量级，单 token 推理进入分钟级。结论是小规模演示可行、实用级语言模型不可行——这与"数据包是配置而非运行时"的定位相符。

### 6.2 已知限制

- **语义记忆而非理解**：87k 参数的过拟合模型只能复现语料答案，对未见表述输出乱码；
- **性能**：2.4 秒/token 的推理使对话延迟以分钟计；服务器线程在推理期间满载；
- **编解码字符表受限**：`"` 与 `\` 因 SNBT 转义无法进入分派表，非语料字符降级为 `?`；
- **快照期机制的稳定性**：谓词键名变更表明 26.3 新机制在开发周期内仍有变动，跨版本需重新核对；
- **网络环境**：命令存储为服务端全局，多玩家并发对话共享状态，需自行加锁。

### 6.3 可能的改进

激活函数与 softmax 的更高精度逼近、按层流水线化以隐藏 `schedule` 延迟、以 `weighted_list` 提供器实现温度采样替代贪心解码，以及以更大的语料-参数配比获得有限的同义泛化能力，均在本框架的能力范围内。

## 7 结论

本文证明：Java 版 26.3 的 `/compute` 命令与上下文数值提供器使数据包具备了承载真实神经网络推理的算术表达力。通过"提供器负责纯算术、mcfunction 负责控制流"的分工，辅以 NBT 列表追加的 KV cache、掩码展开的注意力与游戏内编解码，一个 87,552 参数的字节级 Transformer 可以在纯原版数据包中完成中文对话的全流程。该工作的意义不在实用——而在为"数据包能算什么"划定了一个新的边界：任何可静态展开的浮点计算图，原则上都可以在 26.3 之后的数据包中运行。

## 参考文献

[1] Java版26.3 - Minecraft Wiki[EB/OL]. https://zh.minecraft.wiki/w/Java%E7%89%8826.3.

[2] 命令/compute - Minecraft Wiki[EB/OL]. https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/compute.

[3] 数值提供器 - Minecraft Wiki[EB/OL]. https://zh.minecraft.wiki/w/%E6%95%B0%E5%80%BC%E6%8F%90%E4%BE%9B%E5%99%A8.

[4] 命令/scoreboard - Minecraft Wiki[EB/OL]. https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/scoreboard.

[5] 命令/data - Minecraft Wiki[EB/OL]. https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/data.

[6] Vaswani A, Shazeer N, Parmar N, et al. Attention is All You Need[C]//Advances in Neural Information Processing Systems 30 (NeurIPS 2017).

[7] Karpathy A. nanoGPT: The simplest, fastest repository for training/finetuning medium-sized GPTs[EB/OL]. GitHub. https://github.com/karpathy/nanoGPT.
