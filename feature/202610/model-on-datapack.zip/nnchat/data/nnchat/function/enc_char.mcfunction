scoreboard players set #m nn 0
execute if data storage nnchat:s {ch:" "} store success score #m nn run data modify storage nnchat:s tokens append value 32
execute if data storage nnchat:s {ch:"!"} store success score #m nn run data modify storage nnchat:s tokens append value 33
execute if data storage nnchat:s {ch:"#"} store success score #m nn run data modify storage nnchat:s tokens append value 35
execute if data storage nnchat:s {ch:"$"} store success score #m nn run data modify storage nnchat:s tokens append value 36
execute if data storage nnchat:s {ch:"%"} store success score #m nn run data modify storage nnchat:s tokens append value 37
execute if data storage nnchat:s {ch:"&"} store success score #m nn run data modify storage nnchat:s tokens append value 38
execute if data storage nnchat:s {ch:"'"} store success score #m nn run data modify storage nnchat:s tokens append value 39
execute if data storage nnchat:s {ch:"("} store success score #m nn run data modify storage nnchat:s tokens append value 40
execute if data storage nnchat:s {ch:")"} store success score #m nn run data modify storage nnchat:s tokens append value 41
execute if data storage nnchat:s {ch:"*"} store success score #m nn run data modify storage nnchat:s tokens append value 42
execute if data storage nnchat:s {ch:"+"} store success score #m nn run data modify storage nnchat:s tokens append value 43
execute if data storage nnchat:s {ch:","} store success score #m nn run data modify storage nnchat:s tokens append value 44
execute if data storage nnchat:s {ch:"-"} store success score #m nn run data modify storage nnchat:s tokens append value 45
execute if data storage nnchat:s {ch:"."} store success score #m nn run data modify storage nnchat:s tokens append value 46
execute if data storage nnchat:s {ch:"/"} store success score #m nn run data modify storage nnchat:s tokens append value 47
execute if data storage nnchat:s {ch:"0"} store success score #m nn run data modify storage nnchat:s tokens append value 48
execute if data storage nnchat:s {ch:"1"} store success score #m nn run data modify storage nnchat:s tokens append value 49
execute if data storage nnchat:s {ch:"2"} store success score #m nn run data modify storage nnchat:s tokens append value 50
execute if data storage nnchat:s {ch:"3"} store success score #m nn run data modify storage nnchat:s tokens append value 51
execute if data storage nnchat:s {ch:"4"} store success score #m nn run data modify storage nnchat:s tokens append value 52
execute if data storage nnchat:s {ch:"5"} store success score #m nn run data modify storage nnchat:s tokens append value 53
execute if data storage nnchat:s {ch:"6"} store success score #m nn run data modify storage nnchat:s tokens append value 54
execute if data storage nnchat:s {ch:"7"} store success score #m nn run data modify storage nnchat:s tokens append value 55
execute if data storage nnchat:s {ch:"8"} store success score #m nn run data modify storage nnchat:s tokens append value 56
execute if data storage nnchat:s {ch:"9"} store success score #m nn run data modify storage nnchat:s tokens append value 57
execute if data storage nnchat:s {ch:":"} store success score #m nn run data modify storage nnchat:s tokens append value 58
execute if data storage nnchat:s {ch:";"} store success score #m nn run data modify storage nnchat:s tokens append value 59
execute if data storage nnchat:s {ch:"<"} store success score #m nn run data modify storage nnchat:s tokens append value 60
execute if data storage nnchat:s {ch:"="} store success score #m nn run data modify storage nnchat:s tokens append value 61
execute if data storage nnchat:s {ch:">"} store success score #m nn run data modify storage nnchat:s tokens append value 62
execute if data storage nnchat:s {ch:"?"} store success score #m nn run data modify storage nnchat:s tokens append value 63
execute if data storage nnchat:s {ch:"@"} store success score #m nn run data modify storage nnchat:s tokens append value 64
execute if data storage nnchat:s {ch:"A"} store success score #m nn run data modify storage nnchat:s tokens append value 65
execute if data storage nnchat:s {ch:"B"} store success score #m nn run data modify storage nnchat:s tokens append value 66
execute if data storage nnchat:s {ch:"C"} store success score #m nn run data modify storage nnchat:s tokens append value 67
execute if data storage nnchat:s {ch:"D"} store success score #m nn run data modify storage nnchat:s tokens append value 68
execute if data storage nnchat:s {ch:"E"} store success score #m nn run data modify storage nnchat:s tokens append value 69
execute if data storage nnchat:s {ch:"F"} store success score #m nn run data modify storage nnchat:s tokens append value 70
execute if data storage nnchat:s {ch:"G"} store success score #m nn run data modify storage nnchat:s tokens append value 71
execute if data storage nnchat:s {ch:"H"} store success score #m nn run data modify storage nnchat:s tokens append value 72
execute if data storage nnchat:s {ch:"I"} store success score #m nn run data modify storage nnchat:s tokens append value 73
execute if data storage nnchat:s {ch:"J"} store success score #m nn run data modify storage nnchat:s tokens append value 74
execute if data storage nnchat:s {ch:"K"} store success score #m nn run data modify storage nnchat:s tokens append value 75
execute if data storage nnchat:s {ch:"L"} store success score #m nn run data modify storage nnchat:s tokens append value 76
execute if data storage nnchat:s {ch:"M"} store success score #m nn run data modify storage nnchat:s tokens append value 77
execute if data storage nnchat:s {ch:"N"} store success score #m nn run data modify storage nnchat:s tokens append value 78
execute if data storage nnchat:s {ch:"O"} store success score #m nn run data modify storage nnchat:s tokens append value 79
execute if data storage nnchat:s {ch:"P"} store success score #m nn run data modify storage nnchat:s tokens append value 80
execute if data storage nnchat:s {ch:"Q"} store success score #m nn run data modify storage nnchat:s tokens append value 81
execute if data storage nnchat:s {ch:"R"} store success score #m nn run data modify storage nnchat:s tokens append value 82
execute if data storage nnchat:s {ch:"S"} store success score #m nn run data modify storage nnchat:s tokens append value 83
execute if data storage nnchat:s {ch:"T"} store success score #m nn run data modify storage nnchat:s tokens append value 84
execute if data storage nnchat:s {ch:"U"} store success score #m nn run data modify storage nnchat:s tokens append value 85
execute if data storage nnchat:s {ch:"V"} store success score #m nn run data modify storage nnchat:s tokens append value 86
execute if data storage nnchat:s {ch:"W"} store success score #m nn run data modify storage nnchat:s tokens append value 87
execute if data storage nnchat:s {ch:"X"} store success score #m nn run data modify storage nnchat:s tokens append value 88
execute if data storage nnchat:s {ch:"Y"} store success score #m nn run data modify storage nnchat:s tokens append value 89
execute if data storage nnchat:s {ch:"Z"} store success score #m nn run data modify storage nnchat:s tokens append value 90
execute if data storage nnchat:s {ch:"["} store success score #m nn run data modify storage nnchat:s tokens append value 91
execute if data storage nnchat:s {ch:"]"} store success score #m nn run data modify storage nnchat:s tokens append value 93
execute if data storage nnchat:s {ch:"^"} store success score #m nn run data modify storage nnchat:s tokens append value 94
execute if data storage nnchat:s {ch:"_"} store success score #m nn run data modify storage nnchat:s tokens append value 95
execute if data storage nnchat:s {ch:"`"} store success score #m nn run data modify storage nnchat:s tokens append value 96
execute if data storage nnchat:s {ch:"a"} store success score #m nn run data modify storage nnchat:s tokens append value 97
execute if data storage nnchat:s {ch:"b"} store success score #m nn run data modify storage nnchat:s tokens append value 98
execute if data storage nnchat:s {ch:"c"} store success score #m nn run data modify storage nnchat:s tokens append value 99
execute if data storage nnchat:s {ch:"d"} store success score #m nn run data modify storage nnchat:s tokens append value 100
execute if data storage nnchat:s {ch:"e"} store success score #m nn run data modify storage nnchat:s tokens append value 101
execute if data storage nnchat:s {ch:"f"} store success score #m nn run data modify storage nnchat:s tokens append value 102
execute if data storage nnchat:s {ch:"g"} store success score #m nn run data modify storage nnchat:s tokens append value 103
execute if data storage nnchat:s {ch:"h"} store success score #m nn run data modify storage nnchat:s tokens append value 104
execute if data storage nnchat:s {ch:"i"} store success score #m nn run data modify storage nnchat:s tokens append value 105
execute if data storage nnchat:s {ch:"j"} store success score #m nn run data modify storage nnchat:s tokens append value 106
execute if data storage nnchat:s {ch:"k"} store success score #m nn run data modify storage nnchat:s tokens append value 107
execute if data storage nnchat:s {ch:"l"} store success score #m nn run data modify storage nnchat:s tokens append value 108
execute if data storage nnchat:s {ch:"m"} store success score #m nn run data modify storage nnchat:s tokens append value 109
execute if data storage nnchat:s {ch:"n"} store success score #m nn run data modify storage nnchat:s tokens append value 110
execute if data storage nnchat:s {ch:"o"} store success score #m nn run data modify storage nnchat:s tokens append value 111
execute if data storage nnchat:s {ch:"p"} store success score #m nn run data modify storage nnchat:s tokens append value 112
execute if data storage nnchat:s {ch:"q"} store success score #m nn run data modify storage nnchat:s tokens append value 113
execute if data storage nnchat:s {ch:"r"} store success score #m nn run data modify storage nnchat:s tokens append value 114
execute if data storage nnchat:s {ch:"s"} store success score #m nn run data modify storage nnchat:s tokens append value 115
execute if data storage nnchat:s {ch:"t"} store success score #m nn run data modify storage nnchat:s tokens append value 116
execute if data storage nnchat:s {ch:"u"} store success score #m nn run data modify storage nnchat:s tokens append value 117
execute if data storage nnchat:s {ch:"v"} store success score #m nn run data modify storage nnchat:s tokens append value 118
execute if data storage nnchat:s {ch:"w"} store success score #m nn run data modify storage nnchat:s tokens append value 119
execute if data storage nnchat:s {ch:"x"} store success score #m nn run data modify storage nnchat:s tokens append value 120
execute if data storage nnchat:s {ch:"y"} store success score #m nn run data modify storage nnchat:s tokens append value 121
execute if data storage nnchat:s {ch:"z"} store success score #m nn run data modify storage nnchat:s tokens append value 122
execute if data storage nnchat:s {ch:"{"} store success score #m nn run data modify storage nnchat:s tokens append value 123
execute if data storage nnchat:s {ch:"}"} store success score #m nn run data modify storage nnchat:s tokens append value 125
execute if data storage nnchat:s {ch:"~"} store success score #m nn run data modify storage nnchat:s tokens append value 126
execute if data storage nnchat:s {ch:"。"} store success score #m nn run data modify storage nnchat:s tokens append value 227
execute if data storage nnchat:s {ch:"。"} run data modify storage nnchat:s tokens append value 128
execute if data storage nnchat:s {ch:"。"} run data modify storage nnchat:s tokens append value 130
execute if data storage nnchat:s {ch:"一"} store success score #m nn run data modify storage nnchat:s tokens append value 228
execute if data storage nnchat:s {ch:"一"} run data modify storage nnchat:s tokens append value 184
execute if data storage nnchat:s {ch:"一"} run data modify storage nnchat:s tokens append value 128
execute if data storage nnchat:s {ch:"上"} store success score #m nn run data modify storage nnchat:s tokens append value 228
execute if data storage nnchat:s {ch:"上"} run data modify storage nnchat:s tokens append value 184
execute if data storage nnchat:s {ch:"上"} run data modify storage nnchat:s tokens append value 138
execute if data storage nnchat:s {ch:"下"} store success score #m nn run data modify storage nnchat:s tokens append value 228
execute if data storage nnchat:s {ch:"下"} run data modify storage nnchat:s tokens append value 184
execute if data storage nnchat:s {ch:"下"} run data modify storage nnchat:s tokens append value 139
execute if data storage nnchat:s {ch:"不"} store success score #m nn run data modify storage nnchat:s tokens append value 228
execute if data storage nnchat:s {ch:"不"} run data modify storage nnchat:s tokens append value 184
execute if data storage nnchat:s {ch:"不"} run data modify storage nnchat:s tokens append value 141
execute if data storage nnchat:s {ch:"世"} store success score #m nn run data modify storage nnchat:s tokens append value 228
execute if data storage nnchat:s {ch:"世"} run data modify storage nnchat:s tokens append value 184
execute if data storage nnchat:s {ch:"世"} run data modify storage nnchat:s tokens append value 150
execute if data storage nnchat:s {ch:"两"} store success score #m nn run data modify storage nnchat:s tokens append value 228
execute if data storage nnchat:s {ch:"两"} run data modify storage nnchat:s tokens append value 184
execute if data storage nnchat:s {ch:"两"} run data modify storage nnchat:s tokens append value 164
execute if data storage nnchat:s {ch:"个"} store success score #m nn run data modify storage nnchat:s tokens append value 228
execute if data storage nnchat:s {ch:"个"} run data modify storage nnchat:s tokens append value 184
execute if data storage nnchat:s {ch:"个"} run data modify storage nnchat:s tokens append value 170
execute if data storage nnchat:s {ch:"中"} store success score #m nn run data modify storage nnchat:s tokens append value 228
execute if data storage nnchat:s {ch:"中"} run data modify storage nnchat:s tokens append value 184
execute if data storage nnchat:s {ch:"中"} run data modify storage nnchat:s tokens append value 173
execute if data storage nnchat:s {ch:"为"} store success score #m nn run data modify storage nnchat:s tokens append value 228
execute if data storage nnchat:s {ch:"为"} run data modify storage nnchat:s tokens append value 184
execute if data storage nnchat:s {ch:"为"} run data modify storage nnchat:s tokens append value 186
execute if data storage nnchat:s {ch:"久"} store success score #m nn run data modify storage nnchat:s tokens append value 228
execute if data storage nnchat:s {ch:"久"} run data modify storage nnchat:s tokens append value 185
execute if data storage nnchat:s {ch:"久"} run data modify storage nnchat:s tokens append value 133
execute if data storage nnchat:s {ch:"么"} store success score #m nn run data modify storage nnchat:s tokens append value 228
execute if data storage nnchat:s {ch:"么"} run data modify storage nnchat:s tokens append value 185
execute if data storage nnchat:s {ch:"么"} run data modify storage nnchat:s tokens append value 136
execute if data storage nnchat:s {ch:"乘"} store success score #m nn run data modify storage nnchat:s tokens append value 228
execute if data storage nnchat:s {ch:"乘"} run data modify storage nnchat:s tokens append value 185
execute if data storage nnchat:s {ch:"乘"} run data modify storage nnchat:s tokens append value 152
execute if data storage nnchat:s {ch:"了"} store success score #m nn run data modify storage nnchat:s tokens append value 228
execute if data storage nnchat:s {ch:"了"} run data modify storage nnchat:s tokens append value 186
execute if data storage nnchat:s {ch:"了"} run data modify storage nnchat:s tokens append value 134
execute if data storage nnchat:s {ch:"二"} store success score #m nn run data modify storage nnchat:s tokens append value 228
execute if data storage nnchat:s {ch:"二"} run data modify storage nnchat:s tokens append value 186
execute if data storage nnchat:s {ch:"二"} run data modify storage nnchat:s tokens append value 140
execute if data storage nnchat:s {ch:"于"} store success score #m nn run data modify storage nnchat:s tokens append value 228
execute if data storage nnchat:s {ch:"于"} run data modify storage nnchat:s tokens append value 186
execute if data storage nnchat:s {ch:"于"} run data modify storage nnchat:s tokens append value 142
execute if data storage nnchat:s {ch:"交"} store success score #m nn run data modify storage nnchat:s tokens append value 228
execute if data storage nnchat:s {ch:"交"} run data modify storage nnchat:s tokens append value 186
execute if data storage nnchat:s {ch:"交"} run data modify storage nnchat:s tokens append value 164
execute if data storage nnchat:s {ch:"什"} store success score #m nn run data modify storage nnchat:s tokens append value 228
execute if data storage nnchat:s {ch:"什"} run data modify storage nnchat:s tokens append value 187
execute if data storage nnchat:s {ch:"什"} run data modify storage nnchat:s tokens append value 128
execute if data storage nnchat:s {ch:"代"} store success score #m nn run data modify storage nnchat:s tokens append value 228
execute if data storage nnchat:s {ch:"代"} run data modify storage nnchat:s tokens append value 187
execute if data storage nnchat:s {ch:"代"} run data modify storage nnchat:s tokens append value 163
execute if data storage nnchat:s {ch:"以"} store success score #m nn run data modify storage nnchat:s tokens append value 228
execute if data storage nnchat:s {ch:"以"} run data modify storage nnchat:s tokens append value 187
execute if data storage nnchat:s {ch:"以"} run data modify storage nnchat:s tokens append value 165
execute if data storage nnchat:s {ch:"件"} store success score #m nn run data modify storage nnchat:s tokens append value 228
execute if data storage nnchat:s {ch:"件"} run data modify storage nnchat:s tokens append value 187
execute if data storage nnchat:s {ch:"件"} run data modify storage nnchat:s tokens append value 182
execute if data storage nnchat:s {ch:"会"} store success score #m nn run data modify storage nnchat:s tokens append value 228
execute if data storage nnchat:s {ch:"会"} run data modify storage nnchat:s tokens append value 188
execute if data storage nnchat:s {ch:"会"} run data modify storage nnchat:s tokens append value 154
execute if data storage nnchat:s {ch:"传"} store success score #m nn run data modify storage nnchat:s tokens append value 228
execute if data storage nnchat:s {ch:"传"} run data modify storage nnchat:s tokens append value 188
execute if data storage nnchat:s {ch:"传"} run data modify storage nnchat:s tokens append value 160
execute if data storage nnchat:s {ch:"但"} store success score #m nn run data modify storage nnchat:s tokens append value 228
execute if data storage nnchat:s {ch:"但"} run data modify storage nnchat:s tokens append value 189
execute if data storage nnchat:s {ch:"但"} run data modify storage nnchat:s tokens append value 134
execute if data storage nnchat:s {ch:"住"} store success score #m nn run data modify storage nnchat:s tokens append value 228
execute if data storage nnchat:s {ch:"住"} run data modify storage nnchat:s tokens append value 189
execute if data storage nnchat:s {ch:"住"} run data modify storage nnchat:s tokens append value 143
execute if data storage nnchat:s {ch:"何"} store success score #m nn run data modify storage nnchat:s tokens append value 228
execute if data storage nnchat:s {ch:"何"} run data modify storage nnchat:s tokens append value 189
execute if data storage nnchat:s {ch:"何"} run data modify storage nnchat:s tokens append value 149
execute if data storage nnchat:s {ch:"作"} store success score #m nn run data modify storage nnchat:s tokens append value 228
execute if data storage nnchat:s {ch:"作"} run data modify storage nnchat:s tokens append value 189
execute if data storage nnchat:s {ch:"作"} run data modify storage nnchat:s tokens append value 156
execute if data storage nnchat:s {ch:"你"} store success score #m nn run data modify storage nnchat:s tokens append value 228
execute if data storage nnchat:s {ch:"你"} run data modify storage nnchat:s tokens append value 189
execute if data storage nnchat:s {ch:"你"} run data modify storage nnchat:s tokens append value 160
execute if data storage nnchat:s {ch:"供"} store success score #m nn run data modify storage nnchat:s tokens append value 228
execute if data storage nnchat:s {ch:"供"} run data modify storage nnchat:s tokens append value 190
execute if data storage nnchat:s {ch:"供"} run data modify storage nnchat:s tokens append value 155
execute if data storage nnchat:s {ch:"做"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"做"} run data modify storage nnchat:s tokens append value 129
execute if data storage nnchat:s {ch:"做"} run data modify storage nnchat:s tokens append value 154
execute if data storage nnchat:s {ch:"先"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"先"} run data modify storage nnchat:s tokens append value 133
execute if data storage nnchat:s {ch:"先"} run data modify storage nnchat:s tokens append value 136
execute if data storage nnchat:s {ch:"全"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"全"} run data modify storage nnchat:s tokens append value 133
execute if data storage nnchat:s {ch:"全"} run data modify storage nnchat:s tokens append value 168
execute if data storage nnchat:s {ch:"兴"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"兴"} run data modify storage nnchat:s tokens append value 133
execute if data storage nnchat:s {ch:"兴"} run data modify storage nnchat:s tokens append value 180
execute if data storage nnchat:s {ch:"再"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"再"} run data modify storage nnchat:s tokens append value 134
execute if data storage nnchat:s {ch:"再"} run data modify storage nnchat:s tokens append value 141
execute if data storage nnchat:s {ch:"几"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"几"} run data modify storage nnchat:s tokens append value 135
execute if data storage nnchat:s {ch:"几"} run data modify storage nnchat:s tokens append value 160
execute if data storage nnchat:s {ch:"出"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"出"} run data modify storage nnchat:s tokens append value 135
execute if data storage nnchat:s {ch:"出"} run data modify storage nnchat:s tokens append value 186
execute if data storage nnchat:s {ch:"刚"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"刚"} run data modify storage nnchat:s tokens append value 136
execute if data storage nnchat:s {ch:"刚"} run data modify storage nnchat:s tokens append value 154
execute if data storage nnchat:s {ch:"创"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"创"} run data modify storage nnchat:s tokens append value 136
execute if data storage nnchat:s {ch:"创"} run data modify storage nnchat:s tokens append value 155
execute if data storage nnchat:s {ch:"别"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"别"} run data modify storage nnchat:s tokens append value 136
execute if data storage nnchat:s {ch:"别"} run data modify storage nnchat:s tokens append value 171
execute if data storage nnchat:s {ch:"刻"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"刻"} run data modify storage nnchat:s tokens append value 136
execute if data storage nnchat:s {ch:"刻"} run data modify storage nnchat:s tokens append value 187
execute if data storage nnchat:s {ch:"力"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"力"} run data modify storage nnchat:s tokens append value 138
execute if data storage nnchat:s {ch:"力"} run data modify storage nnchat:s tokens append value 155
execute if data storage nnchat:s {ch:"加"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"加"} run data modify storage nnchat:s tokens append value 138
execute if data storage nnchat:s {ch:"加"} run data modify storage nnchat:s tokens append value 160
execute if data storage nnchat:s {ch:"努"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"努"} run data modify storage nnchat:s tokens append value 138
execute if data storage nnchat:s {ch:"努"} run data modify storage nnchat:s tokens append value 170
execute if data storage nnchat:s {ch:"包"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"包"} run data modify storage nnchat:s tokens append value 140
execute if data storage nnchat:s {ch:"包"} run data modify storage nnchat:s tokens append value 133
execute if data storage nnchat:s {ch:"十"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"十"} run data modify storage nnchat:s tokens append value 141
execute if data storage nnchat:s {ch:"十"} run data modify storage nnchat:s tokens append value 129
execute if data storage nnchat:s {ch:"去"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"去"} run data modify storage nnchat:s tokens append value 142
execute if data storage nnchat:s {ch:"去"} run data modify storage nnchat:s tokens append value 187
execute if data storage nnchat:s {ch:"参"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"参"} run data modify storage nnchat:s tokens append value 143
execute if data storage nnchat:s {ch:"参"} run data modify storage nnchat:s tokens append value 130
execute if data storage nnchat:s {ch:"只"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"只"} run data modify storage nnchat:s tokens append value 143
execute if data storage nnchat:s {ch:"只"} run data modify storage nnchat:s tokens append value 170
execute if data storage nnchat:s {ch:"叫"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"叫"} run data modify storage nnchat:s tokens append value 143
execute if data storage nnchat:s {ch:"叫"} run data modify storage nnchat:s tokens append value 171
execute if data storage nnchat:s {ch:"可"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"可"} run data modify storage nnchat:s tokens append value 143
execute if data storage nnchat:s {ch:"可"} run data modify storage nnchat:s tokens append value 175
execute if data storage nnchat:s {ch:"台"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"台"} run data modify storage nnchat:s tokens append value 143
execute if data storage nnchat:s {ch:"台"} run data modify storage nnchat:s tokens append value 176
execute if data storage nnchat:s {ch:"吃"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"吃"} run data modify storage nnchat:s tokens append value 144
execute if data storage nnchat:s {ch:"吃"} run data modify storage nnchat:s tokens append value 131
execute if data storage nnchat:s {ch:"合"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"合"} run data modify storage nnchat:s tokens append value 144
execute if data storage nnchat:s {ch:"合"} run data modify storage nnchat:s tokens append value 136
execute if data storage nnchat:s {ch:"吗"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"吗"} run data modify storage nnchat:s tokens append value 144
execute if data storage nnchat:s {ch:"吗"} run data modify storage nnchat:s tokens append value 151
execute if data storage nnchat:s {ch:"吧"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"吧"} run data modify storage nnchat:s tokens append value 144
execute if data storage nnchat:s {ch:"吧"} run data modify storage nnchat:s tokens append value 167
execute if data storage nnchat:s {ch:"呀"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"呀"} run data modify storage nnchat:s tokens append value 145
execute if data storage nnchat:s {ch:"呀"} run data modify storage nnchat:s tokens append value 128
execute if data storage nnchat:s {ch:"和"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"和"} run data modify storage nnchat:s tokens append value 146
execute if data storage nnchat:s {ch:"和"} run data modify storage nnchat:s tokens append value 140
execute if data storage nnchat:s {ch:"哪"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"哪"} run data modify storage nnchat:s tokens append value 147
execute if data storage nnchat:s {ch:"哪"} run data modify storage nnchat:s tokens append value 170
execute if data storage nnchat:s {ch:"唱"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"唱"} run data modify storage nnchat:s tokens append value 148
execute if data storage nnchat:s {ch:"唱"} run data modify storage nnchat:s tokens append value 177
execute if data storage nnchat:s {ch:"啊"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"啊"} run data modify storage nnchat:s tokens append value 149
execute if data storage nnchat:s {ch:"啊"} run data modify storage nnchat:s tokens append value 138
execute if data storage nnchat:s {ch:"喜"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"喜"} run data modify storage nnchat:s tokens append value 150
execute if data storage nnchat:s {ch:"喜"} run data modify storage nnchat:s tokens append value 156
execute if data storage nnchat:s {ch:"器"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"器"} run data modify storage nnchat:s tokens append value 153
execute if data storage nnchat:s {ch:"器"} run data modify storage nnchat:s tokens append value 168
execute if data storage nnchat:s {ch:"四"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"四"} run data modify storage nnchat:s tokens append value 155
execute if data storage nnchat:s {ch:"四"} run data modify storage nnchat:s tokens append value 155
execute if data storage nnchat:s {ch:"在"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"在"} run data modify storage nnchat:s tokens append value 156
execute if data storage nnchat:s {ch:"在"} run data modify storage nnchat:s tokens append value 168
execute if data storage nnchat:s {ch:"地"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"地"} run data modify storage nnchat:s tokens append value 156
execute if data storage nnchat:s {ch:"地"} run data modify storage nnchat:s tokens append value 176
execute if data storage nnchat:s {ch:"型"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"型"} run data modify storage nnchat:s tokens append value 158
execute if data storage nnchat:s {ch:"型"} run data modify storage nnchat:s tokens append value 139
execute if data storage nnchat:s {ch:"多"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"多"} run data modify storage nnchat:s tokens append value 164
execute if data storage nnchat:s {ch:"多"} run data modify storage nnchat:s tokens append value 154
execute if data storage nnchat:s {ch:"大"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"大"} run data modify storage nnchat:s tokens append value 164
execute if data storage nnchat:s {ch:"大"} run data modify storage nnchat:s tokens append value 167
execute if data storage nnchat:s {ch:"天"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"天"} run data modify storage nnchat:s tokens append value 164
execute if data storage nnchat:s {ch:"天"} run data modify storage nnchat:s tokens append value 169
execute if data storage nnchat:s {ch:"太"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"太"} run data modify storage nnchat:s tokens append value 164
execute if data storage nnchat:s {ch:"太"} run data modify storage nnchat:s tokens append value 170
execute if data storage nnchat:s {ch:"头"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"头"} run data modify storage nnchat:s tokens append value 164
execute if data storage nnchat:s {ch:"头"} run data modify storage nnchat:s tokens append value 180
execute if data storage nnchat:s {ch:"夹"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"夹"} run data modify storage nnchat:s tokens append value 164
execute if data storage nnchat:s {ch:"夹"} run data modify storage nnchat:s tokens append value 185
execute if data storage nnchat:s {ch:"好"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"好"} run data modify storage nnchat:s tokens append value 165
execute if data storage nnchat:s {ch:"好"} run data modify storage nnchat:s tokens append value 189
execute if data storage nnchat:s {ch:"如"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"如"} run data modify storage nnchat:s tokens append value 166
execute if data storage nnchat:s {ch:"如"} run data modify storage nnchat:s tokens append value 130
execute if data storage nnchat:s {ch:"存"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"存"} run data modify storage nnchat:s tokens append value 173
execute if data storage nnchat:s {ch:"存"} run data modify storage nnchat:s tokens append value 152
execute if data storage nnchat:s {ch:"学"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"学"} run data modify storage nnchat:s tokens append value 173
execute if data storage nnchat:s {ch:"学"} run data modify storage nnchat:s tokens append value 166
execute if data storage nnchat:s {ch:"安"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"安"} run data modify storage nnchat:s tokens append value 174
execute if data storage nnchat:s {ch:"安"} run data modify storage nnchat:s tokens append value 137
execute if data storage nnchat:s {ch:"客"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"客"} run data modify storage nnchat:s tokens append value 174
execute if data storage nnchat:s {ch:"客"} run data modify storage nnchat:s tokens append value 162
execute if data storage nnchat:s {ch:"害"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"害"} run data modify storage nnchat:s tokens append value 174
execute if data storage nnchat:s {ch:"害"} run data modify storage nnchat:s tokens append value 179
execute if data storage nnchat:s {ch:"家"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"家"} run data modify storage nnchat:s tokens append value 174
execute if data storage nnchat:s {ch:"家"} run data modify storage nnchat:s tokens append value 182
execute if data storage nnchat:s {ch:"寄"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"寄"} run data modify storage nnchat:s tokens append value 175
execute if data storage nnchat:s {ch:"寄"} run data modify storage nnchat:s tokens append value 132
execute if data storage nnchat:s {ch:"小"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"小"} run data modify storage nnchat:s tokens append value 176
execute if data storage nnchat:s {ch:"小"} run data modify storage nnchat:s tokens append value 143
execute if data storage nnchat:s {ch:"少"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"少"} run data modify storage nnchat:s tokens append value 176
execute if data storage nnchat:s {ch:"少"} run data modify storage nnchat:s tokens append value 145
execute if data storage nnchat:s {ch:"层"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"层"} run data modify storage nnchat:s tokens append value 177
execute if data storage nnchat:s {ch:"层"} run data modify storage nnchat:s tokens append value 130
execute if data storage nnchat:s {ch:"岩"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"岩"} run data modify storage nnchat:s tokens append value 178
execute if data storage nnchat:s {ch:"岩"} run data modify storage nnchat:s tokens append value 169
execute if data storage nnchat:s {ch:"工"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"工"} run data modify storage nnchat:s tokens append value 183
execute if data storage nnchat:s {ch:"工"} run data modify storage nnchat:s tokens append value 165
execute if data storage nnchat:s {ch:"希"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"希"} run data modify storage nnchat:s tokens append value 184
execute if data storage nnchat:s {ch:"希"} run data modify storage nnchat:s tokens append value 140
execute if data storage nnchat:s {ch:"帮"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"帮"} run data modify storage nnchat:s tokens append value 184
execute if data storage nnchat:s {ch:"帮"} run data modify storage nnchat:s tokens append value 174
execute if data storage nnchat:s {ch:"度"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"度"} run data modify storage nnchat:s tokens append value 186
execute if data storage nnchat:s {ch:"度"} run data modify storage nnchat:s tokens append value 166
execute if data storage nnchat:s {ch:"弦"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"弦"} run data modify storage nnchat:s tokens append value 188
execute if data storage nnchat:s {ch:"弦"} run data modify storage nnchat:s tokens append value 166
execute if data storage nnchat:s {ch:"影"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"影"} run data modify storage nnchat:s tokens append value 189
execute if data storage nnchat:s {ch:"影"} run data modify storage nnchat:s tokens append value 177
execute if data storage nnchat:s {ch:"很"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"很"} run data modify storage nnchat:s tokens append value 190
execute if data storage nnchat:s {ch:"很"} run data modify storage nnchat:s tokens append value 136
execute if data storage nnchat:s {ch:"心"} store success score #m nn run data modify storage nnchat:s tokens append value 229
execute if data storage nnchat:s {ch:"心"} run data modify storage nnchat:s tokens append value 191
execute if data storage nnchat:s {ch:"心"} run data modify storage nnchat:s tokens append value 131
execute if data storage nnchat:s {ch:"怎"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"怎"} run data modify storage nnchat:s tokens append value 128
execute if data storage nnchat:s {ch:"怎"} run data modify storage nnchat:s tokens append value 142
execute if data storage nnchat:s {ch:"怕"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"怕"} run data modify storage nnchat:s tokens append value 128
execute if data storage nnchat:s {ch:"怕"} run data modify storage nnchat:s tokens append value 149
execute if data storage nnchat:s {ch:"思"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"思"} run data modify storage nnchat:s tokens append value 128
execute if data storage nnchat:s {ch:"思"} run data modify storage nnchat:s tokens append value 157
execute if data storage nnchat:s {ch:"意"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"意"} run data modify storage nnchat:s tokens append value 132
execute if data storage nnchat:s {ch:"意"} run data modify storage nnchat:s tokens append value 143
execute if data storage nnchat:s {ch:"愿"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"愿"} run data modify storage nnchat:s tokens append value 132
execute if data storage nnchat:s {ch:"愿"} run data modify storage nnchat:s tokens append value 191
execute if data storage nnchat:s {ch:"慢"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"慢"} run data modify storage nnchat:s tokens append value 133
execute if data storage nnchat:s {ch:"慢"} run data modify storage nnchat:s tokens append value 162
execute if data storage nnchat:s {ch:"戏"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"戏"} run data modify storage nnchat:s tokens append value 136
execute if data storage nnchat:s {ch:"戏"} run data modify storage nnchat:s tokens append value 143
execute if data storage nnchat:s {ch:"成"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"成"} run data modify storage nnchat:s tokens append value 136
execute if data storage nnchat:s {ch:"成"} run data modify storage nnchat:s tokens append value 144
execute if data storage nnchat:s {ch:"我"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"我"} run data modify storage nnchat:s tokens append value 136
execute if data storage nnchat:s {ch:"我"} run data modify storage nnchat:s tokens append value 145
execute if data storage nnchat:s {ch:"或"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"或"} run data modify storage nnchat:s tokens append value 136
execute if data storage nnchat:s {ch:"或"} run data modify storage nnchat:s tokens append value 150
execute if data storage nnchat:s {ch:"打"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"打"} run data modify storage nnchat:s tokens append value 137
execute if data storage nnchat:s {ch:"打"} run data modify storage nnchat:s tokens append value 147
execute if data storage nnchat:s {ch:"挖"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"挖"} run data modify storage nnchat:s tokens append value 140
execute if data storage nnchat:s {ch:"挖"} run data modify storage nnchat:s tokens append value 150
execute if data storage nnchat:s {ch:"据"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"据"} run data modify storage nnchat:s tokens append value 141
execute if data storage nnchat:s {ch:"据"} run data modify storage nnchat:s tokens append value 174
execute if data storage nnchat:s {ch:"掉"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"掉"} run data modify storage nnchat:s tokens append value 142
execute if data storage nnchat:s {ch:"掉"} run data modify storage nnchat:s tokens append value 137
execute if data storage nnchat:s {ch:"推"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"推"} run data modify storage nnchat:s tokens append value 142
execute if data storage nnchat:s {ch:"推"} run data modify storage nnchat:s tokens append value 168
execute if data storage nnchat:s {ch:"提"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"提"} run data modify storage nnchat:s tokens append value 143
execute if data storage nnchat:s {ch:"提"} run data modify storage nnchat:s tokens append value 144
execute if data storage nnchat:s {ch:"改"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"改"} run data modify storage nnchat:s tokens append value 148
execute if data storage nnchat:s {ch:"改"} run data modify storage nnchat:s tokens append value 185
execute if data storage nnchat:s {ch:"放"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"放"} run data modify storage nnchat:s tokens append value 148
execute if data storage nnchat:s {ch:"放"} run data modify storage nnchat:s tokens append value 190
execute if data storage nnchat:s {ch:"数"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"数"} run data modify storage nnchat:s tokens append value 149
execute if data storage nnchat:s {ch:"数"} run data modify storage nnchat:s tokens append value 176
execute if data storage nnchat:s {ch:"文"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"文"} run data modify storage nnchat:s tokens append value 150
execute if data storage nnchat:s {ch:"文"} run data modify storage nnchat:s tokens append value 135
execute if data storage nnchat:s {ch:"料"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"料"} run data modify storage nnchat:s tokens append value 150
execute if data storage nnchat:s {ch:"料"} run data modify storage nnchat:s tokens append value 153
execute if data storage nnchat:s {ch:"无"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"无"} run data modify storage nnchat:s tokens append value 151
execute if data storage nnchat:s {ch:"无"} run data modify storage nnchat:s tokens append value 160
execute if data storage nnchat:s {ch:"明"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"明"} run data modify storage nnchat:s tokens append value 152
execute if data storage nnchat:s {ch:"明"} run data modify storage nnchat:s tokens append value 142
execute if data storage nnchat:s {ch:"易"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"易"} run data modify storage nnchat:s tokens append value 152
execute if data storage nnchat:s {ch:"易"} run data modify storage nnchat:s tokens append value 147
execute if data storage nnchat:s {ch:"是"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"是"} run data modify storage nnchat:s tokens append value 152
execute if data storage nnchat:s {ch:"是"} run data modify storage nnchat:s tokens append value 175
execute if data storage nnchat:s {ch:"晚"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"晚"} run data modify storage nnchat:s tokens append value 153
execute if data storage nnchat:s {ch:"晚"} run data modify storage nnchat:s tokens append value 154
execute if data storage nnchat:s {ch:"晴"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"晴"} run data modify storage nnchat:s tokens append value 153
execute if data storage nnchat:s {ch:"晴"} run data modify storage nnchat:s tokens append value 180
execute if data storage nnchat:s {ch:"晶"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"晶"} run data modify storage nnchat:s tokens append value 153
execute if data storage nnchat:s {ch:"晶"} run data modify storage nnchat:s tokens append value 182
execute if data storage nnchat:s {ch:"有"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"有"} run data modify storage nnchat:s tokens append value 156
execute if data storage nnchat:s {ch:"有"} run data modify storage nnchat:s tokens append value 137
execute if data storage nnchat:s {ch:"望"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"望"} run data modify storage nnchat:s tokens append value 156
execute if data storage nnchat:s {ch:"望"} run data modify storage nnchat:s tokens append value 155
execute if data storage nnchat:s {ch:"木"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"木"} run data modify storage nnchat:s tokens append value 156
execute if data storage nnchat:s {ch:"木"} run data modify storage nnchat:s tokens append value 168
execute if data storage nnchat:s {ch:"末"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"末"} run data modify storage nnchat:s tokens append value 156
execute if data storage nnchat:s {ch:"末"} run data modify storage nnchat:s tokens append value 171
execute if data storage nnchat:s {ch:"材"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"材"} run data modify storage nnchat:s tokens append value 157
execute if data storage nnchat:s {ch:"材"} run data modify storage nnchat:s tokens append value 144
execute if data storage nnchat:s {ch:"村"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"村"} run data modify storage nnchat:s tokens append value 157
execute if data storage nnchat:s {ch:"村"} run data modify storage nnchat:s tokens append value 145
execute if data storage nnchat:s {ch:"来"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"来"} run data modify storage nnchat:s tokens append value 157
execute if data storage nnchat:s {ch:"来"} run data modify storage nnchat:s tokens append value 165
execute if data storage nnchat:s {ch:"板"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"板"} run data modify storage nnchat:s tokens append value 157
execute if data storage nnchat:s {ch:"板"} run data modify storage nnchat:s tokens append value 191
execute if data storage nnchat:s {ch:"架"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"架"} run data modify storage nnchat:s tokens append value 158
execute if data storage nnchat:s {ch:"架"} run data modify storage nnchat:s tokens append value 182
execute if data storage nnchat:s {ch:"标"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"标"} run data modify storage nnchat:s tokens append value 160
execute if data storage nnchat:s {ch:"标"} run data modify storage nnchat:s tokens append value 135
execute if data storage nnchat:s {ch:"格"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"格"} run data modify storage nnchat:s tokens append value 160
execute if data storage nnchat:s {ch:"格"} run data modify storage nnchat:s tokens append value 188
execute if data storage nnchat:s {ch:"梦"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"梦"} run data modify storage nnchat:s tokens append value 162
execute if data storage nnchat:s {ch:"梦"} run data modify storage nnchat:s tokens append value 166
execute if data storage nnchat:s {ch:"梯"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"梯"} run data modify storage nnchat:s tokens append value 162
execute if data storage nnchat:s {ch:"梯"} run data modify storage nnchat:s tokens append value 175
execute if data storage nnchat:s {ch:"欢"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"欢"} run data modify storage nnchat:s tokens append value 172
execute if data storage nnchat:s {ch:"欢"} run data modify storage nnchat:s tokens append value 162
execute if data storage nnchat:s {ch:"歌"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"歌"} run data modify storage nnchat:s tokens append value 173
execute if data storage nnchat:s {ch:"歌"} run data modify storage nnchat:s tokens append value 140
execute if data storage nnchat:s {ch:"正"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"正"} run data modify storage nnchat:s tokens append value 173
execute if data storage nnchat:s {ch:"正"} run data modify storage nnchat:s tokens append value 163
execute if data storage nnchat:s {ch:"毁"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"毁"} run data modify storage nnchat:s tokens append value 175
execute if data storage nnchat:s {ch:"毁"} run data modify storage nnchat:s tokens append value 129
execute if data storage nnchat:s {ch:"每"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"每"} run data modify storage nnchat:s tokens append value 175
execute if data storage nnchat:s {ch:"每"} run data modify storage nnchat:s tokens append value 143
execute if data storage nnchat:s {ch:"民"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"民"} run data modify storage nnchat:s tokens append value 176
execute if data storage nnchat:s {ch:"民"} run data modify storage nnchat:s tokens append value 145
execute if data storage nnchat:s {ch:"气"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"气"} run data modify storage nnchat:s tokens append value 176
execute if data storage nnchat:s {ch:"气"} run data modify storage nnchat:s tokens append value 148
execute if data storage nnchat:s {ch:"水"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"水"} run data modify storage nnchat:s tokens append value 176
execute if data storage nnchat:s {ch:"水"} run data modify storage nnchat:s tokens append value 180
execute if data storage nnchat:s {ch:"没"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"没"} run data modify storage nnchat:s tokens append value 178
execute if data storage nnchat:s {ch:"没"} run data modify storage nnchat:s tokens append value 161
execute if data storage nnchat:s {ch:"法"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"法"} run data modify storage nnchat:s tokens append value 179
execute if data storage nnchat:s {ch:"法"} run data modify storage nnchat:s tokens append value 149
execute if data storage nnchat:s {ch:"波"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"波"} run data modify storage nnchat:s tokens append value 179
execute if data storage nnchat:s {ch:"波"} run data modify storage nnchat:s tokens append value 162
execute if data storage nnchat:s {ch:"注"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"注"} run data modify storage nnchat:s tokens append value 179
execute if data storage nnchat:s {ch:"注"} run data modify storage nnchat:s tokens append value 168
execute if data storage nnchat:s {ch:"浮"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"浮"} run data modify storage nnchat:s tokens append value 181
execute if data storage nnchat:s {ch:"浮"} run data modify storage nnchat:s tokens append value 174
execute if data storage nnchat:s {ch:"深"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"深"} run data modify storage nnchat:s tokens append value 183
execute if data storage nnchat:s {ch:"深"} run data modify storage nnchat:s tokens append value 177
execute if data storage nnchat:s {ch:"游"} store success score #m nn run data modify storage nnchat:s tokens append value 230
execute if data storage nnchat:s {ch:"游"} run data modify storage nnchat:s tokens append value 184
execute if data storage nnchat:s {ch:"游"} run data modify storage nnchat:s tokens append value 184
execute if data storage nnchat:s {ch:"炸"} store success score #m nn run data modify storage nnchat:s tokens append value 231
execute if data storage nnchat:s {ch:"炸"} run data modify storage nnchat:s tokens append value 130
execute if data storage nnchat:s {ch:"炸"} run data modify storage nnchat:s tokens append value 184
execute if data storage nnchat:s {ch:"点"} store success score #m nn run data modify storage nnchat:s tokens append value 231
execute if data storage nnchat:s {ch:"点"} run data modify storage nnchat:s tokens append value 130
execute if data storage nnchat:s {ch:"点"} run data modify storage nnchat:s tokens append value 185
execute if data storage nnchat:s {ch:"爆"} store success score #m nn run data modify storage nnchat:s tokens append value 231
execute if data storage nnchat:s {ch:"爆"} run data modify storage nnchat:s tokens append value 136
execute if data storage nnchat:s {ch:"爆"} run data modify storage nnchat:s tokens append value 134
execute if data storage nnchat:s {ch:"物"} store success score #m nn run data modify storage nnchat:s tokens append value 231
execute if data storage nnchat:s {ch:"物"} run data modify storage nnchat:s tokens append value 137
execute if data storage nnchat:s {ch:"物"} run data modify storage nnchat:s tokens append value 169
execute if data storage nnchat:s {ch:"玩"} store success score #m nn run data modify storage nnchat:s tokens append value 231
execute if data storage nnchat:s {ch:"玩"} run data modify storage nnchat:s tokens append value 142
execute if data storage nnchat:s {ch:"玩"} run data modify storage nnchat:s tokens append value 169
execute if data storage nnchat:s {ch:"理"} store success score #m nn run data modify storage nnchat:s tokens append value 231
execute if data storage nnchat:s {ch:"理"} run data modify storage nnchat:s tokens append value 144
execute if data storage nnchat:s {ch:"理"} run data modify storage nnchat:s tokens append value 134
execute if data storage nnchat:s {ch:"生"} store success score #m nn run data modify storage nnchat:s tokens append value 231
execute if data storage nnchat:s {ch:"生"} run data modify storage nnchat:s tokens append value 148
execute if data storage nnchat:s {ch:"生"} run data modify storage nnchat:s tokens append value 159
execute if data storage nnchat:s {ch:"用"} store success score #m nn run data modify storage nnchat:s tokens append value 231
execute if data storage nnchat:s {ch:"用"} run data modify storage nnchat:s tokens append value 148
execute if data storage nnchat:s {ch:"用"} run data modify storage nnchat:s tokens append value 168
execute if data storage nnchat:s {ch:"电"} store success score #m nn run data modify storage nnchat:s tokens append value 231
execute if data storage nnchat:s {ch:"电"} run data modify storage nnchat:s tokens append value 148
execute if data storage nnchat:s {ch:"电"} run data modify storage nnchat:s tokens append value 181
execute if data storage nnchat:s {ch:"界"} store success score #m nn run data modify storage nnchat:s tokens append value 231
execute if data storage nnchat:s {ch:"界"} run data modify storage nnchat:s tokens append value 149
execute if data storage nnchat:s {ch:"界"} run data modify storage nnchat:s tokens append value 140
execute if data storage nnchat:s {ch:"的"} store success score #m nn run data modify storage nnchat:s tokens append value 231
execute if data storage nnchat:s {ch:"的"} run data modify storage nnchat:s tokens append value 154
execute if data storage nnchat:s {ch:"的"} run data modify storage nnchat:s tokens append value 132
execute if data storage nnchat:s {ch:"石"} store success score #m nn run data modify storage nnchat:s tokens append value 231
execute if data storage nnchat:s {ch:"石"} run data modify storage nnchat:s tokens append value 159
execute if data storage nnchat:s {ch:"石"} run data modify storage nnchat:s tokens append value 179
execute if data storage nnchat:s {ch:"矿"} store success score #m nn run data modify storage nnchat:s tokens append value 231
execute if data storage nnchat:s {ch:"矿"} run data modify storage nnchat:s tokens append value 159
execute if data storage nnchat:s {ch:"矿"} run data modify storage nnchat:s tokens append value 191
execute if data storage nnchat:s {ch:"码"} store success score #m nn run data modify storage nnchat:s tokens append value 231
execute if data storage nnchat:s {ch:"码"} run data modify storage nnchat:s tokens append value 160
execute if data storage nnchat:s {ch:"码"} run data modify storage nnchat:s tokens append value 129
execute if data storage nnchat:s {ch:"神"} store success score #m nn run data modify storage nnchat:s tokens append value 231
execute if data storage nnchat:s {ch:"神"} run data modify storage nnchat:s tokens append value 165
execute if data storage nnchat:s {ch:"神"} run data modify storage nnchat:s tokens append value 158
execute if data storage nnchat:s {ch:"秒"} store success score #m nn run data modify storage nnchat:s tokens append value 231
execute if data storage nnchat:s {ch:"秒"} run data modify storage nnchat:s tokens append value 167
execute if data storage nnchat:s {ch:"秒"} run data modify storage nnchat:s tokens append value 146
execute if data storage nnchat:s {ch:"笑"} store success score #m nn run data modify storage nnchat:s tokens append value 231
execute if data storage nnchat:s {ch:"笑"} run data modify storage nnchat:s tokens append value 172
execute if data storage nnchat:s {ch:"笑"} run data modify storage nnchat:s tokens append value 145
execute if data storage nnchat:s {ch:"等"} store success score #m nn run data modify storage nnchat:s tokens append value 231
execute if data storage nnchat:s {ch:"等"} run data modify storage nnchat:s tokens append value 173
execute if data storage nnchat:s {ch:"等"} run data modify storage nnchat:s tokens append value 137
execute if data storage nnchat:s {ch:"答"} store success score #m nn run data modify storage nnchat:s tokens append value 231
execute if data storage nnchat:s {ch:"答"} run data modify storage nnchat:s tokens append value 173
execute if data storage nnchat:s {ch:"答"} run data modify storage nnchat:s tokens append value 148
execute if data storage nnchat:s {ch:"签"} store success score #m nn run data modify storage nnchat:s tokens append value 231
execute if data storage nnchat:s {ch:"签"} run data modify storage nnchat:s tokens append value 173
execute if data storage nnchat:s {ch:"签"} run data modify storage nnchat:s tokens append value 190
execute if data storage nnchat:s {ch:"算"} store success score #m nn run data modify storage nnchat:s tokens append value 231
execute if data storage nnchat:s {ch:"算"} run data modify storage nnchat:s tokens append value 174
execute if data storage nnchat:s {ch:"算"} run data modify storage nnchat:s tokens append value 151
execute if data storage nnchat:s {ch:"累"} store success score #m nn run data modify storage nnchat:s tokens append value 231
execute if data storage nnchat:s {ch:"累"} run data modify storage nnchat:s tokens append value 180
execute if data storage nnchat:s {ch:"累"} run data modify storage nnchat:s tokens append value 175
execute if data storage nnchat:s {ch:"红"} store success score #m nn run data modify storage nnchat:s tokens append value 231
execute if data storage nnchat:s {ch:"红"} run data modify storage nnchat:s tokens append value 186
execute if data storage nnchat:s {ch:"红"} run data modify storage nnchat:s tokens append value 162
execute if data storage nnchat:s {ch:"经"} store success score #m nn run data modify storage nnchat:s tokens append value 231
execute if data storage nnchat:s {ch:"经"} run data modify storage nnchat:s tokens append value 187
execute if data storage nnchat:s {ch:"经"} run data modify storage nnchat:s tokens append value 143
execute if data storage nnchat:s {ch:"给"} store success score #m nn run data modify storage nnchat:s tokens append value 231
execute if data storage nnchat:s {ch:"给"} run data modify storage nnchat:s tokens append value 187
execute if data storage nnchat:s {ch:"给"} run data modify storage nnchat:s tokens append value 153
execute if data storage nnchat:s {ch:"络"} store success score #m nn run data modify storage nnchat:s tokens append value 231
execute if data storage nnchat:s {ch:"络"} run data modify storage nnchat:s tokens append value 187
execute if data storage nnchat:s {ch:"络"} run data modify storage nnchat:s tokens append value 156
execute if data storage nnchat:s {ch:"绿"} store success score #m nn run data modify storage nnchat:s tokens append value 231
execute if data storage nnchat:s {ch:"绿"} run data modify storage nnchat:s tokens append value 187
execute if data storage nnchat:s {ch:"绿"} run data modify storage nnchat:s tokens append value 191
execute if data storage nnchat:s {ch:"网"} store success score #m nn run data modify storage nnchat:s tokens append value 231
execute if data storage nnchat:s {ch:"网"} run data modify storage nnchat:s tokens append value 189
execute if data storage nnchat:s {ch:"网"} run data modify storage nnchat:s tokens append value 145
execute if data storage nnchat:s {ch:"考"} store success score #m nn run data modify storage nnchat:s tokens append value 232
execute if data storage nnchat:s {ch:"考"} run data modify storage nnchat:s tokens append value 128
execute if data storage nnchat:s {ch:"考"} run data modify storage nnchat:s tokens append value 131
execute if data storage nnchat:s {ch:"者"} store success score #m nn run data modify storage nnchat:s tokens append value 232
execute if data storage nnchat:s {ch:"者"} run data modify storage nnchat:s tokens append value 128
execute if data storage nnchat:s {ch:"者"} run data modify storage nnchat:s tokens append value 133
execute if data storage nnchat:s {ch:"聊"} store success score #m nn run data modify storage nnchat:s tokens append value 232
execute if data storage nnchat:s {ch:"聊"} run data modify storage nnchat:s tokens append value 129
execute if data storage nnchat:s {ch:"聊"} run data modify storage nnchat:s tokens append value 138
execute if data storage nnchat:s {ch:"聪"} store success score #m nn run data modify storage nnchat:s tokens append value 232
execute if data storage nnchat:s {ch:"聪"} run data modify storage nnchat:s tokens append value 129
execute if data storage nnchat:s {ch:"聪"} run data modify storage nnchat:s tokens append value 170
execute if data storage nnchat:s {ch:"胆"} store success score #m nn run data modify storage nnchat:s tokens append value 232
execute if data storage nnchat:s {ch:"胆"} run data modify storage nnchat:s tokens append value 131
execute if data storage nnchat:s {ch:"胆"} run data modify storage nnchat:s tokens append value 134
execute if data storage nnchat:s {ch:"能"} store success score #m nn run data modify storage nnchat:s tokens append value 232
execute if data storage nnchat:s {ch:"能"} run data modify storage nnchat:s tokens append value 131
execute if data storage nnchat:s {ch:"能"} run data modify storage nnchat:s tokens append value 189
execute if data storage nnchat:s {ch:"色"} store success score #m nn run data modify storage nnchat:s tokens append value 232
execute if data storage nnchat:s {ch:"色"} run data modify storage nnchat:s tokens append value 137
execute if data storage nnchat:s {ch:"色"} run data modify storage nnchat:s tokens append value 178
execute if data storage nnchat:s {ch:"苦"} store success score #m nn run data modify storage nnchat:s tokens append value 232
execute if data storage nnchat:s {ch:"苦"} run data modify storage nnchat:s tokens append value 139
execute if data storage nnchat:s {ch:"苦"} run data modify storage nnchat:s tokens append value 166
execute if data storage nnchat:s {ch:"见"} store success score #m nn run data modify storage nnchat:s tokens append value 232
execute if data storage nnchat:s {ch:"见"} run data modify storage nnchat:s tokens append value 167
execute if data storage nnchat:s {ch:"见"} run data modify storage nnchat:s tokens append value 129
execute if data storage nnchat:s {ch:"讲"} store success score #m nn run data modify storage nnchat:s tokens append value 232
execute if data storage nnchat:s {ch:"讲"} run data modify storage nnchat:s tokens append value 174
execute if data storage nnchat:s {ch:"讲"} run data modify storage nnchat:s tokens append value 178
execute if data storage nnchat:s {ch:"话"} store success score #m nn run data modify storage nnchat:s tokens append value 232
execute if data storage nnchat:s {ch:"话"} run data modify storage nnchat:s tokens append value 175
execute if data storage nnchat:s {ch:"话"} run data modify storage nnchat:s tokens append value 157
execute if data storage nnchat:s {ch:"说"} store success score #m nn run data modify storage nnchat:s tokens append value 232
execute if data storage nnchat:s {ch:"说"} run data modify storage nnchat:s tokens append value 175
execute if data storage nnchat:s {ch:"说"} run data modify storage nnchat:s tokens append value 180
execute if data storage nnchat:s {ch:"谁"} store success score #m nn run data modify storage nnchat:s tokens append value 232
execute if data storage nnchat:s {ch:"谁"} run data modify storage nnchat:s tokens append value 176
execute if data storage nnchat:s {ch:"谁"} run data modify storage nnchat:s tokens append value 129
execute if data storage nnchat:s {ch:"谎"} store success score #m nn run data modify storage nnchat:s tokens append value 232
execute if data storage nnchat:s {ch:"谎"} run data modify storage nnchat:s tokens append value 176
execute if data storage nnchat:s {ch:"谎"} run data modify storage nnchat:s tokens append value 142
execute if data storage nnchat:s {ch:"谢"} store success score #m nn run data modify storage nnchat:s tokens append value 232
execute if data storage nnchat:s {ch:"谢"} run data modify storage nnchat:s tokens append value 176
execute if data storage nnchat:s {ch:"谢"} run data modify storage nnchat:s tokens append value 162
execute if data storage nnchat:s {ch:"路"} store success score #m nn run data modify storage nnchat:s tokens append value 232
execute if data storage nnchat:s {ch:"路"} run data modify storage nnchat:s tokens append value 183
execute if data storage nnchat:s {ch:"路"} run data modify storage nnchat:s tokens append value 175
execute if data storage nnchat:s {ch:"跳"} store success score #m nn run data modify storage nnchat:s tokens append value 232
execute if data storage nnchat:s {ch:"跳"} run data modify storage nnchat:s tokens append value 183
execute if data storage nnchat:s {ch:"跳"} run data modify storage nnchat:s tokens append value 179
execute if data storage nnchat:s {ch:"迎"} store success score #m nn run data modify storage nnchat:s tokens append value 232
execute if data storage nnchat:s {ch:"迎"} run data modify storage nnchat:s tokens append value 191
execute if data storage nnchat:s {ch:"迎"} run data modify storage nnchat:s tokens append value 142
execute if data storage nnchat:s {ch:"造"} store success score #m nn run data modify storage nnchat:s tokens append value 233
execute if data storage nnchat:s {ch:"造"} run data modify storage nnchat:s tokens append value 128
execute if data storage nnchat:s {ch:"造"} run data modify storage nnchat:s tokens append value 160
execute if data storage nnchat:s {ch:"里"} store success score #m nn run data modify storage nnchat:s tokens append value 233
execute if data storage nnchat:s {ch:"里"} run data modify storage nnchat:s tokens append value 135
execute if data storage nnchat:s {ch:"里"} run data modify storage nnchat:s tokens append value 140
execute if data storage nnchat:s {ch:"量"} store success score #m nn run data modify storage nnchat:s tokens append value 233
execute if data storage nnchat:s {ch:"量"} run data modify storage nnchat:s tokens append value 135
execute if data storage nnchat:s {ch:"量"} run data modify storage nnchat:s tokens append value 143
execute if data storage nnchat:s {ch:"钻"} store success score #m nn run data modify storage nnchat:s tokens append value 233
execute if data storage nnchat:s {ch:"钻"} run data modify storage nnchat:s tokens append value 146
execute if data storage nnchat:s {ch:"钻"} run data modify storage nnchat:s tokens append value 187
execute if data storage nnchat:s {ch:"铁"} store success score #m nn run data modify storage nnchat:s tokens append value 233
execute if data storage nnchat:s {ch:"铁"} run data modify storage nnchat:s tokens append value 147
execute if data storage nnchat:s {ch:"铁"} run data modify storage nnchat:s tokens append value 129
execute if data storage nnchat:s {ch:"镐"} store success score #m nn run data modify storage nnchat:s tokens append value 233
execute if data storage nnchat:s {ch:"镐"} run data modify storage nnchat:s tokens append value 149
execute if data storage nnchat:s {ch:"镐"} run data modify storage nnchat:s tokens append value 144
execute if data storage nnchat:s {ch:"问"} store success score #m nn run data modify storage nnchat:s tokens append value 233
execute if data storage nnchat:s {ch:"问"} run data modify storage nnchat:s tokens append value 151
execute if data storage nnchat:s {ch:"问"} run data modify storage nnchat:s tokens append value 174
execute if data storage nnchat:s {ch:"降"} store success score #m nn run data modify storage nnchat:s tokens append value 233
execute if data storage nnchat:s {ch:"降"} run data modify storage nnchat:s tokens append value 153
execute if data storage nnchat:s {ch:"降"} run data modify storage nnchat:s tokens append value 141
execute if data storage nnchat:s {ch:"面"} store success score #m nn run data modify storage nnchat:s tokens append value 233
execute if data storage nnchat:s {ch:"面"} run data modify storage nnchat:s tokens append value 157
execute if data storage nnchat:s {ch:"面"} run data modify storage nnchat:s tokens append value 162
execute if data storage nnchat:s {ch:"飘"} store success score #m nn run data modify storage nnchat:s tokens append value 233
execute if data storage nnchat:s {ch:"飘"} run data modify storage nnchat:s tokens append value 163
execute if data storage nnchat:s {ch:"飘"} run data modify storage nnchat:s tokens append value 152
execute if data storage nnchat:s {ch:"飞"} store success score #m nn run data modify storage nnchat:s tokens append value 233
execute if data storage nnchat:s {ch:"飞"} run data modify storage nnchat:s tokens append value 163
execute if data storage nnchat:s {ch:"飞"} run data modify storage nnchat:s tokens append value 158
execute if data storage nnchat:s {ch:"食"} store success score #m nn run data modify storage nnchat:s tokens append value 233
execute if data storage nnchat:s {ch:"食"} run data modify storage nnchat:s tokens append value 163
execute if data storage nnchat:s {ch:"食"} run data modify storage nnchat:s tokens append value 159
execute if data storage nnchat:s {ch:"饿"} store success score #m nn run data modify storage nnchat:s tokens append value 233
execute if data storage nnchat:s {ch:"饿"} run data modify storage nnchat:s tokens append value 165
execute if data storage nnchat:s {ch:"饿"} run data modify storage nnchat:s tokens append value 191
execute if data storage nnchat:s {ch:"骷"} store success score #m nn run data modify storage nnchat:s tokens append value 233
execute if data storage nnchat:s {ch:"骷"} run data modify storage nnchat:s tokens append value 170
execute if data storage nnchat:s {ch:"骷"} run data modify storage nnchat:s tokens append value 183
execute if data storage nnchat:s {ch:"髅"} store success score #m nn run data modify storage nnchat:s tokens append value 233
execute if data storage nnchat:s {ch:"髅"} run data modify storage nnchat:s tokens append value 171
execute if data storage nnchat:s {ch:"髅"} run data modify storage nnchat:s tokens append value 133
execute if data storage nnchat:s {ch:"高"} store success score #m nn run data modify storage nnchat:s tokens append value 233
execute if data storage nnchat:s {ch:"高"} run data modify storage nnchat:s tokens append value 171
execute if data storage nnchat:s {ch:"高"} run data modify storage nnchat:s tokens append value 152
execute if data storage nnchat:s {ch:"黑"} store success score #m nn run data modify storage nnchat:s tokens append value 233
execute if data storage nnchat:s {ch:"黑"} run data modify storage nnchat:s tokens append value 187
execute if data storage nnchat:s {ch:"黑"} run data modify storage nnchat:s tokens append value 145
execute if data storage nnchat:s {ch:"龙"} store success score #m nn run data modify storage nnchat:s tokens append value 233
execute if data storage nnchat:s {ch:"龙"} run data modify storage nnchat:s tokens append value 190
execute if data storage nnchat:s {ch:"龙"} run data modify storage nnchat:s tokens append value 153
execute if data storage nnchat:s {ch:"！"} store success score #m nn run data modify storage nnchat:s tokens append value 239
execute if data storage nnchat:s {ch:"！"} run data modify storage nnchat:s tokens append value 188
execute if data storage nnchat:s {ch:"！"} run data modify storage nnchat:s tokens append value 129
execute if data storage nnchat:s {ch:"，"} store success score #m nn run data modify storage nnchat:s tokens append value 239
execute if data storage nnchat:s {ch:"，"} run data modify storage nnchat:s tokens append value 188
execute if data storage nnchat:s {ch:"，"} run data modify storage nnchat:s tokens append value 140
execute if data storage nnchat:s {ch:"|"} store success score #m nn run data modify storage nnchat:s tokens append value 10
# 未知字符 -> '?'
execute if score #m nn matches 0 run data modify storage nnchat:s tokens append value 63
scoreboard players add #pos nn 1
function nnchat:enc_loop
