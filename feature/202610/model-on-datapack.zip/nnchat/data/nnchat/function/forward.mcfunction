# --- 词嵌入/位置嵌入查表 (宏代入运行时下标) ---
execute store result storage nnchat:s ei.i int 1 run scoreboard players get #btok nn
function nnchat:emb_tok with storage nnchat:s ei
execute store result storage nnchat:s ei.i int 1 run scoreboard players get #t nn
function nnchat:emb_pos with storage nnchat:s ei
data modify storage nnchat:s x[0] set compute default float nnchat:emb_0
data modify storage nnchat:s x[1] set compute default float nnchat:emb_1
data modify storage nnchat:s x[2] set compute default float nnchat:emb_2
data modify storage nnchat:s x[3] set compute default float nnchat:emb_3
data modify storage nnchat:s x[4] set compute default float nnchat:emb_4
data modify storage nnchat:s x[5] set compute default float nnchat:emb_5
data modify storage nnchat:s x[6] set compute default float nnchat:emb_6
data modify storage nnchat:s x[7] set compute default float nnchat:emb_7
data modify storage nnchat:s x[8] set compute default float nnchat:emb_8
data modify storage nnchat:s x[9] set compute default float nnchat:emb_9
data modify storage nnchat:s x[10] set compute default float nnchat:emb_10
data modify storage nnchat:s x[11] set compute default float nnchat:emb_11
data modify storage nnchat:s x[12] set compute default float nnchat:emb_12
data modify storage nnchat:s x[13] set compute default float nnchat:emb_13
data modify storage nnchat:s x[14] set compute default float nnchat:emb_14
data modify storage nnchat:s x[15] set compute default float nnchat:emb_15
data modify storage nnchat:s x[16] set compute default float nnchat:emb_16
data modify storage nnchat:s x[17] set compute default float nnchat:emb_17
data modify storage nnchat:s x[18] set compute default float nnchat:emb_18
data modify storage nnchat:s x[19] set compute default float nnchat:emb_19
data modify storage nnchat:s x[20] set compute default float nnchat:emb_20
data modify storage nnchat:s x[21] set compute default float nnchat:emb_21
data modify storage nnchat:s x[22] set compute default float nnchat:emb_22
data modify storage nnchat:s x[23] set compute default float nnchat:emb_23
data modify storage nnchat:s x[24] set compute default float nnchat:emb_24
data modify storage nnchat:s x[25] set compute default float nnchat:emb_25
data modify storage nnchat:s x[26] set compute default float nnchat:emb_26
data modify storage nnchat:s x[27] set compute default float nnchat:emb_27
data modify storage nnchat:s x[28] set compute default float nnchat:emb_28
data modify storage nnchat:s x[29] set compute default float nnchat:emb_29
data modify storage nnchat:s x[30] set compute default float nnchat:emb_30
data modify storage nnchat:s x[31] set compute default float nnchat:emb_31
data modify storage nnchat:s x[32] set compute default float nnchat:emb_32
data modify storage nnchat:s x[33] set compute default float nnchat:emb_33
data modify storage nnchat:s x[34] set compute default float nnchat:emb_34
data modify storage nnchat:s x[35] set compute default float nnchat:emb_35
data modify storage nnchat:s x[36] set compute default float nnchat:emb_36
data modify storage nnchat:s x[37] set compute default float nnchat:emb_37
data modify storage nnchat:s x[38] set compute default float nnchat:emb_38
data modify storage nnchat:s x[39] set compute default float nnchat:emb_39
data modify storage nnchat:s x[40] set compute default float nnchat:emb_40
data modify storage nnchat:s x[41] set compute default float nnchat:emb_41
data modify storage nnchat:s x[42] set compute default float nnchat:emb_42
data modify storage nnchat:s x[43] set compute default float nnchat:emb_43
data modify storage nnchat:s x[44] set compute default float nnchat:emb_44
data modify storage nnchat:s x[45] set compute default float nnchat:emb_45
data modify storage nnchat:s x[46] set compute default float nnchat:emb_46
data modify storage nnchat:s x[47] set compute default float nnchat:emb_47
data modify storage nnchat:s x[48] set compute default float nnchat:emb_48
data modify storage nnchat:s x[49] set compute default float nnchat:emb_49
data modify storage nnchat:s x[50] set compute default float nnchat:emb_50
data modify storage nnchat:s x[51] set compute default float nnchat:emb_51
data modify storage nnchat:s x[52] set compute default float nnchat:emb_52
data modify storage nnchat:s x[53] set compute default float nnchat:emb_53
data modify storage nnchat:s x[54] set compute default float nnchat:emb_54
data modify storage nnchat:s x[55] set compute default float nnchat:emb_55
data modify storage nnchat:s x[56] set compute default float nnchat:emb_56
data modify storage nnchat:s x[57] set compute default float nnchat:emb_57
data modify storage nnchat:s x[58] set compute default float nnchat:emb_58
data modify storage nnchat:s x[59] set compute default float nnchat:emb_59
data modify storage nnchat:s x[60] set compute default float nnchat:emb_60
data modify storage nnchat:s x[61] set compute default float nnchat:emb_61
data modify storage nnchat:s x[62] set compute default float nnchat:emb_62
data modify storage nnchat:s x[63] set compute default float nnchat:emb_63
# --- 层 0: LN1 ---
data modify storage nnchat:s m set compute default float nnchat:l0_m1
data modify storage nnchat:s c[0] set compute default float nnchat:l0_c1_0
data modify storage nnchat:s c[1] set compute default float nnchat:l0_c1_1
data modify storage nnchat:s c[2] set compute default float nnchat:l0_c1_2
data modify storage nnchat:s c[3] set compute default float nnchat:l0_c1_3
data modify storage nnchat:s c[4] set compute default float nnchat:l0_c1_4
data modify storage nnchat:s c[5] set compute default float nnchat:l0_c1_5
data modify storage nnchat:s c[6] set compute default float nnchat:l0_c1_6
data modify storage nnchat:s c[7] set compute default float nnchat:l0_c1_7
data modify storage nnchat:s c[8] set compute default float nnchat:l0_c1_8
data modify storage nnchat:s c[9] set compute default float nnchat:l0_c1_9
data modify storage nnchat:s c[10] set compute default float nnchat:l0_c1_10
data modify storage nnchat:s c[11] set compute default float nnchat:l0_c1_11
data modify storage nnchat:s c[12] set compute default float nnchat:l0_c1_12
data modify storage nnchat:s c[13] set compute default float nnchat:l0_c1_13
data modify storage nnchat:s c[14] set compute default float nnchat:l0_c1_14
data modify storage nnchat:s c[15] set compute default float nnchat:l0_c1_15
data modify storage nnchat:s c[16] set compute default float nnchat:l0_c1_16
data modify storage nnchat:s c[17] set compute default float nnchat:l0_c1_17
data modify storage nnchat:s c[18] set compute default float nnchat:l0_c1_18
data modify storage nnchat:s c[19] set compute default float nnchat:l0_c1_19
data modify storage nnchat:s c[20] set compute default float nnchat:l0_c1_20
data modify storage nnchat:s c[21] set compute default float nnchat:l0_c1_21
data modify storage nnchat:s c[22] set compute default float nnchat:l0_c1_22
data modify storage nnchat:s c[23] set compute default float nnchat:l0_c1_23
data modify storage nnchat:s c[24] set compute default float nnchat:l0_c1_24
data modify storage nnchat:s c[25] set compute default float nnchat:l0_c1_25
data modify storage nnchat:s c[26] set compute default float nnchat:l0_c1_26
data modify storage nnchat:s c[27] set compute default float nnchat:l0_c1_27
data modify storage nnchat:s c[28] set compute default float nnchat:l0_c1_28
data modify storage nnchat:s c[29] set compute default float nnchat:l0_c1_29
data modify storage nnchat:s c[30] set compute default float nnchat:l0_c1_30
data modify storage nnchat:s c[31] set compute default float nnchat:l0_c1_31
data modify storage nnchat:s c[32] set compute default float nnchat:l0_c1_32
data modify storage nnchat:s c[33] set compute default float nnchat:l0_c1_33
data modify storage nnchat:s c[34] set compute default float nnchat:l0_c1_34
data modify storage nnchat:s c[35] set compute default float nnchat:l0_c1_35
data modify storage nnchat:s c[36] set compute default float nnchat:l0_c1_36
data modify storage nnchat:s c[37] set compute default float nnchat:l0_c1_37
data modify storage nnchat:s c[38] set compute default float nnchat:l0_c1_38
data modify storage nnchat:s c[39] set compute default float nnchat:l0_c1_39
data modify storage nnchat:s c[40] set compute default float nnchat:l0_c1_40
data modify storage nnchat:s c[41] set compute default float nnchat:l0_c1_41
data modify storage nnchat:s c[42] set compute default float nnchat:l0_c1_42
data modify storage nnchat:s c[43] set compute default float nnchat:l0_c1_43
data modify storage nnchat:s c[44] set compute default float nnchat:l0_c1_44
data modify storage nnchat:s c[45] set compute default float nnchat:l0_c1_45
data modify storage nnchat:s c[46] set compute default float nnchat:l0_c1_46
data modify storage nnchat:s c[47] set compute default float nnchat:l0_c1_47
data modify storage nnchat:s c[48] set compute default float nnchat:l0_c1_48
data modify storage nnchat:s c[49] set compute default float nnchat:l0_c1_49
data modify storage nnchat:s c[50] set compute default float nnchat:l0_c1_50
data modify storage nnchat:s c[51] set compute default float nnchat:l0_c1_51
data modify storage nnchat:s c[52] set compute default float nnchat:l0_c1_52
data modify storage nnchat:s c[53] set compute default float nnchat:l0_c1_53
data modify storage nnchat:s c[54] set compute default float nnchat:l0_c1_54
data modify storage nnchat:s c[55] set compute default float nnchat:l0_c1_55
data modify storage nnchat:s c[56] set compute default float nnchat:l0_c1_56
data modify storage nnchat:s c[57] set compute default float nnchat:l0_c1_57
data modify storage nnchat:s c[58] set compute default float nnchat:l0_c1_58
data modify storage nnchat:s c[59] set compute default float nnchat:l0_c1_59
data modify storage nnchat:s c[60] set compute default float nnchat:l0_c1_60
data modify storage nnchat:s c[61] set compute default float nnchat:l0_c1_61
data modify storage nnchat:s c[62] set compute default float nnchat:l0_c1_62
data modify storage nnchat:s c[63] set compute default float nnchat:l0_c1_63
data modify storage nnchat:s var set compute default float nnchat:l0_var1
data modify storage nnchat:s inv set compute default float nnchat:l0_inv1
data modify storage nnchat:s n[0] set compute default float nnchat:l0_n1_0
data modify storage nnchat:s n[1] set compute default float nnchat:l0_n1_1
data modify storage nnchat:s n[2] set compute default float nnchat:l0_n1_2
data modify storage nnchat:s n[3] set compute default float nnchat:l0_n1_3
data modify storage nnchat:s n[4] set compute default float nnchat:l0_n1_4
data modify storage nnchat:s n[5] set compute default float nnchat:l0_n1_5
data modify storage nnchat:s n[6] set compute default float nnchat:l0_n1_6
data modify storage nnchat:s n[7] set compute default float nnchat:l0_n1_7
data modify storage nnchat:s n[8] set compute default float nnchat:l0_n1_8
data modify storage nnchat:s n[9] set compute default float nnchat:l0_n1_9
data modify storage nnchat:s n[10] set compute default float nnchat:l0_n1_10
data modify storage nnchat:s n[11] set compute default float nnchat:l0_n1_11
data modify storage nnchat:s n[12] set compute default float nnchat:l0_n1_12
data modify storage nnchat:s n[13] set compute default float nnchat:l0_n1_13
data modify storage nnchat:s n[14] set compute default float nnchat:l0_n1_14
data modify storage nnchat:s n[15] set compute default float nnchat:l0_n1_15
data modify storage nnchat:s n[16] set compute default float nnchat:l0_n1_16
data modify storage nnchat:s n[17] set compute default float nnchat:l0_n1_17
data modify storage nnchat:s n[18] set compute default float nnchat:l0_n1_18
data modify storage nnchat:s n[19] set compute default float nnchat:l0_n1_19
data modify storage nnchat:s n[20] set compute default float nnchat:l0_n1_20
data modify storage nnchat:s n[21] set compute default float nnchat:l0_n1_21
data modify storage nnchat:s n[22] set compute default float nnchat:l0_n1_22
data modify storage nnchat:s n[23] set compute default float nnchat:l0_n1_23
data modify storage nnchat:s n[24] set compute default float nnchat:l0_n1_24
data modify storage nnchat:s n[25] set compute default float nnchat:l0_n1_25
data modify storage nnchat:s n[26] set compute default float nnchat:l0_n1_26
data modify storage nnchat:s n[27] set compute default float nnchat:l0_n1_27
data modify storage nnchat:s n[28] set compute default float nnchat:l0_n1_28
data modify storage nnchat:s n[29] set compute default float nnchat:l0_n1_29
data modify storage nnchat:s n[30] set compute default float nnchat:l0_n1_30
data modify storage nnchat:s n[31] set compute default float nnchat:l0_n1_31
data modify storage nnchat:s n[32] set compute default float nnchat:l0_n1_32
data modify storage nnchat:s n[33] set compute default float nnchat:l0_n1_33
data modify storage nnchat:s n[34] set compute default float nnchat:l0_n1_34
data modify storage nnchat:s n[35] set compute default float nnchat:l0_n1_35
data modify storage nnchat:s n[36] set compute default float nnchat:l0_n1_36
data modify storage nnchat:s n[37] set compute default float nnchat:l0_n1_37
data modify storage nnchat:s n[38] set compute default float nnchat:l0_n1_38
data modify storage nnchat:s n[39] set compute default float nnchat:l0_n1_39
data modify storage nnchat:s n[40] set compute default float nnchat:l0_n1_40
data modify storage nnchat:s n[41] set compute default float nnchat:l0_n1_41
data modify storage nnchat:s n[42] set compute default float nnchat:l0_n1_42
data modify storage nnchat:s n[43] set compute default float nnchat:l0_n1_43
data modify storage nnchat:s n[44] set compute default float nnchat:l0_n1_44
data modify storage nnchat:s n[45] set compute default float nnchat:l0_n1_45
data modify storage nnchat:s n[46] set compute default float nnchat:l0_n1_46
data modify storage nnchat:s n[47] set compute default float nnchat:l0_n1_47
data modify storage nnchat:s n[48] set compute default float nnchat:l0_n1_48
data modify storage nnchat:s n[49] set compute default float nnchat:l0_n1_49
data modify storage nnchat:s n[50] set compute default float nnchat:l0_n1_50
data modify storage nnchat:s n[51] set compute default float nnchat:l0_n1_51
data modify storage nnchat:s n[52] set compute default float nnchat:l0_n1_52
data modify storage nnchat:s n[53] set compute default float nnchat:l0_n1_53
data modify storage nnchat:s n[54] set compute default float nnchat:l0_n1_54
data modify storage nnchat:s n[55] set compute default float nnchat:l0_n1_55
data modify storage nnchat:s n[56] set compute default float nnchat:l0_n1_56
data modify storage nnchat:s n[57] set compute default float nnchat:l0_n1_57
data modify storage nnchat:s n[58] set compute default float nnchat:l0_n1_58
data modify storage nnchat:s n[59] set compute default float nnchat:l0_n1_59
data modify storage nnchat:s n[60] set compute default float nnchat:l0_n1_60
data modify storage nnchat:s n[61] set compute default float nnchat:l0_n1_61
data modify storage nnchat:s n[62] set compute default float nnchat:l0_n1_62
data modify storage nnchat:s n[63] set compute default float nnchat:l0_n1_63
# --- 层 0: QKV ---
data modify storage nnchat:s q[0] set compute default float nnchat:l0_q_0
data modify storage nnchat:s q[1] set compute default float nnchat:l0_q_1
data modify storage nnchat:s q[2] set compute default float nnchat:l0_q_2
data modify storage nnchat:s q[3] set compute default float nnchat:l0_q_3
data modify storage nnchat:s q[4] set compute default float nnchat:l0_q_4
data modify storage nnchat:s q[5] set compute default float nnchat:l0_q_5
data modify storage nnchat:s q[6] set compute default float nnchat:l0_q_6
data modify storage nnchat:s q[7] set compute default float nnchat:l0_q_7
data modify storage nnchat:s q[8] set compute default float nnchat:l0_q_8
data modify storage nnchat:s q[9] set compute default float nnchat:l0_q_9
data modify storage nnchat:s q[10] set compute default float nnchat:l0_q_10
data modify storage nnchat:s q[11] set compute default float nnchat:l0_q_11
data modify storage nnchat:s q[12] set compute default float nnchat:l0_q_12
data modify storage nnchat:s q[13] set compute default float nnchat:l0_q_13
data modify storage nnchat:s q[14] set compute default float nnchat:l0_q_14
data modify storage nnchat:s q[15] set compute default float nnchat:l0_q_15
data modify storage nnchat:s q[16] set compute default float nnchat:l0_q_16
data modify storage nnchat:s q[17] set compute default float nnchat:l0_q_17
data modify storage nnchat:s q[18] set compute default float nnchat:l0_q_18
data modify storage nnchat:s q[19] set compute default float nnchat:l0_q_19
data modify storage nnchat:s q[20] set compute default float nnchat:l0_q_20
data modify storage nnchat:s q[21] set compute default float nnchat:l0_q_21
data modify storage nnchat:s q[22] set compute default float nnchat:l0_q_22
data modify storage nnchat:s q[23] set compute default float nnchat:l0_q_23
data modify storage nnchat:s q[24] set compute default float nnchat:l0_q_24
data modify storage nnchat:s q[25] set compute default float nnchat:l0_q_25
data modify storage nnchat:s q[26] set compute default float nnchat:l0_q_26
data modify storage nnchat:s q[27] set compute default float nnchat:l0_q_27
data modify storage nnchat:s q[28] set compute default float nnchat:l0_q_28
data modify storage nnchat:s q[29] set compute default float nnchat:l0_q_29
data modify storage nnchat:s q[30] set compute default float nnchat:l0_q_30
data modify storage nnchat:s q[31] set compute default float nnchat:l0_q_31
data modify storage nnchat:s q[32] set compute default float nnchat:l0_q_32
data modify storage nnchat:s q[33] set compute default float nnchat:l0_q_33
data modify storage nnchat:s q[34] set compute default float nnchat:l0_q_34
data modify storage nnchat:s q[35] set compute default float nnchat:l0_q_35
data modify storage nnchat:s q[36] set compute default float nnchat:l0_q_36
data modify storage nnchat:s q[37] set compute default float nnchat:l0_q_37
data modify storage nnchat:s q[38] set compute default float nnchat:l0_q_38
data modify storage nnchat:s q[39] set compute default float nnchat:l0_q_39
data modify storage nnchat:s q[40] set compute default float nnchat:l0_q_40
data modify storage nnchat:s q[41] set compute default float nnchat:l0_q_41
data modify storage nnchat:s q[42] set compute default float nnchat:l0_q_42
data modify storage nnchat:s q[43] set compute default float nnchat:l0_q_43
data modify storage nnchat:s q[44] set compute default float nnchat:l0_q_44
data modify storage nnchat:s q[45] set compute default float nnchat:l0_q_45
data modify storage nnchat:s q[46] set compute default float nnchat:l0_q_46
data modify storage nnchat:s q[47] set compute default float nnchat:l0_q_47
data modify storage nnchat:s q[48] set compute default float nnchat:l0_q_48
data modify storage nnchat:s q[49] set compute default float nnchat:l0_q_49
data modify storage nnchat:s q[50] set compute default float nnchat:l0_q_50
data modify storage nnchat:s q[51] set compute default float nnchat:l0_q_51
data modify storage nnchat:s q[52] set compute default float nnchat:l0_q_52
data modify storage nnchat:s q[53] set compute default float nnchat:l0_q_53
data modify storage nnchat:s q[54] set compute default float nnchat:l0_q_54
data modify storage nnchat:s q[55] set compute default float nnchat:l0_q_55
data modify storage nnchat:s q[56] set compute default float nnchat:l0_q_56
data modify storage nnchat:s q[57] set compute default float nnchat:l0_q_57
data modify storage nnchat:s q[58] set compute default float nnchat:l0_q_58
data modify storage nnchat:s q[59] set compute default float nnchat:l0_q_59
data modify storage nnchat:s q[60] set compute default float nnchat:l0_q_60
data modify storage nnchat:s q[61] set compute default float nnchat:l0_q_61
data modify storage nnchat:s q[62] set compute default float nnchat:l0_q_62
data modify storage nnchat:s q[63] set compute default float nnchat:l0_q_63
data modify storage nnchat:s k[0] set compute default float nnchat:l0_k_0
data modify storage nnchat:s k[1] set compute default float nnchat:l0_k_1
data modify storage nnchat:s k[2] set compute default float nnchat:l0_k_2
data modify storage nnchat:s k[3] set compute default float nnchat:l0_k_3
data modify storage nnchat:s k[4] set compute default float nnchat:l0_k_4
data modify storage nnchat:s k[5] set compute default float nnchat:l0_k_5
data modify storage nnchat:s k[6] set compute default float nnchat:l0_k_6
data modify storage nnchat:s k[7] set compute default float nnchat:l0_k_7
data modify storage nnchat:s k[8] set compute default float nnchat:l0_k_8
data modify storage nnchat:s k[9] set compute default float nnchat:l0_k_9
data modify storage nnchat:s k[10] set compute default float nnchat:l0_k_10
data modify storage nnchat:s k[11] set compute default float nnchat:l0_k_11
data modify storage nnchat:s k[12] set compute default float nnchat:l0_k_12
data modify storage nnchat:s k[13] set compute default float nnchat:l0_k_13
data modify storage nnchat:s k[14] set compute default float nnchat:l0_k_14
data modify storage nnchat:s k[15] set compute default float nnchat:l0_k_15
data modify storage nnchat:s k[16] set compute default float nnchat:l0_k_16
data modify storage nnchat:s k[17] set compute default float nnchat:l0_k_17
data modify storage nnchat:s k[18] set compute default float nnchat:l0_k_18
data modify storage nnchat:s k[19] set compute default float nnchat:l0_k_19
data modify storage nnchat:s k[20] set compute default float nnchat:l0_k_20
data modify storage nnchat:s k[21] set compute default float nnchat:l0_k_21
data modify storage nnchat:s k[22] set compute default float nnchat:l0_k_22
data modify storage nnchat:s k[23] set compute default float nnchat:l0_k_23
data modify storage nnchat:s k[24] set compute default float nnchat:l0_k_24
data modify storage nnchat:s k[25] set compute default float nnchat:l0_k_25
data modify storage nnchat:s k[26] set compute default float nnchat:l0_k_26
data modify storage nnchat:s k[27] set compute default float nnchat:l0_k_27
data modify storage nnchat:s k[28] set compute default float nnchat:l0_k_28
data modify storage nnchat:s k[29] set compute default float nnchat:l0_k_29
data modify storage nnchat:s k[30] set compute default float nnchat:l0_k_30
data modify storage nnchat:s k[31] set compute default float nnchat:l0_k_31
data modify storage nnchat:s k[32] set compute default float nnchat:l0_k_32
data modify storage nnchat:s k[33] set compute default float nnchat:l0_k_33
data modify storage nnchat:s k[34] set compute default float nnchat:l0_k_34
data modify storage nnchat:s k[35] set compute default float nnchat:l0_k_35
data modify storage nnchat:s k[36] set compute default float nnchat:l0_k_36
data modify storage nnchat:s k[37] set compute default float nnchat:l0_k_37
data modify storage nnchat:s k[38] set compute default float nnchat:l0_k_38
data modify storage nnchat:s k[39] set compute default float nnchat:l0_k_39
data modify storage nnchat:s k[40] set compute default float nnchat:l0_k_40
data modify storage nnchat:s k[41] set compute default float nnchat:l0_k_41
data modify storage nnchat:s k[42] set compute default float nnchat:l0_k_42
data modify storage nnchat:s k[43] set compute default float nnchat:l0_k_43
data modify storage nnchat:s k[44] set compute default float nnchat:l0_k_44
data modify storage nnchat:s k[45] set compute default float nnchat:l0_k_45
data modify storage nnchat:s k[46] set compute default float nnchat:l0_k_46
data modify storage nnchat:s k[47] set compute default float nnchat:l0_k_47
data modify storage nnchat:s k[48] set compute default float nnchat:l0_k_48
data modify storage nnchat:s k[49] set compute default float nnchat:l0_k_49
data modify storage nnchat:s k[50] set compute default float nnchat:l0_k_50
data modify storage nnchat:s k[51] set compute default float nnchat:l0_k_51
data modify storage nnchat:s k[52] set compute default float nnchat:l0_k_52
data modify storage nnchat:s k[53] set compute default float nnchat:l0_k_53
data modify storage nnchat:s k[54] set compute default float nnchat:l0_k_54
data modify storage nnchat:s k[55] set compute default float nnchat:l0_k_55
data modify storage nnchat:s k[56] set compute default float nnchat:l0_k_56
data modify storage nnchat:s k[57] set compute default float nnchat:l0_k_57
data modify storage nnchat:s k[58] set compute default float nnchat:l0_k_58
data modify storage nnchat:s k[59] set compute default float nnchat:l0_k_59
data modify storage nnchat:s k[60] set compute default float nnchat:l0_k_60
data modify storage nnchat:s k[61] set compute default float nnchat:l0_k_61
data modify storage nnchat:s k[62] set compute default float nnchat:l0_k_62
data modify storage nnchat:s k[63] set compute default float nnchat:l0_k_63
data modify storage nnchat:s v[0] set compute default float nnchat:l0_v_0
data modify storage nnchat:s v[1] set compute default float nnchat:l0_v_1
data modify storage nnchat:s v[2] set compute default float nnchat:l0_v_2
data modify storage nnchat:s v[3] set compute default float nnchat:l0_v_3
data modify storage nnchat:s v[4] set compute default float nnchat:l0_v_4
data modify storage nnchat:s v[5] set compute default float nnchat:l0_v_5
data modify storage nnchat:s v[6] set compute default float nnchat:l0_v_6
data modify storage nnchat:s v[7] set compute default float nnchat:l0_v_7
data modify storage nnchat:s v[8] set compute default float nnchat:l0_v_8
data modify storage nnchat:s v[9] set compute default float nnchat:l0_v_9
data modify storage nnchat:s v[10] set compute default float nnchat:l0_v_10
data modify storage nnchat:s v[11] set compute default float nnchat:l0_v_11
data modify storage nnchat:s v[12] set compute default float nnchat:l0_v_12
data modify storage nnchat:s v[13] set compute default float nnchat:l0_v_13
data modify storage nnchat:s v[14] set compute default float nnchat:l0_v_14
data modify storage nnchat:s v[15] set compute default float nnchat:l0_v_15
data modify storage nnchat:s v[16] set compute default float nnchat:l0_v_16
data modify storage nnchat:s v[17] set compute default float nnchat:l0_v_17
data modify storage nnchat:s v[18] set compute default float nnchat:l0_v_18
data modify storage nnchat:s v[19] set compute default float nnchat:l0_v_19
data modify storage nnchat:s v[20] set compute default float nnchat:l0_v_20
data modify storage nnchat:s v[21] set compute default float nnchat:l0_v_21
data modify storage nnchat:s v[22] set compute default float nnchat:l0_v_22
data modify storage nnchat:s v[23] set compute default float nnchat:l0_v_23
data modify storage nnchat:s v[24] set compute default float nnchat:l0_v_24
data modify storage nnchat:s v[25] set compute default float nnchat:l0_v_25
data modify storage nnchat:s v[26] set compute default float nnchat:l0_v_26
data modify storage nnchat:s v[27] set compute default float nnchat:l0_v_27
data modify storage nnchat:s v[28] set compute default float nnchat:l0_v_28
data modify storage nnchat:s v[29] set compute default float nnchat:l0_v_29
data modify storage nnchat:s v[30] set compute default float nnchat:l0_v_30
data modify storage nnchat:s v[31] set compute default float nnchat:l0_v_31
data modify storage nnchat:s v[32] set compute default float nnchat:l0_v_32
data modify storage nnchat:s v[33] set compute default float nnchat:l0_v_33
data modify storage nnchat:s v[34] set compute default float nnchat:l0_v_34
data modify storage nnchat:s v[35] set compute default float nnchat:l0_v_35
data modify storage nnchat:s v[36] set compute default float nnchat:l0_v_36
data modify storage nnchat:s v[37] set compute default float nnchat:l0_v_37
data modify storage nnchat:s v[38] set compute default float nnchat:l0_v_38
data modify storage nnchat:s v[39] set compute default float nnchat:l0_v_39
data modify storage nnchat:s v[40] set compute default float nnchat:l0_v_40
data modify storage nnchat:s v[41] set compute default float nnchat:l0_v_41
data modify storage nnchat:s v[42] set compute default float nnchat:l0_v_42
data modify storage nnchat:s v[43] set compute default float nnchat:l0_v_43
data modify storage nnchat:s v[44] set compute default float nnchat:l0_v_44
data modify storage nnchat:s v[45] set compute default float nnchat:l0_v_45
data modify storage nnchat:s v[46] set compute default float nnchat:l0_v_46
data modify storage nnchat:s v[47] set compute default float nnchat:l0_v_47
data modify storage nnchat:s v[48] set compute default float nnchat:l0_v_48
data modify storage nnchat:s v[49] set compute default float nnchat:l0_v_49
data modify storage nnchat:s v[50] set compute default float nnchat:l0_v_50
data modify storage nnchat:s v[51] set compute default float nnchat:l0_v_51
data modify storage nnchat:s v[52] set compute default float nnchat:l0_v_52
data modify storage nnchat:s v[53] set compute default float nnchat:l0_v_53
data modify storage nnchat:s v[54] set compute default float nnchat:l0_v_54
data modify storage nnchat:s v[55] set compute default float nnchat:l0_v_55
data modify storage nnchat:s v[56] set compute default float nnchat:l0_v_56
data modify storage nnchat:s v[57] set compute default float nnchat:l0_v_57
data modify storage nnchat:s v[58] set compute default float nnchat:l0_v_58
data modify storage nnchat:s v[59] set compute default float nnchat:l0_v_59
data modify storage nnchat:s v[60] set compute default float nnchat:l0_v_60
data modify storage nnchat:s v[61] set compute default float nnchat:l0_v_61
data modify storage nnchat:s v[62] set compute default float nnchat:l0_v_62
data modify storage nnchat:s v[63] set compute default float nnchat:l0_v_63
data modify storage nnchat:s kc0 append from storage nnchat:s k
data modify storage nnchat:s vc0 append from storage nnchat:s v
# --- 层 0: 注意力 ---
data modify storage nnchat:s s0[0] set compute default float nnchat:l0_s0_0
data modify storage nnchat:s s0[1] set compute default float nnchat:l0_s0_1
data modify storage nnchat:s s0[2] set compute default float nnchat:l0_s0_2
data modify storage nnchat:s s0[3] set compute default float nnchat:l0_s0_3
data modify storage nnchat:s s0[4] set compute default float nnchat:l0_s0_4
data modify storage nnchat:s s0[5] set compute default float nnchat:l0_s0_5
data modify storage nnchat:s s0[6] set compute default float nnchat:l0_s0_6
data modify storage nnchat:s s0[7] set compute default float nnchat:l0_s0_7
data modify storage nnchat:s s0[8] set compute default float nnchat:l0_s0_8
data modify storage nnchat:s s0[9] set compute default float nnchat:l0_s0_9
data modify storage nnchat:s s0[10] set compute default float nnchat:l0_s0_10
data modify storage nnchat:s s0[11] set compute default float nnchat:l0_s0_11
data modify storage nnchat:s s0[12] set compute default float nnchat:l0_s0_12
data modify storage nnchat:s s0[13] set compute default float nnchat:l0_s0_13
data modify storage nnchat:s s0[14] set compute default float nnchat:l0_s0_14
data modify storage nnchat:s s0[15] set compute default float nnchat:l0_s0_15
data modify storage nnchat:s s0[16] set compute default float nnchat:l0_s0_16
data modify storage nnchat:s s0[17] set compute default float nnchat:l0_s0_17
data modify storage nnchat:s s0[18] set compute default float nnchat:l0_s0_18
data modify storage nnchat:s s0[19] set compute default float nnchat:l0_s0_19
data modify storage nnchat:s s0[20] set compute default float nnchat:l0_s0_20
data modify storage nnchat:s s0[21] set compute default float nnchat:l0_s0_21
data modify storage nnchat:s s0[22] set compute default float nnchat:l0_s0_22
data modify storage nnchat:s s0[23] set compute default float nnchat:l0_s0_23
data modify storage nnchat:s s0[24] set compute default float nnchat:l0_s0_24
data modify storage nnchat:s s0[25] set compute default float nnchat:l0_s0_25
data modify storage nnchat:s s0[26] set compute default float nnchat:l0_s0_26
data modify storage nnchat:s s0[27] set compute default float nnchat:l0_s0_27
data modify storage nnchat:s s0[28] set compute default float nnchat:l0_s0_28
data modify storage nnchat:s s0[29] set compute default float nnchat:l0_s0_29
data modify storage nnchat:s s0[30] set compute default float nnchat:l0_s0_30
data modify storage nnchat:s s0[31] set compute default float nnchat:l0_s0_31
data modify storage nnchat:s s0[32] set compute default float nnchat:l0_s0_32
data modify storage nnchat:s s0[33] set compute default float nnchat:l0_s0_33
data modify storage nnchat:s s0[34] set compute default float nnchat:l0_s0_34
data modify storage nnchat:s s0[35] set compute default float nnchat:l0_s0_35
data modify storage nnchat:s s0[36] set compute default float nnchat:l0_s0_36
data modify storage nnchat:s s0[37] set compute default float nnchat:l0_s0_37
data modify storage nnchat:s s0[38] set compute default float nnchat:l0_s0_38
data modify storage nnchat:s s0[39] set compute default float nnchat:l0_s0_39
data modify storage nnchat:s s0[40] set compute default float nnchat:l0_s0_40
data modify storage nnchat:s s0[41] set compute default float nnchat:l0_s0_41
data modify storage nnchat:s s0[42] set compute default float nnchat:l0_s0_42
data modify storage nnchat:s s0[43] set compute default float nnchat:l0_s0_43
data modify storage nnchat:s s0[44] set compute default float nnchat:l0_s0_44
data modify storage nnchat:s s0[45] set compute default float nnchat:l0_s0_45
data modify storage nnchat:s s0[46] set compute default float nnchat:l0_s0_46
data modify storage nnchat:s s0[47] set compute default float nnchat:l0_s0_47
data modify storage nnchat:s s0[48] set compute default float nnchat:l0_s0_48
data modify storage nnchat:s s0[49] set compute default float nnchat:l0_s0_49
data modify storage nnchat:s s0[50] set compute default float nnchat:l0_s0_50
data modify storage nnchat:s s0[51] set compute default float nnchat:l0_s0_51
data modify storage nnchat:s s0[52] set compute default float nnchat:l0_s0_52
data modify storage nnchat:s s0[53] set compute default float nnchat:l0_s0_53
data modify storage nnchat:s s0[54] set compute default float nnchat:l0_s0_54
data modify storage nnchat:s s0[55] set compute default float nnchat:l0_s0_55
data modify storage nnchat:s s0[56] set compute default float nnchat:l0_s0_56
data modify storage nnchat:s s0[57] set compute default float nnchat:l0_s0_57
data modify storage nnchat:s s0[58] set compute default float nnchat:l0_s0_58
data modify storage nnchat:s s0[59] set compute default float nnchat:l0_s0_59
data modify storage nnchat:s s0[60] set compute default float nnchat:l0_s0_60
data modify storage nnchat:s s0[61] set compute default float nnchat:l0_s0_61
data modify storage nnchat:s s0[62] set compute default float nnchat:l0_s0_62
data modify storage nnchat:s s0[63] set compute default float nnchat:l0_s0_63
data modify storage nnchat:s s1[0] set compute default float nnchat:l0_s1_0
data modify storage nnchat:s s1[1] set compute default float nnchat:l0_s1_1
data modify storage nnchat:s s1[2] set compute default float nnchat:l0_s1_2
data modify storage nnchat:s s1[3] set compute default float nnchat:l0_s1_3
data modify storage nnchat:s s1[4] set compute default float nnchat:l0_s1_4
data modify storage nnchat:s s1[5] set compute default float nnchat:l0_s1_5
data modify storage nnchat:s s1[6] set compute default float nnchat:l0_s1_6
data modify storage nnchat:s s1[7] set compute default float nnchat:l0_s1_7
data modify storage nnchat:s s1[8] set compute default float nnchat:l0_s1_8
data modify storage nnchat:s s1[9] set compute default float nnchat:l0_s1_9
data modify storage nnchat:s s1[10] set compute default float nnchat:l0_s1_10
data modify storage nnchat:s s1[11] set compute default float nnchat:l0_s1_11
data modify storage nnchat:s s1[12] set compute default float nnchat:l0_s1_12
data modify storage nnchat:s s1[13] set compute default float nnchat:l0_s1_13
data modify storage nnchat:s s1[14] set compute default float nnchat:l0_s1_14
data modify storage nnchat:s s1[15] set compute default float nnchat:l0_s1_15
data modify storage nnchat:s s1[16] set compute default float nnchat:l0_s1_16
data modify storage nnchat:s s1[17] set compute default float nnchat:l0_s1_17
data modify storage nnchat:s s1[18] set compute default float nnchat:l0_s1_18
data modify storage nnchat:s s1[19] set compute default float nnchat:l0_s1_19
data modify storage nnchat:s s1[20] set compute default float nnchat:l0_s1_20
data modify storage nnchat:s s1[21] set compute default float nnchat:l0_s1_21
data modify storage nnchat:s s1[22] set compute default float nnchat:l0_s1_22
data modify storage nnchat:s s1[23] set compute default float nnchat:l0_s1_23
data modify storage nnchat:s s1[24] set compute default float nnchat:l0_s1_24
data modify storage nnchat:s s1[25] set compute default float nnchat:l0_s1_25
data modify storage nnchat:s s1[26] set compute default float nnchat:l0_s1_26
data modify storage nnchat:s s1[27] set compute default float nnchat:l0_s1_27
data modify storage nnchat:s s1[28] set compute default float nnchat:l0_s1_28
data modify storage nnchat:s s1[29] set compute default float nnchat:l0_s1_29
data modify storage nnchat:s s1[30] set compute default float nnchat:l0_s1_30
data modify storage nnchat:s s1[31] set compute default float nnchat:l0_s1_31
data modify storage nnchat:s s1[32] set compute default float nnchat:l0_s1_32
data modify storage nnchat:s s1[33] set compute default float nnchat:l0_s1_33
data modify storage nnchat:s s1[34] set compute default float nnchat:l0_s1_34
data modify storage nnchat:s s1[35] set compute default float nnchat:l0_s1_35
data modify storage nnchat:s s1[36] set compute default float nnchat:l0_s1_36
data modify storage nnchat:s s1[37] set compute default float nnchat:l0_s1_37
data modify storage nnchat:s s1[38] set compute default float nnchat:l0_s1_38
data modify storage nnchat:s s1[39] set compute default float nnchat:l0_s1_39
data modify storage nnchat:s s1[40] set compute default float nnchat:l0_s1_40
data modify storage nnchat:s s1[41] set compute default float nnchat:l0_s1_41
data modify storage nnchat:s s1[42] set compute default float nnchat:l0_s1_42
data modify storage nnchat:s s1[43] set compute default float nnchat:l0_s1_43
data modify storage nnchat:s s1[44] set compute default float nnchat:l0_s1_44
data modify storage nnchat:s s1[45] set compute default float nnchat:l0_s1_45
data modify storage nnchat:s s1[46] set compute default float nnchat:l0_s1_46
data modify storage nnchat:s s1[47] set compute default float nnchat:l0_s1_47
data modify storage nnchat:s s1[48] set compute default float nnchat:l0_s1_48
data modify storage nnchat:s s1[49] set compute default float nnchat:l0_s1_49
data modify storage nnchat:s s1[50] set compute default float nnchat:l0_s1_50
data modify storage nnchat:s s1[51] set compute default float nnchat:l0_s1_51
data modify storage nnchat:s s1[52] set compute default float nnchat:l0_s1_52
data modify storage nnchat:s s1[53] set compute default float nnchat:l0_s1_53
data modify storage nnchat:s s1[54] set compute default float nnchat:l0_s1_54
data modify storage nnchat:s s1[55] set compute default float nnchat:l0_s1_55
data modify storage nnchat:s s1[56] set compute default float nnchat:l0_s1_56
data modify storage nnchat:s s1[57] set compute default float nnchat:l0_s1_57
data modify storage nnchat:s s1[58] set compute default float nnchat:l0_s1_58
data modify storage nnchat:s s1[59] set compute default float nnchat:l0_s1_59
data modify storage nnchat:s s1[60] set compute default float nnchat:l0_s1_60
data modify storage nnchat:s s1[61] set compute default float nnchat:l0_s1_61
data modify storage nnchat:s s1[62] set compute default float nnchat:l0_s1_62
data modify storage nnchat:s s1[63] set compute default float nnchat:l0_s1_63
data modify storage nnchat:s mx0 set compute default float nnchat:l0_mx0
data modify storage nnchat:s mx1 set compute default float nnchat:l0_mx1
data modify storage nnchat:s e0[0] set compute default float nnchat:l0_e0_0
data modify storage nnchat:s e0[1] set compute default float nnchat:l0_e0_1
data modify storage nnchat:s e0[2] set compute default float nnchat:l0_e0_2
data modify storage nnchat:s e0[3] set compute default float nnchat:l0_e0_3
data modify storage nnchat:s e0[4] set compute default float nnchat:l0_e0_4
data modify storage nnchat:s e0[5] set compute default float nnchat:l0_e0_5
data modify storage nnchat:s e0[6] set compute default float nnchat:l0_e0_6
data modify storage nnchat:s e0[7] set compute default float nnchat:l0_e0_7
data modify storage nnchat:s e0[8] set compute default float nnchat:l0_e0_8
data modify storage nnchat:s e0[9] set compute default float nnchat:l0_e0_9
data modify storage nnchat:s e0[10] set compute default float nnchat:l0_e0_10
data modify storage nnchat:s e0[11] set compute default float nnchat:l0_e0_11
data modify storage nnchat:s e0[12] set compute default float nnchat:l0_e0_12
data modify storage nnchat:s e0[13] set compute default float nnchat:l0_e0_13
data modify storage nnchat:s e0[14] set compute default float nnchat:l0_e0_14
data modify storage nnchat:s e0[15] set compute default float nnchat:l0_e0_15
data modify storage nnchat:s e0[16] set compute default float nnchat:l0_e0_16
data modify storage nnchat:s e0[17] set compute default float nnchat:l0_e0_17
data modify storage nnchat:s e0[18] set compute default float nnchat:l0_e0_18
data modify storage nnchat:s e0[19] set compute default float nnchat:l0_e0_19
data modify storage nnchat:s e0[20] set compute default float nnchat:l0_e0_20
data modify storage nnchat:s e0[21] set compute default float nnchat:l0_e0_21
data modify storage nnchat:s e0[22] set compute default float nnchat:l0_e0_22
data modify storage nnchat:s e0[23] set compute default float nnchat:l0_e0_23
data modify storage nnchat:s e0[24] set compute default float nnchat:l0_e0_24
data modify storage nnchat:s e0[25] set compute default float nnchat:l0_e0_25
data modify storage nnchat:s e0[26] set compute default float nnchat:l0_e0_26
data modify storage nnchat:s e0[27] set compute default float nnchat:l0_e0_27
data modify storage nnchat:s e0[28] set compute default float nnchat:l0_e0_28
data modify storage nnchat:s e0[29] set compute default float nnchat:l0_e0_29
data modify storage nnchat:s e0[30] set compute default float nnchat:l0_e0_30
data modify storage nnchat:s e0[31] set compute default float nnchat:l0_e0_31
data modify storage nnchat:s e0[32] set compute default float nnchat:l0_e0_32
data modify storage nnchat:s e0[33] set compute default float nnchat:l0_e0_33
data modify storage nnchat:s e0[34] set compute default float nnchat:l0_e0_34
data modify storage nnchat:s e0[35] set compute default float nnchat:l0_e0_35
data modify storage nnchat:s e0[36] set compute default float nnchat:l0_e0_36
data modify storage nnchat:s e0[37] set compute default float nnchat:l0_e0_37
data modify storage nnchat:s e0[38] set compute default float nnchat:l0_e0_38
data modify storage nnchat:s e0[39] set compute default float nnchat:l0_e0_39
data modify storage nnchat:s e0[40] set compute default float nnchat:l0_e0_40
data modify storage nnchat:s e0[41] set compute default float nnchat:l0_e0_41
data modify storage nnchat:s e0[42] set compute default float nnchat:l0_e0_42
data modify storage nnchat:s e0[43] set compute default float nnchat:l0_e0_43
data modify storage nnchat:s e0[44] set compute default float nnchat:l0_e0_44
data modify storage nnchat:s e0[45] set compute default float nnchat:l0_e0_45
data modify storage nnchat:s e0[46] set compute default float nnchat:l0_e0_46
data modify storage nnchat:s e0[47] set compute default float nnchat:l0_e0_47
data modify storage nnchat:s e0[48] set compute default float nnchat:l0_e0_48
data modify storage nnchat:s e0[49] set compute default float nnchat:l0_e0_49
data modify storage nnchat:s e0[50] set compute default float nnchat:l0_e0_50
data modify storage nnchat:s e0[51] set compute default float nnchat:l0_e0_51
data modify storage nnchat:s e0[52] set compute default float nnchat:l0_e0_52
data modify storage nnchat:s e0[53] set compute default float nnchat:l0_e0_53
data modify storage nnchat:s e0[54] set compute default float nnchat:l0_e0_54
data modify storage nnchat:s e0[55] set compute default float nnchat:l0_e0_55
data modify storage nnchat:s e0[56] set compute default float nnchat:l0_e0_56
data modify storage nnchat:s e0[57] set compute default float nnchat:l0_e0_57
data modify storage nnchat:s e0[58] set compute default float nnchat:l0_e0_58
data modify storage nnchat:s e0[59] set compute default float nnchat:l0_e0_59
data modify storage nnchat:s e0[60] set compute default float nnchat:l0_e0_60
data modify storage nnchat:s e0[61] set compute default float nnchat:l0_e0_61
data modify storage nnchat:s e0[62] set compute default float nnchat:l0_e0_62
data modify storage nnchat:s e0[63] set compute default float nnchat:l0_e0_63
data modify storage nnchat:s e1[0] set compute default float nnchat:l0_e1_0
data modify storage nnchat:s e1[1] set compute default float nnchat:l0_e1_1
data modify storage nnchat:s e1[2] set compute default float nnchat:l0_e1_2
data modify storage nnchat:s e1[3] set compute default float nnchat:l0_e1_3
data modify storage nnchat:s e1[4] set compute default float nnchat:l0_e1_4
data modify storage nnchat:s e1[5] set compute default float nnchat:l0_e1_5
data modify storage nnchat:s e1[6] set compute default float nnchat:l0_e1_6
data modify storage nnchat:s e1[7] set compute default float nnchat:l0_e1_7
data modify storage nnchat:s e1[8] set compute default float nnchat:l0_e1_8
data modify storage nnchat:s e1[9] set compute default float nnchat:l0_e1_9
data modify storage nnchat:s e1[10] set compute default float nnchat:l0_e1_10
data modify storage nnchat:s e1[11] set compute default float nnchat:l0_e1_11
data modify storage nnchat:s e1[12] set compute default float nnchat:l0_e1_12
data modify storage nnchat:s e1[13] set compute default float nnchat:l0_e1_13
data modify storage nnchat:s e1[14] set compute default float nnchat:l0_e1_14
data modify storage nnchat:s e1[15] set compute default float nnchat:l0_e1_15
data modify storage nnchat:s e1[16] set compute default float nnchat:l0_e1_16
data modify storage nnchat:s e1[17] set compute default float nnchat:l0_e1_17
data modify storage nnchat:s e1[18] set compute default float nnchat:l0_e1_18
data modify storage nnchat:s e1[19] set compute default float nnchat:l0_e1_19
data modify storage nnchat:s e1[20] set compute default float nnchat:l0_e1_20
data modify storage nnchat:s e1[21] set compute default float nnchat:l0_e1_21
data modify storage nnchat:s e1[22] set compute default float nnchat:l0_e1_22
data modify storage nnchat:s e1[23] set compute default float nnchat:l0_e1_23
data modify storage nnchat:s e1[24] set compute default float nnchat:l0_e1_24
data modify storage nnchat:s e1[25] set compute default float nnchat:l0_e1_25
data modify storage nnchat:s e1[26] set compute default float nnchat:l0_e1_26
data modify storage nnchat:s e1[27] set compute default float nnchat:l0_e1_27
data modify storage nnchat:s e1[28] set compute default float nnchat:l0_e1_28
data modify storage nnchat:s e1[29] set compute default float nnchat:l0_e1_29
data modify storage nnchat:s e1[30] set compute default float nnchat:l0_e1_30
data modify storage nnchat:s e1[31] set compute default float nnchat:l0_e1_31
data modify storage nnchat:s e1[32] set compute default float nnchat:l0_e1_32
data modify storage nnchat:s e1[33] set compute default float nnchat:l0_e1_33
data modify storage nnchat:s e1[34] set compute default float nnchat:l0_e1_34
data modify storage nnchat:s e1[35] set compute default float nnchat:l0_e1_35
data modify storage nnchat:s e1[36] set compute default float nnchat:l0_e1_36
data modify storage nnchat:s e1[37] set compute default float nnchat:l0_e1_37
data modify storage nnchat:s e1[38] set compute default float nnchat:l0_e1_38
data modify storage nnchat:s e1[39] set compute default float nnchat:l0_e1_39
data modify storage nnchat:s e1[40] set compute default float nnchat:l0_e1_40
data modify storage nnchat:s e1[41] set compute default float nnchat:l0_e1_41
data modify storage nnchat:s e1[42] set compute default float nnchat:l0_e1_42
data modify storage nnchat:s e1[43] set compute default float nnchat:l0_e1_43
data modify storage nnchat:s e1[44] set compute default float nnchat:l0_e1_44
data modify storage nnchat:s e1[45] set compute default float nnchat:l0_e1_45
data modify storage nnchat:s e1[46] set compute default float nnchat:l0_e1_46
data modify storage nnchat:s e1[47] set compute default float nnchat:l0_e1_47
data modify storage nnchat:s e1[48] set compute default float nnchat:l0_e1_48
data modify storage nnchat:s e1[49] set compute default float nnchat:l0_e1_49
data modify storage nnchat:s e1[50] set compute default float nnchat:l0_e1_50
data modify storage nnchat:s e1[51] set compute default float nnchat:l0_e1_51
data modify storage nnchat:s e1[52] set compute default float nnchat:l0_e1_52
data modify storage nnchat:s e1[53] set compute default float nnchat:l0_e1_53
data modify storage nnchat:s e1[54] set compute default float nnchat:l0_e1_54
data modify storage nnchat:s e1[55] set compute default float nnchat:l0_e1_55
data modify storage nnchat:s e1[56] set compute default float nnchat:l0_e1_56
data modify storage nnchat:s e1[57] set compute default float nnchat:l0_e1_57
data modify storage nnchat:s e1[58] set compute default float nnchat:l0_e1_58
data modify storage nnchat:s e1[59] set compute default float nnchat:l0_e1_59
data modify storage nnchat:s e1[60] set compute default float nnchat:l0_e1_60
data modify storage nnchat:s e1[61] set compute default float nnchat:l0_e1_61
data modify storage nnchat:s e1[62] set compute default float nnchat:l0_e1_62
data modify storage nnchat:s e1[63] set compute default float nnchat:l0_e1_63
data modify storage nnchat:s dn0 set compute default float nnchat:l0_dn0
data modify storage nnchat:s dn1 set compute default float nnchat:l0_dn1
data modify storage nnchat:s p0[0] set compute default float nnchat:l0_p0_0
data modify storage nnchat:s p0[1] set compute default float nnchat:l0_p0_1
data modify storage nnchat:s p0[2] set compute default float nnchat:l0_p0_2
data modify storage nnchat:s p0[3] set compute default float nnchat:l0_p0_3
data modify storage nnchat:s p0[4] set compute default float nnchat:l0_p0_4
data modify storage nnchat:s p0[5] set compute default float nnchat:l0_p0_5
data modify storage nnchat:s p0[6] set compute default float nnchat:l0_p0_6
data modify storage nnchat:s p0[7] set compute default float nnchat:l0_p0_7
data modify storage nnchat:s p0[8] set compute default float nnchat:l0_p0_8
data modify storage nnchat:s p0[9] set compute default float nnchat:l0_p0_9
data modify storage nnchat:s p0[10] set compute default float nnchat:l0_p0_10
data modify storage nnchat:s p0[11] set compute default float nnchat:l0_p0_11
data modify storage nnchat:s p0[12] set compute default float nnchat:l0_p0_12
data modify storage nnchat:s p0[13] set compute default float nnchat:l0_p0_13
data modify storage nnchat:s p0[14] set compute default float nnchat:l0_p0_14
data modify storage nnchat:s p0[15] set compute default float nnchat:l0_p0_15
data modify storage nnchat:s p0[16] set compute default float nnchat:l0_p0_16
data modify storage nnchat:s p0[17] set compute default float nnchat:l0_p0_17
data modify storage nnchat:s p0[18] set compute default float nnchat:l0_p0_18
data modify storage nnchat:s p0[19] set compute default float nnchat:l0_p0_19
data modify storage nnchat:s p0[20] set compute default float nnchat:l0_p0_20
data modify storage nnchat:s p0[21] set compute default float nnchat:l0_p0_21
data modify storage nnchat:s p0[22] set compute default float nnchat:l0_p0_22
data modify storage nnchat:s p0[23] set compute default float nnchat:l0_p0_23
data modify storage nnchat:s p0[24] set compute default float nnchat:l0_p0_24
data modify storage nnchat:s p0[25] set compute default float nnchat:l0_p0_25
data modify storage nnchat:s p0[26] set compute default float nnchat:l0_p0_26
data modify storage nnchat:s p0[27] set compute default float nnchat:l0_p0_27
data modify storage nnchat:s p0[28] set compute default float nnchat:l0_p0_28
data modify storage nnchat:s p0[29] set compute default float nnchat:l0_p0_29
data modify storage nnchat:s p0[30] set compute default float nnchat:l0_p0_30
data modify storage nnchat:s p0[31] set compute default float nnchat:l0_p0_31
data modify storage nnchat:s p0[32] set compute default float nnchat:l0_p0_32
data modify storage nnchat:s p0[33] set compute default float nnchat:l0_p0_33
data modify storage nnchat:s p0[34] set compute default float nnchat:l0_p0_34
data modify storage nnchat:s p0[35] set compute default float nnchat:l0_p0_35
data modify storage nnchat:s p0[36] set compute default float nnchat:l0_p0_36
data modify storage nnchat:s p0[37] set compute default float nnchat:l0_p0_37
data modify storage nnchat:s p0[38] set compute default float nnchat:l0_p0_38
data modify storage nnchat:s p0[39] set compute default float nnchat:l0_p0_39
data modify storage nnchat:s p0[40] set compute default float nnchat:l0_p0_40
data modify storage nnchat:s p0[41] set compute default float nnchat:l0_p0_41
data modify storage nnchat:s p0[42] set compute default float nnchat:l0_p0_42
data modify storage nnchat:s p0[43] set compute default float nnchat:l0_p0_43
data modify storage nnchat:s p0[44] set compute default float nnchat:l0_p0_44
data modify storage nnchat:s p0[45] set compute default float nnchat:l0_p0_45
data modify storage nnchat:s p0[46] set compute default float nnchat:l0_p0_46
data modify storage nnchat:s p0[47] set compute default float nnchat:l0_p0_47
data modify storage nnchat:s p0[48] set compute default float nnchat:l0_p0_48
data modify storage nnchat:s p0[49] set compute default float nnchat:l0_p0_49
data modify storage nnchat:s p0[50] set compute default float nnchat:l0_p0_50
data modify storage nnchat:s p0[51] set compute default float nnchat:l0_p0_51
data modify storage nnchat:s p0[52] set compute default float nnchat:l0_p0_52
data modify storage nnchat:s p0[53] set compute default float nnchat:l0_p0_53
data modify storage nnchat:s p0[54] set compute default float nnchat:l0_p0_54
data modify storage nnchat:s p0[55] set compute default float nnchat:l0_p0_55
data modify storage nnchat:s p0[56] set compute default float nnchat:l0_p0_56
data modify storage nnchat:s p0[57] set compute default float nnchat:l0_p0_57
data modify storage nnchat:s p0[58] set compute default float nnchat:l0_p0_58
data modify storage nnchat:s p0[59] set compute default float nnchat:l0_p0_59
data modify storage nnchat:s p0[60] set compute default float nnchat:l0_p0_60
data modify storage nnchat:s p0[61] set compute default float nnchat:l0_p0_61
data modify storage nnchat:s p0[62] set compute default float nnchat:l0_p0_62
data modify storage nnchat:s p0[63] set compute default float nnchat:l0_p0_63
data modify storage nnchat:s p1[0] set compute default float nnchat:l0_p1_0
data modify storage nnchat:s p1[1] set compute default float nnchat:l0_p1_1
data modify storage nnchat:s p1[2] set compute default float nnchat:l0_p1_2
data modify storage nnchat:s p1[3] set compute default float nnchat:l0_p1_3
data modify storage nnchat:s p1[4] set compute default float nnchat:l0_p1_4
data modify storage nnchat:s p1[5] set compute default float nnchat:l0_p1_5
data modify storage nnchat:s p1[6] set compute default float nnchat:l0_p1_6
data modify storage nnchat:s p1[7] set compute default float nnchat:l0_p1_7
data modify storage nnchat:s p1[8] set compute default float nnchat:l0_p1_8
data modify storage nnchat:s p1[9] set compute default float nnchat:l0_p1_9
data modify storage nnchat:s p1[10] set compute default float nnchat:l0_p1_10
data modify storage nnchat:s p1[11] set compute default float nnchat:l0_p1_11
data modify storage nnchat:s p1[12] set compute default float nnchat:l0_p1_12
data modify storage nnchat:s p1[13] set compute default float nnchat:l0_p1_13
data modify storage nnchat:s p1[14] set compute default float nnchat:l0_p1_14
data modify storage nnchat:s p1[15] set compute default float nnchat:l0_p1_15
data modify storage nnchat:s p1[16] set compute default float nnchat:l0_p1_16
data modify storage nnchat:s p1[17] set compute default float nnchat:l0_p1_17
data modify storage nnchat:s p1[18] set compute default float nnchat:l0_p1_18
data modify storage nnchat:s p1[19] set compute default float nnchat:l0_p1_19
data modify storage nnchat:s p1[20] set compute default float nnchat:l0_p1_20
data modify storage nnchat:s p1[21] set compute default float nnchat:l0_p1_21
data modify storage nnchat:s p1[22] set compute default float nnchat:l0_p1_22
data modify storage nnchat:s p1[23] set compute default float nnchat:l0_p1_23
data modify storage nnchat:s p1[24] set compute default float nnchat:l0_p1_24
data modify storage nnchat:s p1[25] set compute default float nnchat:l0_p1_25
data modify storage nnchat:s p1[26] set compute default float nnchat:l0_p1_26
data modify storage nnchat:s p1[27] set compute default float nnchat:l0_p1_27
data modify storage nnchat:s p1[28] set compute default float nnchat:l0_p1_28
data modify storage nnchat:s p1[29] set compute default float nnchat:l0_p1_29
data modify storage nnchat:s p1[30] set compute default float nnchat:l0_p1_30
data modify storage nnchat:s p1[31] set compute default float nnchat:l0_p1_31
data modify storage nnchat:s p1[32] set compute default float nnchat:l0_p1_32
data modify storage nnchat:s p1[33] set compute default float nnchat:l0_p1_33
data modify storage nnchat:s p1[34] set compute default float nnchat:l0_p1_34
data modify storage nnchat:s p1[35] set compute default float nnchat:l0_p1_35
data modify storage nnchat:s p1[36] set compute default float nnchat:l0_p1_36
data modify storage nnchat:s p1[37] set compute default float nnchat:l0_p1_37
data modify storage nnchat:s p1[38] set compute default float nnchat:l0_p1_38
data modify storage nnchat:s p1[39] set compute default float nnchat:l0_p1_39
data modify storage nnchat:s p1[40] set compute default float nnchat:l0_p1_40
data modify storage nnchat:s p1[41] set compute default float nnchat:l0_p1_41
data modify storage nnchat:s p1[42] set compute default float nnchat:l0_p1_42
data modify storage nnchat:s p1[43] set compute default float nnchat:l0_p1_43
data modify storage nnchat:s p1[44] set compute default float nnchat:l0_p1_44
data modify storage nnchat:s p1[45] set compute default float nnchat:l0_p1_45
data modify storage nnchat:s p1[46] set compute default float nnchat:l0_p1_46
data modify storage nnchat:s p1[47] set compute default float nnchat:l0_p1_47
data modify storage nnchat:s p1[48] set compute default float nnchat:l0_p1_48
data modify storage nnchat:s p1[49] set compute default float nnchat:l0_p1_49
data modify storage nnchat:s p1[50] set compute default float nnchat:l0_p1_50
data modify storage nnchat:s p1[51] set compute default float nnchat:l0_p1_51
data modify storage nnchat:s p1[52] set compute default float nnchat:l0_p1_52
data modify storage nnchat:s p1[53] set compute default float nnchat:l0_p1_53
data modify storage nnchat:s p1[54] set compute default float nnchat:l0_p1_54
data modify storage nnchat:s p1[55] set compute default float nnchat:l0_p1_55
data modify storage nnchat:s p1[56] set compute default float nnchat:l0_p1_56
data modify storage nnchat:s p1[57] set compute default float nnchat:l0_p1_57
data modify storage nnchat:s p1[58] set compute default float nnchat:l0_p1_58
data modify storage nnchat:s p1[59] set compute default float nnchat:l0_p1_59
data modify storage nnchat:s p1[60] set compute default float nnchat:l0_p1_60
data modify storage nnchat:s p1[61] set compute default float nnchat:l0_p1_61
data modify storage nnchat:s p1[62] set compute default float nnchat:l0_p1_62
data modify storage nnchat:s p1[63] set compute default float nnchat:l0_p1_63
data modify storage nnchat:s ao[0] set compute default float nnchat:l0_ao_0
data modify storage nnchat:s ao[1] set compute default float nnchat:l0_ao_1
data modify storage nnchat:s ao[2] set compute default float nnchat:l0_ao_2
data modify storage nnchat:s ao[3] set compute default float nnchat:l0_ao_3
data modify storage nnchat:s ao[4] set compute default float nnchat:l0_ao_4
data modify storage nnchat:s ao[5] set compute default float nnchat:l0_ao_5
data modify storage nnchat:s ao[6] set compute default float nnchat:l0_ao_6
data modify storage nnchat:s ao[7] set compute default float nnchat:l0_ao_7
data modify storage nnchat:s ao[8] set compute default float nnchat:l0_ao_8
data modify storage nnchat:s ao[9] set compute default float nnchat:l0_ao_9
data modify storage nnchat:s ao[10] set compute default float nnchat:l0_ao_10
data modify storage nnchat:s ao[11] set compute default float nnchat:l0_ao_11
data modify storage nnchat:s ao[12] set compute default float nnchat:l0_ao_12
data modify storage nnchat:s ao[13] set compute default float nnchat:l0_ao_13
data modify storage nnchat:s ao[14] set compute default float nnchat:l0_ao_14
data modify storage nnchat:s ao[15] set compute default float nnchat:l0_ao_15
data modify storage nnchat:s ao[16] set compute default float nnchat:l0_ao_16
data modify storage nnchat:s ao[17] set compute default float nnchat:l0_ao_17
data modify storage nnchat:s ao[18] set compute default float nnchat:l0_ao_18
data modify storage nnchat:s ao[19] set compute default float nnchat:l0_ao_19
data modify storage nnchat:s ao[20] set compute default float nnchat:l0_ao_20
data modify storage nnchat:s ao[21] set compute default float nnchat:l0_ao_21
data modify storage nnchat:s ao[22] set compute default float nnchat:l0_ao_22
data modify storage nnchat:s ao[23] set compute default float nnchat:l0_ao_23
data modify storage nnchat:s ao[24] set compute default float nnchat:l0_ao_24
data modify storage nnchat:s ao[25] set compute default float nnchat:l0_ao_25
data modify storage nnchat:s ao[26] set compute default float nnchat:l0_ao_26
data modify storage nnchat:s ao[27] set compute default float nnchat:l0_ao_27
data modify storage nnchat:s ao[28] set compute default float nnchat:l0_ao_28
data modify storage nnchat:s ao[29] set compute default float nnchat:l0_ao_29
data modify storage nnchat:s ao[30] set compute default float nnchat:l0_ao_30
data modify storage nnchat:s ao[31] set compute default float nnchat:l0_ao_31
data modify storage nnchat:s ao[32] set compute default float nnchat:l0_ao_32
data modify storage nnchat:s ao[33] set compute default float nnchat:l0_ao_33
data modify storage nnchat:s ao[34] set compute default float nnchat:l0_ao_34
data modify storage nnchat:s ao[35] set compute default float nnchat:l0_ao_35
data modify storage nnchat:s ao[36] set compute default float nnchat:l0_ao_36
data modify storage nnchat:s ao[37] set compute default float nnchat:l0_ao_37
data modify storage nnchat:s ao[38] set compute default float nnchat:l0_ao_38
data modify storage nnchat:s ao[39] set compute default float nnchat:l0_ao_39
data modify storage nnchat:s ao[40] set compute default float nnchat:l0_ao_40
data modify storage nnchat:s ao[41] set compute default float nnchat:l0_ao_41
data modify storage nnchat:s ao[42] set compute default float nnchat:l0_ao_42
data modify storage nnchat:s ao[43] set compute default float nnchat:l0_ao_43
data modify storage nnchat:s ao[44] set compute default float nnchat:l0_ao_44
data modify storage nnchat:s ao[45] set compute default float nnchat:l0_ao_45
data modify storage nnchat:s ao[46] set compute default float nnchat:l0_ao_46
data modify storage nnchat:s ao[47] set compute default float nnchat:l0_ao_47
data modify storage nnchat:s ao[48] set compute default float nnchat:l0_ao_48
data modify storage nnchat:s ao[49] set compute default float nnchat:l0_ao_49
data modify storage nnchat:s ao[50] set compute default float nnchat:l0_ao_50
data modify storage nnchat:s ao[51] set compute default float nnchat:l0_ao_51
data modify storage nnchat:s ao[52] set compute default float nnchat:l0_ao_52
data modify storage nnchat:s ao[53] set compute default float nnchat:l0_ao_53
data modify storage nnchat:s ao[54] set compute default float nnchat:l0_ao_54
data modify storage nnchat:s ao[55] set compute default float nnchat:l0_ao_55
data modify storage nnchat:s ao[56] set compute default float nnchat:l0_ao_56
data modify storage nnchat:s ao[57] set compute default float nnchat:l0_ao_57
data modify storage nnchat:s ao[58] set compute default float nnchat:l0_ao_58
data modify storage nnchat:s ao[59] set compute default float nnchat:l0_ao_59
data modify storage nnchat:s ao[60] set compute default float nnchat:l0_ao_60
data modify storage nnchat:s ao[61] set compute default float nnchat:l0_ao_61
data modify storage nnchat:s ao[62] set compute default float nnchat:l0_ao_62
data modify storage nnchat:s ao[63] set compute default float nnchat:l0_ao_63
data modify storage nnchat:s x[0] set compute default float nnchat:l0_o_0
data modify storage nnchat:s x[1] set compute default float nnchat:l0_o_1
data modify storage nnchat:s x[2] set compute default float nnchat:l0_o_2
data modify storage nnchat:s x[3] set compute default float nnchat:l0_o_3
data modify storage nnchat:s x[4] set compute default float nnchat:l0_o_4
data modify storage nnchat:s x[5] set compute default float nnchat:l0_o_5
data modify storage nnchat:s x[6] set compute default float nnchat:l0_o_6
data modify storage nnchat:s x[7] set compute default float nnchat:l0_o_7
data modify storage nnchat:s x[8] set compute default float nnchat:l0_o_8
data modify storage nnchat:s x[9] set compute default float nnchat:l0_o_9
data modify storage nnchat:s x[10] set compute default float nnchat:l0_o_10
data modify storage nnchat:s x[11] set compute default float nnchat:l0_o_11
data modify storage nnchat:s x[12] set compute default float nnchat:l0_o_12
data modify storage nnchat:s x[13] set compute default float nnchat:l0_o_13
data modify storage nnchat:s x[14] set compute default float nnchat:l0_o_14
data modify storage nnchat:s x[15] set compute default float nnchat:l0_o_15
data modify storage nnchat:s x[16] set compute default float nnchat:l0_o_16
data modify storage nnchat:s x[17] set compute default float nnchat:l0_o_17
data modify storage nnchat:s x[18] set compute default float nnchat:l0_o_18
data modify storage nnchat:s x[19] set compute default float nnchat:l0_o_19
data modify storage nnchat:s x[20] set compute default float nnchat:l0_o_20
data modify storage nnchat:s x[21] set compute default float nnchat:l0_o_21
data modify storage nnchat:s x[22] set compute default float nnchat:l0_o_22
data modify storage nnchat:s x[23] set compute default float nnchat:l0_o_23
data modify storage nnchat:s x[24] set compute default float nnchat:l0_o_24
data modify storage nnchat:s x[25] set compute default float nnchat:l0_o_25
data modify storage nnchat:s x[26] set compute default float nnchat:l0_o_26
data modify storage nnchat:s x[27] set compute default float nnchat:l0_o_27
data modify storage nnchat:s x[28] set compute default float nnchat:l0_o_28
data modify storage nnchat:s x[29] set compute default float nnchat:l0_o_29
data modify storage nnchat:s x[30] set compute default float nnchat:l0_o_30
data modify storage nnchat:s x[31] set compute default float nnchat:l0_o_31
data modify storage nnchat:s x[32] set compute default float nnchat:l0_o_32
data modify storage nnchat:s x[33] set compute default float nnchat:l0_o_33
data modify storage nnchat:s x[34] set compute default float nnchat:l0_o_34
data modify storage nnchat:s x[35] set compute default float nnchat:l0_o_35
data modify storage nnchat:s x[36] set compute default float nnchat:l0_o_36
data modify storage nnchat:s x[37] set compute default float nnchat:l0_o_37
data modify storage nnchat:s x[38] set compute default float nnchat:l0_o_38
data modify storage nnchat:s x[39] set compute default float nnchat:l0_o_39
data modify storage nnchat:s x[40] set compute default float nnchat:l0_o_40
data modify storage nnchat:s x[41] set compute default float nnchat:l0_o_41
data modify storage nnchat:s x[42] set compute default float nnchat:l0_o_42
data modify storage nnchat:s x[43] set compute default float nnchat:l0_o_43
data modify storage nnchat:s x[44] set compute default float nnchat:l0_o_44
data modify storage nnchat:s x[45] set compute default float nnchat:l0_o_45
data modify storage nnchat:s x[46] set compute default float nnchat:l0_o_46
data modify storage nnchat:s x[47] set compute default float nnchat:l0_o_47
data modify storage nnchat:s x[48] set compute default float nnchat:l0_o_48
data modify storage nnchat:s x[49] set compute default float nnchat:l0_o_49
data modify storage nnchat:s x[50] set compute default float nnchat:l0_o_50
data modify storage nnchat:s x[51] set compute default float nnchat:l0_o_51
data modify storage nnchat:s x[52] set compute default float nnchat:l0_o_52
data modify storage nnchat:s x[53] set compute default float nnchat:l0_o_53
data modify storage nnchat:s x[54] set compute default float nnchat:l0_o_54
data modify storage nnchat:s x[55] set compute default float nnchat:l0_o_55
data modify storage nnchat:s x[56] set compute default float nnchat:l0_o_56
data modify storage nnchat:s x[57] set compute default float nnchat:l0_o_57
data modify storage nnchat:s x[58] set compute default float nnchat:l0_o_58
data modify storage nnchat:s x[59] set compute default float nnchat:l0_o_59
data modify storage nnchat:s x[60] set compute default float nnchat:l0_o_60
data modify storage nnchat:s x[61] set compute default float nnchat:l0_o_61
data modify storage nnchat:s x[62] set compute default float nnchat:l0_o_62
data modify storage nnchat:s x[63] set compute default float nnchat:l0_o_63
# --- 层 0: LN2 + FFN ---
data modify storage nnchat:s m set compute default float nnchat:l0_m2
data modify storage nnchat:s c[0] set compute default float nnchat:l0_c2_0
data modify storage nnchat:s c[1] set compute default float nnchat:l0_c2_1
data modify storage nnchat:s c[2] set compute default float nnchat:l0_c2_2
data modify storage nnchat:s c[3] set compute default float nnchat:l0_c2_3
data modify storage nnchat:s c[4] set compute default float nnchat:l0_c2_4
data modify storage nnchat:s c[5] set compute default float nnchat:l0_c2_5
data modify storage nnchat:s c[6] set compute default float nnchat:l0_c2_6
data modify storage nnchat:s c[7] set compute default float nnchat:l0_c2_7
data modify storage nnchat:s c[8] set compute default float nnchat:l0_c2_8
data modify storage nnchat:s c[9] set compute default float nnchat:l0_c2_9
data modify storage nnchat:s c[10] set compute default float nnchat:l0_c2_10
data modify storage nnchat:s c[11] set compute default float nnchat:l0_c2_11
data modify storage nnchat:s c[12] set compute default float nnchat:l0_c2_12
data modify storage nnchat:s c[13] set compute default float nnchat:l0_c2_13
data modify storage nnchat:s c[14] set compute default float nnchat:l0_c2_14
data modify storage nnchat:s c[15] set compute default float nnchat:l0_c2_15
data modify storage nnchat:s c[16] set compute default float nnchat:l0_c2_16
data modify storage nnchat:s c[17] set compute default float nnchat:l0_c2_17
data modify storage nnchat:s c[18] set compute default float nnchat:l0_c2_18
data modify storage nnchat:s c[19] set compute default float nnchat:l0_c2_19
data modify storage nnchat:s c[20] set compute default float nnchat:l0_c2_20
data modify storage nnchat:s c[21] set compute default float nnchat:l0_c2_21
data modify storage nnchat:s c[22] set compute default float nnchat:l0_c2_22
data modify storage nnchat:s c[23] set compute default float nnchat:l0_c2_23
data modify storage nnchat:s c[24] set compute default float nnchat:l0_c2_24
data modify storage nnchat:s c[25] set compute default float nnchat:l0_c2_25
data modify storage nnchat:s c[26] set compute default float nnchat:l0_c2_26
data modify storage nnchat:s c[27] set compute default float nnchat:l0_c2_27
data modify storage nnchat:s c[28] set compute default float nnchat:l0_c2_28
data modify storage nnchat:s c[29] set compute default float nnchat:l0_c2_29
data modify storage nnchat:s c[30] set compute default float nnchat:l0_c2_30
data modify storage nnchat:s c[31] set compute default float nnchat:l0_c2_31
data modify storage nnchat:s c[32] set compute default float nnchat:l0_c2_32
data modify storage nnchat:s c[33] set compute default float nnchat:l0_c2_33
data modify storage nnchat:s c[34] set compute default float nnchat:l0_c2_34
data modify storage nnchat:s c[35] set compute default float nnchat:l0_c2_35
data modify storage nnchat:s c[36] set compute default float nnchat:l0_c2_36
data modify storage nnchat:s c[37] set compute default float nnchat:l0_c2_37
data modify storage nnchat:s c[38] set compute default float nnchat:l0_c2_38
data modify storage nnchat:s c[39] set compute default float nnchat:l0_c2_39
data modify storage nnchat:s c[40] set compute default float nnchat:l0_c2_40
data modify storage nnchat:s c[41] set compute default float nnchat:l0_c2_41
data modify storage nnchat:s c[42] set compute default float nnchat:l0_c2_42
data modify storage nnchat:s c[43] set compute default float nnchat:l0_c2_43
data modify storage nnchat:s c[44] set compute default float nnchat:l0_c2_44
data modify storage nnchat:s c[45] set compute default float nnchat:l0_c2_45
data modify storage nnchat:s c[46] set compute default float nnchat:l0_c2_46
data modify storage nnchat:s c[47] set compute default float nnchat:l0_c2_47
data modify storage nnchat:s c[48] set compute default float nnchat:l0_c2_48
data modify storage nnchat:s c[49] set compute default float nnchat:l0_c2_49
data modify storage nnchat:s c[50] set compute default float nnchat:l0_c2_50
data modify storage nnchat:s c[51] set compute default float nnchat:l0_c2_51
data modify storage nnchat:s c[52] set compute default float nnchat:l0_c2_52
data modify storage nnchat:s c[53] set compute default float nnchat:l0_c2_53
data modify storage nnchat:s c[54] set compute default float nnchat:l0_c2_54
data modify storage nnchat:s c[55] set compute default float nnchat:l0_c2_55
data modify storage nnchat:s c[56] set compute default float nnchat:l0_c2_56
data modify storage nnchat:s c[57] set compute default float nnchat:l0_c2_57
data modify storage nnchat:s c[58] set compute default float nnchat:l0_c2_58
data modify storage nnchat:s c[59] set compute default float nnchat:l0_c2_59
data modify storage nnchat:s c[60] set compute default float nnchat:l0_c2_60
data modify storage nnchat:s c[61] set compute default float nnchat:l0_c2_61
data modify storage nnchat:s c[62] set compute default float nnchat:l0_c2_62
data modify storage nnchat:s c[63] set compute default float nnchat:l0_c2_63
data modify storage nnchat:s var set compute default float nnchat:l0_var2
data modify storage nnchat:s inv set compute default float nnchat:l0_inv2
data modify storage nnchat:s n[0] set compute default float nnchat:l0_n2_0
data modify storage nnchat:s n[1] set compute default float nnchat:l0_n2_1
data modify storage nnchat:s n[2] set compute default float nnchat:l0_n2_2
data modify storage nnchat:s n[3] set compute default float nnchat:l0_n2_3
data modify storage nnchat:s n[4] set compute default float nnchat:l0_n2_4
data modify storage nnchat:s n[5] set compute default float nnchat:l0_n2_5
data modify storage nnchat:s n[6] set compute default float nnchat:l0_n2_6
data modify storage nnchat:s n[7] set compute default float nnchat:l0_n2_7
data modify storage nnchat:s n[8] set compute default float nnchat:l0_n2_8
data modify storage nnchat:s n[9] set compute default float nnchat:l0_n2_9
data modify storage nnchat:s n[10] set compute default float nnchat:l0_n2_10
data modify storage nnchat:s n[11] set compute default float nnchat:l0_n2_11
data modify storage nnchat:s n[12] set compute default float nnchat:l0_n2_12
data modify storage nnchat:s n[13] set compute default float nnchat:l0_n2_13
data modify storage nnchat:s n[14] set compute default float nnchat:l0_n2_14
data modify storage nnchat:s n[15] set compute default float nnchat:l0_n2_15
data modify storage nnchat:s n[16] set compute default float nnchat:l0_n2_16
data modify storage nnchat:s n[17] set compute default float nnchat:l0_n2_17
data modify storage nnchat:s n[18] set compute default float nnchat:l0_n2_18
data modify storage nnchat:s n[19] set compute default float nnchat:l0_n2_19
data modify storage nnchat:s n[20] set compute default float nnchat:l0_n2_20
data modify storage nnchat:s n[21] set compute default float nnchat:l0_n2_21
data modify storage nnchat:s n[22] set compute default float nnchat:l0_n2_22
data modify storage nnchat:s n[23] set compute default float nnchat:l0_n2_23
data modify storage nnchat:s n[24] set compute default float nnchat:l0_n2_24
data modify storage nnchat:s n[25] set compute default float nnchat:l0_n2_25
data modify storage nnchat:s n[26] set compute default float nnchat:l0_n2_26
data modify storage nnchat:s n[27] set compute default float nnchat:l0_n2_27
data modify storage nnchat:s n[28] set compute default float nnchat:l0_n2_28
data modify storage nnchat:s n[29] set compute default float nnchat:l0_n2_29
data modify storage nnchat:s n[30] set compute default float nnchat:l0_n2_30
data modify storage nnchat:s n[31] set compute default float nnchat:l0_n2_31
data modify storage nnchat:s n[32] set compute default float nnchat:l0_n2_32
data modify storage nnchat:s n[33] set compute default float nnchat:l0_n2_33
data modify storage nnchat:s n[34] set compute default float nnchat:l0_n2_34
data modify storage nnchat:s n[35] set compute default float nnchat:l0_n2_35
data modify storage nnchat:s n[36] set compute default float nnchat:l0_n2_36
data modify storage nnchat:s n[37] set compute default float nnchat:l0_n2_37
data modify storage nnchat:s n[38] set compute default float nnchat:l0_n2_38
data modify storage nnchat:s n[39] set compute default float nnchat:l0_n2_39
data modify storage nnchat:s n[40] set compute default float nnchat:l0_n2_40
data modify storage nnchat:s n[41] set compute default float nnchat:l0_n2_41
data modify storage nnchat:s n[42] set compute default float nnchat:l0_n2_42
data modify storage nnchat:s n[43] set compute default float nnchat:l0_n2_43
data modify storage nnchat:s n[44] set compute default float nnchat:l0_n2_44
data modify storage nnchat:s n[45] set compute default float nnchat:l0_n2_45
data modify storage nnchat:s n[46] set compute default float nnchat:l0_n2_46
data modify storage nnchat:s n[47] set compute default float nnchat:l0_n2_47
data modify storage nnchat:s n[48] set compute default float nnchat:l0_n2_48
data modify storage nnchat:s n[49] set compute default float nnchat:l0_n2_49
data modify storage nnchat:s n[50] set compute default float nnchat:l0_n2_50
data modify storage nnchat:s n[51] set compute default float nnchat:l0_n2_51
data modify storage nnchat:s n[52] set compute default float nnchat:l0_n2_52
data modify storage nnchat:s n[53] set compute default float nnchat:l0_n2_53
data modify storage nnchat:s n[54] set compute default float nnchat:l0_n2_54
data modify storage nnchat:s n[55] set compute default float nnchat:l0_n2_55
data modify storage nnchat:s n[56] set compute default float nnchat:l0_n2_56
data modify storage nnchat:s n[57] set compute default float nnchat:l0_n2_57
data modify storage nnchat:s n[58] set compute default float nnchat:l0_n2_58
data modify storage nnchat:s n[59] set compute default float nnchat:l0_n2_59
data modify storage nnchat:s n[60] set compute default float nnchat:l0_n2_60
data modify storage nnchat:s n[61] set compute default float nnchat:l0_n2_61
data modify storage nnchat:s n[62] set compute default float nnchat:l0_n2_62
data modify storage nnchat:s n[63] set compute default float nnchat:l0_n2_63
data modify storage nnchat:s f[0] set compute default float nnchat:l0_f_0
data modify storage nnchat:s f[1] set compute default float nnchat:l0_f_1
data modify storage nnchat:s f[2] set compute default float nnchat:l0_f_2
data modify storage nnchat:s f[3] set compute default float nnchat:l0_f_3
data modify storage nnchat:s f[4] set compute default float nnchat:l0_f_4
data modify storage nnchat:s f[5] set compute default float nnchat:l0_f_5
data modify storage nnchat:s f[6] set compute default float nnchat:l0_f_6
data modify storage nnchat:s f[7] set compute default float nnchat:l0_f_7
data modify storage nnchat:s f[8] set compute default float nnchat:l0_f_8
data modify storage nnchat:s f[9] set compute default float nnchat:l0_f_9
data modify storage nnchat:s f[10] set compute default float nnchat:l0_f_10
data modify storage nnchat:s f[11] set compute default float nnchat:l0_f_11
data modify storage nnchat:s f[12] set compute default float nnchat:l0_f_12
data modify storage nnchat:s f[13] set compute default float nnchat:l0_f_13
data modify storage nnchat:s f[14] set compute default float nnchat:l0_f_14
data modify storage nnchat:s f[15] set compute default float nnchat:l0_f_15
data modify storage nnchat:s f[16] set compute default float nnchat:l0_f_16
data modify storage nnchat:s f[17] set compute default float nnchat:l0_f_17
data modify storage nnchat:s f[18] set compute default float nnchat:l0_f_18
data modify storage nnchat:s f[19] set compute default float nnchat:l0_f_19
data modify storage nnchat:s f[20] set compute default float nnchat:l0_f_20
data modify storage nnchat:s f[21] set compute default float nnchat:l0_f_21
data modify storage nnchat:s f[22] set compute default float nnchat:l0_f_22
data modify storage nnchat:s f[23] set compute default float nnchat:l0_f_23
data modify storage nnchat:s f[24] set compute default float nnchat:l0_f_24
data modify storage nnchat:s f[25] set compute default float nnchat:l0_f_25
data modify storage nnchat:s f[26] set compute default float nnchat:l0_f_26
data modify storage nnchat:s f[27] set compute default float nnchat:l0_f_27
data modify storage nnchat:s f[28] set compute default float nnchat:l0_f_28
data modify storage nnchat:s f[29] set compute default float nnchat:l0_f_29
data modify storage nnchat:s f[30] set compute default float nnchat:l0_f_30
data modify storage nnchat:s f[31] set compute default float nnchat:l0_f_31
data modify storage nnchat:s f[32] set compute default float nnchat:l0_f_32
data modify storage nnchat:s f[33] set compute default float nnchat:l0_f_33
data modify storage nnchat:s f[34] set compute default float nnchat:l0_f_34
data modify storage nnchat:s f[35] set compute default float nnchat:l0_f_35
data modify storage nnchat:s f[36] set compute default float nnchat:l0_f_36
data modify storage nnchat:s f[37] set compute default float nnchat:l0_f_37
data modify storage nnchat:s f[38] set compute default float nnchat:l0_f_38
data modify storage nnchat:s f[39] set compute default float nnchat:l0_f_39
data modify storage nnchat:s f[40] set compute default float nnchat:l0_f_40
data modify storage nnchat:s f[41] set compute default float nnchat:l0_f_41
data modify storage nnchat:s f[42] set compute default float nnchat:l0_f_42
data modify storage nnchat:s f[43] set compute default float nnchat:l0_f_43
data modify storage nnchat:s f[44] set compute default float nnchat:l0_f_44
data modify storage nnchat:s f[45] set compute default float nnchat:l0_f_45
data modify storage nnchat:s f[46] set compute default float nnchat:l0_f_46
data modify storage nnchat:s f[47] set compute default float nnchat:l0_f_47
data modify storage nnchat:s f[48] set compute default float nnchat:l0_f_48
data modify storage nnchat:s f[49] set compute default float nnchat:l0_f_49
data modify storage nnchat:s f[50] set compute default float nnchat:l0_f_50
data modify storage nnchat:s f[51] set compute default float nnchat:l0_f_51
data modify storage nnchat:s f[52] set compute default float nnchat:l0_f_52
data modify storage nnchat:s f[53] set compute default float nnchat:l0_f_53
data modify storage nnchat:s f[54] set compute default float nnchat:l0_f_54
data modify storage nnchat:s f[55] set compute default float nnchat:l0_f_55
data modify storage nnchat:s f[56] set compute default float nnchat:l0_f_56
data modify storage nnchat:s f[57] set compute default float nnchat:l0_f_57
data modify storage nnchat:s f[58] set compute default float nnchat:l0_f_58
data modify storage nnchat:s f[59] set compute default float nnchat:l0_f_59
data modify storage nnchat:s f[60] set compute default float nnchat:l0_f_60
data modify storage nnchat:s f[61] set compute default float nnchat:l0_f_61
data modify storage nnchat:s f[62] set compute default float nnchat:l0_f_62
data modify storage nnchat:s f[63] set compute default float nnchat:l0_f_63
data modify storage nnchat:s f[64] set compute default float nnchat:l0_f_64
data modify storage nnchat:s f[65] set compute default float nnchat:l0_f_65
data modify storage nnchat:s f[66] set compute default float nnchat:l0_f_66
data modify storage nnchat:s f[67] set compute default float nnchat:l0_f_67
data modify storage nnchat:s f[68] set compute default float nnchat:l0_f_68
data modify storage nnchat:s f[69] set compute default float nnchat:l0_f_69
data modify storage nnchat:s f[70] set compute default float nnchat:l0_f_70
data modify storage nnchat:s f[71] set compute default float nnchat:l0_f_71
data modify storage nnchat:s f[72] set compute default float nnchat:l0_f_72
data modify storage nnchat:s f[73] set compute default float nnchat:l0_f_73
data modify storage nnchat:s f[74] set compute default float nnchat:l0_f_74
data modify storage nnchat:s f[75] set compute default float nnchat:l0_f_75
data modify storage nnchat:s f[76] set compute default float nnchat:l0_f_76
data modify storage nnchat:s f[77] set compute default float nnchat:l0_f_77
data modify storage nnchat:s f[78] set compute default float nnchat:l0_f_78
data modify storage nnchat:s f[79] set compute default float nnchat:l0_f_79
data modify storage nnchat:s f[80] set compute default float nnchat:l0_f_80
data modify storage nnchat:s f[81] set compute default float nnchat:l0_f_81
data modify storage nnchat:s f[82] set compute default float nnchat:l0_f_82
data modify storage nnchat:s f[83] set compute default float nnchat:l0_f_83
data modify storage nnchat:s f[84] set compute default float nnchat:l0_f_84
data modify storage nnchat:s f[85] set compute default float nnchat:l0_f_85
data modify storage nnchat:s f[86] set compute default float nnchat:l0_f_86
data modify storage nnchat:s f[87] set compute default float nnchat:l0_f_87
data modify storage nnchat:s f[88] set compute default float nnchat:l0_f_88
data modify storage nnchat:s f[89] set compute default float nnchat:l0_f_89
data modify storage nnchat:s f[90] set compute default float nnchat:l0_f_90
data modify storage nnchat:s f[91] set compute default float nnchat:l0_f_91
data modify storage nnchat:s f[92] set compute default float nnchat:l0_f_92
data modify storage nnchat:s f[93] set compute default float nnchat:l0_f_93
data modify storage nnchat:s f[94] set compute default float nnchat:l0_f_94
data modify storage nnchat:s f[95] set compute default float nnchat:l0_f_95
data modify storage nnchat:s f[96] set compute default float nnchat:l0_f_96
data modify storage nnchat:s f[97] set compute default float nnchat:l0_f_97
data modify storage nnchat:s f[98] set compute default float nnchat:l0_f_98
data modify storage nnchat:s f[99] set compute default float nnchat:l0_f_99
data modify storage nnchat:s f[100] set compute default float nnchat:l0_f_100
data modify storage nnchat:s f[101] set compute default float nnchat:l0_f_101
data modify storage nnchat:s f[102] set compute default float nnchat:l0_f_102
data modify storage nnchat:s f[103] set compute default float nnchat:l0_f_103
data modify storage nnchat:s f[104] set compute default float nnchat:l0_f_104
data modify storage nnchat:s f[105] set compute default float nnchat:l0_f_105
data modify storage nnchat:s f[106] set compute default float nnchat:l0_f_106
data modify storage nnchat:s f[107] set compute default float nnchat:l0_f_107
data modify storage nnchat:s f[108] set compute default float nnchat:l0_f_108
data modify storage nnchat:s f[109] set compute default float nnchat:l0_f_109
data modify storage nnchat:s f[110] set compute default float nnchat:l0_f_110
data modify storage nnchat:s f[111] set compute default float nnchat:l0_f_111
data modify storage nnchat:s f[112] set compute default float nnchat:l0_f_112
data modify storage nnchat:s f[113] set compute default float nnchat:l0_f_113
data modify storage nnchat:s f[114] set compute default float nnchat:l0_f_114
data modify storage nnchat:s f[115] set compute default float nnchat:l0_f_115
data modify storage nnchat:s f[116] set compute default float nnchat:l0_f_116
data modify storage nnchat:s f[117] set compute default float nnchat:l0_f_117
data modify storage nnchat:s f[118] set compute default float nnchat:l0_f_118
data modify storage nnchat:s f[119] set compute default float nnchat:l0_f_119
data modify storage nnchat:s f[120] set compute default float nnchat:l0_f_120
data modify storage nnchat:s f[121] set compute default float nnchat:l0_f_121
data modify storage nnchat:s f[122] set compute default float nnchat:l0_f_122
data modify storage nnchat:s f[123] set compute default float nnchat:l0_f_123
data modify storage nnchat:s f[124] set compute default float nnchat:l0_f_124
data modify storage nnchat:s f[125] set compute default float nnchat:l0_f_125
data modify storage nnchat:s f[126] set compute default float nnchat:l0_f_126
data modify storage nnchat:s f[127] set compute default float nnchat:l0_f_127
data modify storage nnchat:s x[0] set compute default float nnchat:l0_g_0
data modify storage nnchat:s x[1] set compute default float nnchat:l0_g_1
data modify storage nnchat:s x[2] set compute default float nnchat:l0_g_2
data modify storage nnchat:s x[3] set compute default float nnchat:l0_g_3
data modify storage nnchat:s x[4] set compute default float nnchat:l0_g_4
data modify storage nnchat:s x[5] set compute default float nnchat:l0_g_5
data modify storage nnchat:s x[6] set compute default float nnchat:l0_g_6
data modify storage nnchat:s x[7] set compute default float nnchat:l0_g_7
data modify storage nnchat:s x[8] set compute default float nnchat:l0_g_8
data modify storage nnchat:s x[9] set compute default float nnchat:l0_g_9
data modify storage nnchat:s x[10] set compute default float nnchat:l0_g_10
data modify storage nnchat:s x[11] set compute default float nnchat:l0_g_11
data modify storage nnchat:s x[12] set compute default float nnchat:l0_g_12
data modify storage nnchat:s x[13] set compute default float nnchat:l0_g_13
data modify storage nnchat:s x[14] set compute default float nnchat:l0_g_14
data modify storage nnchat:s x[15] set compute default float nnchat:l0_g_15
data modify storage nnchat:s x[16] set compute default float nnchat:l0_g_16
data modify storage nnchat:s x[17] set compute default float nnchat:l0_g_17
data modify storage nnchat:s x[18] set compute default float nnchat:l0_g_18
data modify storage nnchat:s x[19] set compute default float nnchat:l0_g_19
data modify storage nnchat:s x[20] set compute default float nnchat:l0_g_20
data modify storage nnchat:s x[21] set compute default float nnchat:l0_g_21
data modify storage nnchat:s x[22] set compute default float nnchat:l0_g_22
data modify storage nnchat:s x[23] set compute default float nnchat:l0_g_23
data modify storage nnchat:s x[24] set compute default float nnchat:l0_g_24
data modify storage nnchat:s x[25] set compute default float nnchat:l0_g_25
data modify storage nnchat:s x[26] set compute default float nnchat:l0_g_26
data modify storage nnchat:s x[27] set compute default float nnchat:l0_g_27
data modify storage nnchat:s x[28] set compute default float nnchat:l0_g_28
data modify storage nnchat:s x[29] set compute default float nnchat:l0_g_29
data modify storage nnchat:s x[30] set compute default float nnchat:l0_g_30
data modify storage nnchat:s x[31] set compute default float nnchat:l0_g_31
data modify storage nnchat:s x[32] set compute default float nnchat:l0_g_32
data modify storage nnchat:s x[33] set compute default float nnchat:l0_g_33
data modify storage nnchat:s x[34] set compute default float nnchat:l0_g_34
data modify storage nnchat:s x[35] set compute default float nnchat:l0_g_35
data modify storage nnchat:s x[36] set compute default float nnchat:l0_g_36
data modify storage nnchat:s x[37] set compute default float nnchat:l0_g_37
data modify storage nnchat:s x[38] set compute default float nnchat:l0_g_38
data modify storage nnchat:s x[39] set compute default float nnchat:l0_g_39
data modify storage nnchat:s x[40] set compute default float nnchat:l0_g_40
data modify storage nnchat:s x[41] set compute default float nnchat:l0_g_41
data modify storage nnchat:s x[42] set compute default float nnchat:l0_g_42
data modify storage nnchat:s x[43] set compute default float nnchat:l0_g_43
data modify storage nnchat:s x[44] set compute default float nnchat:l0_g_44
data modify storage nnchat:s x[45] set compute default float nnchat:l0_g_45
data modify storage nnchat:s x[46] set compute default float nnchat:l0_g_46
data modify storage nnchat:s x[47] set compute default float nnchat:l0_g_47
data modify storage nnchat:s x[48] set compute default float nnchat:l0_g_48
data modify storage nnchat:s x[49] set compute default float nnchat:l0_g_49
data modify storage nnchat:s x[50] set compute default float nnchat:l0_g_50
data modify storage nnchat:s x[51] set compute default float nnchat:l0_g_51
data modify storage nnchat:s x[52] set compute default float nnchat:l0_g_52
data modify storage nnchat:s x[53] set compute default float nnchat:l0_g_53
data modify storage nnchat:s x[54] set compute default float nnchat:l0_g_54
data modify storage nnchat:s x[55] set compute default float nnchat:l0_g_55
data modify storage nnchat:s x[56] set compute default float nnchat:l0_g_56
data modify storage nnchat:s x[57] set compute default float nnchat:l0_g_57
data modify storage nnchat:s x[58] set compute default float nnchat:l0_g_58
data modify storage nnchat:s x[59] set compute default float nnchat:l0_g_59
data modify storage nnchat:s x[60] set compute default float nnchat:l0_g_60
data modify storage nnchat:s x[61] set compute default float nnchat:l0_g_61
data modify storage nnchat:s x[62] set compute default float nnchat:l0_g_62
data modify storage nnchat:s x[63] set compute default float nnchat:l0_g_63
# --- 层 1: LN1 ---
data modify storage nnchat:s m set compute default float nnchat:l1_m1
data modify storage nnchat:s c[0] set compute default float nnchat:l1_c1_0
data modify storage nnchat:s c[1] set compute default float nnchat:l1_c1_1
data modify storage nnchat:s c[2] set compute default float nnchat:l1_c1_2
data modify storage nnchat:s c[3] set compute default float nnchat:l1_c1_3
data modify storage nnchat:s c[4] set compute default float nnchat:l1_c1_4
data modify storage nnchat:s c[5] set compute default float nnchat:l1_c1_5
data modify storage nnchat:s c[6] set compute default float nnchat:l1_c1_6
data modify storage nnchat:s c[7] set compute default float nnchat:l1_c1_7
data modify storage nnchat:s c[8] set compute default float nnchat:l1_c1_8
data modify storage nnchat:s c[9] set compute default float nnchat:l1_c1_9
data modify storage nnchat:s c[10] set compute default float nnchat:l1_c1_10
data modify storage nnchat:s c[11] set compute default float nnchat:l1_c1_11
data modify storage nnchat:s c[12] set compute default float nnchat:l1_c1_12
data modify storage nnchat:s c[13] set compute default float nnchat:l1_c1_13
data modify storage nnchat:s c[14] set compute default float nnchat:l1_c1_14
data modify storage nnchat:s c[15] set compute default float nnchat:l1_c1_15
data modify storage nnchat:s c[16] set compute default float nnchat:l1_c1_16
data modify storage nnchat:s c[17] set compute default float nnchat:l1_c1_17
data modify storage nnchat:s c[18] set compute default float nnchat:l1_c1_18
data modify storage nnchat:s c[19] set compute default float nnchat:l1_c1_19
data modify storage nnchat:s c[20] set compute default float nnchat:l1_c1_20
data modify storage nnchat:s c[21] set compute default float nnchat:l1_c1_21
data modify storage nnchat:s c[22] set compute default float nnchat:l1_c1_22
data modify storage nnchat:s c[23] set compute default float nnchat:l1_c1_23
data modify storage nnchat:s c[24] set compute default float nnchat:l1_c1_24
data modify storage nnchat:s c[25] set compute default float nnchat:l1_c1_25
data modify storage nnchat:s c[26] set compute default float nnchat:l1_c1_26
data modify storage nnchat:s c[27] set compute default float nnchat:l1_c1_27
data modify storage nnchat:s c[28] set compute default float nnchat:l1_c1_28
data modify storage nnchat:s c[29] set compute default float nnchat:l1_c1_29
data modify storage nnchat:s c[30] set compute default float nnchat:l1_c1_30
data modify storage nnchat:s c[31] set compute default float nnchat:l1_c1_31
data modify storage nnchat:s c[32] set compute default float nnchat:l1_c1_32
data modify storage nnchat:s c[33] set compute default float nnchat:l1_c1_33
data modify storage nnchat:s c[34] set compute default float nnchat:l1_c1_34
data modify storage nnchat:s c[35] set compute default float nnchat:l1_c1_35
data modify storage nnchat:s c[36] set compute default float nnchat:l1_c1_36
data modify storage nnchat:s c[37] set compute default float nnchat:l1_c1_37
data modify storage nnchat:s c[38] set compute default float nnchat:l1_c1_38
data modify storage nnchat:s c[39] set compute default float nnchat:l1_c1_39
data modify storage nnchat:s c[40] set compute default float nnchat:l1_c1_40
data modify storage nnchat:s c[41] set compute default float nnchat:l1_c1_41
data modify storage nnchat:s c[42] set compute default float nnchat:l1_c1_42
data modify storage nnchat:s c[43] set compute default float nnchat:l1_c1_43
data modify storage nnchat:s c[44] set compute default float nnchat:l1_c1_44
data modify storage nnchat:s c[45] set compute default float nnchat:l1_c1_45
data modify storage nnchat:s c[46] set compute default float nnchat:l1_c1_46
data modify storage nnchat:s c[47] set compute default float nnchat:l1_c1_47
data modify storage nnchat:s c[48] set compute default float nnchat:l1_c1_48
data modify storage nnchat:s c[49] set compute default float nnchat:l1_c1_49
data modify storage nnchat:s c[50] set compute default float nnchat:l1_c1_50
data modify storage nnchat:s c[51] set compute default float nnchat:l1_c1_51
data modify storage nnchat:s c[52] set compute default float nnchat:l1_c1_52
data modify storage nnchat:s c[53] set compute default float nnchat:l1_c1_53
data modify storage nnchat:s c[54] set compute default float nnchat:l1_c1_54
data modify storage nnchat:s c[55] set compute default float nnchat:l1_c1_55
data modify storage nnchat:s c[56] set compute default float nnchat:l1_c1_56
data modify storage nnchat:s c[57] set compute default float nnchat:l1_c1_57
data modify storage nnchat:s c[58] set compute default float nnchat:l1_c1_58
data modify storage nnchat:s c[59] set compute default float nnchat:l1_c1_59
data modify storage nnchat:s c[60] set compute default float nnchat:l1_c1_60
data modify storage nnchat:s c[61] set compute default float nnchat:l1_c1_61
data modify storage nnchat:s c[62] set compute default float nnchat:l1_c1_62
data modify storage nnchat:s c[63] set compute default float nnchat:l1_c1_63
data modify storage nnchat:s var set compute default float nnchat:l1_var1
data modify storage nnchat:s inv set compute default float nnchat:l1_inv1
data modify storage nnchat:s n[0] set compute default float nnchat:l1_n1_0
data modify storage nnchat:s n[1] set compute default float nnchat:l1_n1_1
data modify storage nnchat:s n[2] set compute default float nnchat:l1_n1_2
data modify storage nnchat:s n[3] set compute default float nnchat:l1_n1_3
data modify storage nnchat:s n[4] set compute default float nnchat:l1_n1_4
data modify storage nnchat:s n[5] set compute default float nnchat:l1_n1_5
data modify storage nnchat:s n[6] set compute default float nnchat:l1_n1_6
data modify storage nnchat:s n[7] set compute default float nnchat:l1_n1_7
data modify storage nnchat:s n[8] set compute default float nnchat:l1_n1_8
data modify storage nnchat:s n[9] set compute default float nnchat:l1_n1_9
data modify storage nnchat:s n[10] set compute default float nnchat:l1_n1_10
data modify storage nnchat:s n[11] set compute default float nnchat:l1_n1_11
data modify storage nnchat:s n[12] set compute default float nnchat:l1_n1_12
data modify storage nnchat:s n[13] set compute default float nnchat:l1_n1_13
data modify storage nnchat:s n[14] set compute default float nnchat:l1_n1_14
data modify storage nnchat:s n[15] set compute default float nnchat:l1_n1_15
data modify storage nnchat:s n[16] set compute default float nnchat:l1_n1_16
data modify storage nnchat:s n[17] set compute default float nnchat:l1_n1_17
data modify storage nnchat:s n[18] set compute default float nnchat:l1_n1_18
data modify storage nnchat:s n[19] set compute default float nnchat:l1_n1_19
data modify storage nnchat:s n[20] set compute default float nnchat:l1_n1_20
data modify storage nnchat:s n[21] set compute default float nnchat:l1_n1_21
data modify storage nnchat:s n[22] set compute default float nnchat:l1_n1_22
data modify storage nnchat:s n[23] set compute default float nnchat:l1_n1_23
data modify storage nnchat:s n[24] set compute default float nnchat:l1_n1_24
data modify storage nnchat:s n[25] set compute default float nnchat:l1_n1_25
data modify storage nnchat:s n[26] set compute default float nnchat:l1_n1_26
data modify storage nnchat:s n[27] set compute default float nnchat:l1_n1_27
data modify storage nnchat:s n[28] set compute default float nnchat:l1_n1_28
data modify storage nnchat:s n[29] set compute default float nnchat:l1_n1_29
data modify storage nnchat:s n[30] set compute default float nnchat:l1_n1_30
data modify storage nnchat:s n[31] set compute default float nnchat:l1_n1_31
data modify storage nnchat:s n[32] set compute default float nnchat:l1_n1_32
data modify storage nnchat:s n[33] set compute default float nnchat:l1_n1_33
data modify storage nnchat:s n[34] set compute default float nnchat:l1_n1_34
data modify storage nnchat:s n[35] set compute default float nnchat:l1_n1_35
data modify storage nnchat:s n[36] set compute default float nnchat:l1_n1_36
data modify storage nnchat:s n[37] set compute default float nnchat:l1_n1_37
data modify storage nnchat:s n[38] set compute default float nnchat:l1_n1_38
data modify storage nnchat:s n[39] set compute default float nnchat:l1_n1_39
data modify storage nnchat:s n[40] set compute default float nnchat:l1_n1_40
data modify storage nnchat:s n[41] set compute default float nnchat:l1_n1_41
data modify storage nnchat:s n[42] set compute default float nnchat:l1_n1_42
data modify storage nnchat:s n[43] set compute default float nnchat:l1_n1_43
data modify storage nnchat:s n[44] set compute default float nnchat:l1_n1_44
data modify storage nnchat:s n[45] set compute default float nnchat:l1_n1_45
data modify storage nnchat:s n[46] set compute default float nnchat:l1_n1_46
data modify storage nnchat:s n[47] set compute default float nnchat:l1_n1_47
data modify storage nnchat:s n[48] set compute default float nnchat:l1_n1_48
data modify storage nnchat:s n[49] set compute default float nnchat:l1_n1_49
data modify storage nnchat:s n[50] set compute default float nnchat:l1_n1_50
data modify storage nnchat:s n[51] set compute default float nnchat:l1_n1_51
data modify storage nnchat:s n[52] set compute default float nnchat:l1_n1_52
data modify storage nnchat:s n[53] set compute default float nnchat:l1_n1_53
data modify storage nnchat:s n[54] set compute default float nnchat:l1_n1_54
data modify storage nnchat:s n[55] set compute default float nnchat:l1_n1_55
data modify storage nnchat:s n[56] set compute default float nnchat:l1_n1_56
data modify storage nnchat:s n[57] set compute default float nnchat:l1_n1_57
data modify storage nnchat:s n[58] set compute default float nnchat:l1_n1_58
data modify storage nnchat:s n[59] set compute default float nnchat:l1_n1_59
data modify storage nnchat:s n[60] set compute default float nnchat:l1_n1_60
data modify storage nnchat:s n[61] set compute default float nnchat:l1_n1_61
data modify storage nnchat:s n[62] set compute default float nnchat:l1_n1_62
data modify storage nnchat:s n[63] set compute default float nnchat:l1_n1_63
# --- 层 1: QKV ---
data modify storage nnchat:s q[0] set compute default float nnchat:l1_q_0
data modify storage nnchat:s q[1] set compute default float nnchat:l1_q_1
data modify storage nnchat:s q[2] set compute default float nnchat:l1_q_2
data modify storage nnchat:s q[3] set compute default float nnchat:l1_q_3
data modify storage nnchat:s q[4] set compute default float nnchat:l1_q_4
data modify storage nnchat:s q[5] set compute default float nnchat:l1_q_5
data modify storage nnchat:s q[6] set compute default float nnchat:l1_q_6
data modify storage nnchat:s q[7] set compute default float nnchat:l1_q_7
data modify storage nnchat:s q[8] set compute default float nnchat:l1_q_8
data modify storage nnchat:s q[9] set compute default float nnchat:l1_q_9
data modify storage nnchat:s q[10] set compute default float nnchat:l1_q_10
data modify storage nnchat:s q[11] set compute default float nnchat:l1_q_11
data modify storage nnchat:s q[12] set compute default float nnchat:l1_q_12
data modify storage nnchat:s q[13] set compute default float nnchat:l1_q_13
data modify storage nnchat:s q[14] set compute default float nnchat:l1_q_14
data modify storage nnchat:s q[15] set compute default float nnchat:l1_q_15
data modify storage nnchat:s q[16] set compute default float nnchat:l1_q_16
data modify storage nnchat:s q[17] set compute default float nnchat:l1_q_17
data modify storage nnchat:s q[18] set compute default float nnchat:l1_q_18
data modify storage nnchat:s q[19] set compute default float nnchat:l1_q_19
data modify storage nnchat:s q[20] set compute default float nnchat:l1_q_20
data modify storage nnchat:s q[21] set compute default float nnchat:l1_q_21
data modify storage nnchat:s q[22] set compute default float nnchat:l1_q_22
data modify storage nnchat:s q[23] set compute default float nnchat:l1_q_23
data modify storage nnchat:s q[24] set compute default float nnchat:l1_q_24
data modify storage nnchat:s q[25] set compute default float nnchat:l1_q_25
data modify storage nnchat:s q[26] set compute default float nnchat:l1_q_26
data modify storage nnchat:s q[27] set compute default float nnchat:l1_q_27
data modify storage nnchat:s q[28] set compute default float nnchat:l1_q_28
data modify storage nnchat:s q[29] set compute default float nnchat:l1_q_29
data modify storage nnchat:s q[30] set compute default float nnchat:l1_q_30
data modify storage nnchat:s q[31] set compute default float nnchat:l1_q_31
data modify storage nnchat:s q[32] set compute default float nnchat:l1_q_32
data modify storage nnchat:s q[33] set compute default float nnchat:l1_q_33
data modify storage nnchat:s q[34] set compute default float nnchat:l1_q_34
data modify storage nnchat:s q[35] set compute default float nnchat:l1_q_35
data modify storage nnchat:s q[36] set compute default float nnchat:l1_q_36
data modify storage nnchat:s q[37] set compute default float nnchat:l1_q_37
data modify storage nnchat:s q[38] set compute default float nnchat:l1_q_38
data modify storage nnchat:s q[39] set compute default float nnchat:l1_q_39
data modify storage nnchat:s q[40] set compute default float nnchat:l1_q_40
data modify storage nnchat:s q[41] set compute default float nnchat:l1_q_41
data modify storage nnchat:s q[42] set compute default float nnchat:l1_q_42
data modify storage nnchat:s q[43] set compute default float nnchat:l1_q_43
data modify storage nnchat:s q[44] set compute default float nnchat:l1_q_44
data modify storage nnchat:s q[45] set compute default float nnchat:l1_q_45
data modify storage nnchat:s q[46] set compute default float nnchat:l1_q_46
data modify storage nnchat:s q[47] set compute default float nnchat:l1_q_47
data modify storage nnchat:s q[48] set compute default float nnchat:l1_q_48
data modify storage nnchat:s q[49] set compute default float nnchat:l1_q_49
data modify storage nnchat:s q[50] set compute default float nnchat:l1_q_50
data modify storage nnchat:s q[51] set compute default float nnchat:l1_q_51
data modify storage nnchat:s q[52] set compute default float nnchat:l1_q_52
data modify storage nnchat:s q[53] set compute default float nnchat:l1_q_53
data modify storage nnchat:s q[54] set compute default float nnchat:l1_q_54
data modify storage nnchat:s q[55] set compute default float nnchat:l1_q_55
data modify storage nnchat:s q[56] set compute default float nnchat:l1_q_56
data modify storage nnchat:s q[57] set compute default float nnchat:l1_q_57
data modify storage nnchat:s q[58] set compute default float nnchat:l1_q_58
data modify storage nnchat:s q[59] set compute default float nnchat:l1_q_59
data modify storage nnchat:s q[60] set compute default float nnchat:l1_q_60
data modify storage nnchat:s q[61] set compute default float nnchat:l1_q_61
data modify storage nnchat:s q[62] set compute default float nnchat:l1_q_62
data modify storage nnchat:s q[63] set compute default float nnchat:l1_q_63
data modify storage nnchat:s k[0] set compute default float nnchat:l1_k_0
data modify storage nnchat:s k[1] set compute default float nnchat:l1_k_1
data modify storage nnchat:s k[2] set compute default float nnchat:l1_k_2
data modify storage nnchat:s k[3] set compute default float nnchat:l1_k_3
data modify storage nnchat:s k[4] set compute default float nnchat:l1_k_4
data modify storage nnchat:s k[5] set compute default float nnchat:l1_k_5
data modify storage nnchat:s k[6] set compute default float nnchat:l1_k_6
data modify storage nnchat:s k[7] set compute default float nnchat:l1_k_7
data modify storage nnchat:s k[8] set compute default float nnchat:l1_k_8
data modify storage nnchat:s k[9] set compute default float nnchat:l1_k_9
data modify storage nnchat:s k[10] set compute default float nnchat:l1_k_10
data modify storage nnchat:s k[11] set compute default float nnchat:l1_k_11
data modify storage nnchat:s k[12] set compute default float nnchat:l1_k_12
data modify storage nnchat:s k[13] set compute default float nnchat:l1_k_13
data modify storage nnchat:s k[14] set compute default float nnchat:l1_k_14
data modify storage nnchat:s k[15] set compute default float nnchat:l1_k_15
data modify storage nnchat:s k[16] set compute default float nnchat:l1_k_16
data modify storage nnchat:s k[17] set compute default float nnchat:l1_k_17
data modify storage nnchat:s k[18] set compute default float nnchat:l1_k_18
data modify storage nnchat:s k[19] set compute default float nnchat:l1_k_19
data modify storage nnchat:s k[20] set compute default float nnchat:l1_k_20
data modify storage nnchat:s k[21] set compute default float nnchat:l1_k_21
data modify storage nnchat:s k[22] set compute default float nnchat:l1_k_22
data modify storage nnchat:s k[23] set compute default float nnchat:l1_k_23
data modify storage nnchat:s k[24] set compute default float nnchat:l1_k_24
data modify storage nnchat:s k[25] set compute default float nnchat:l1_k_25
data modify storage nnchat:s k[26] set compute default float nnchat:l1_k_26
data modify storage nnchat:s k[27] set compute default float nnchat:l1_k_27
data modify storage nnchat:s k[28] set compute default float nnchat:l1_k_28
data modify storage nnchat:s k[29] set compute default float nnchat:l1_k_29
data modify storage nnchat:s k[30] set compute default float nnchat:l1_k_30
data modify storage nnchat:s k[31] set compute default float nnchat:l1_k_31
data modify storage nnchat:s k[32] set compute default float nnchat:l1_k_32
data modify storage nnchat:s k[33] set compute default float nnchat:l1_k_33
data modify storage nnchat:s k[34] set compute default float nnchat:l1_k_34
data modify storage nnchat:s k[35] set compute default float nnchat:l1_k_35
data modify storage nnchat:s k[36] set compute default float nnchat:l1_k_36
data modify storage nnchat:s k[37] set compute default float nnchat:l1_k_37
data modify storage nnchat:s k[38] set compute default float nnchat:l1_k_38
data modify storage nnchat:s k[39] set compute default float nnchat:l1_k_39
data modify storage nnchat:s k[40] set compute default float nnchat:l1_k_40
data modify storage nnchat:s k[41] set compute default float nnchat:l1_k_41
data modify storage nnchat:s k[42] set compute default float nnchat:l1_k_42
data modify storage nnchat:s k[43] set compute default float nnchat:l1_k_43
data modify storage nnchat:s k[44] set compute default float nnchat:l1_k_44
data modify storage nnchat:s k[45] set compute default float nnchat:l1_k_45
data modify storage nnchat:s k[46] set compute default float nnchat:l1_k_46
data modify storage nnchat:s k[47] set compute default float nnchat:l1_k_47
data modify storage nnchat:s k[48] set compute default float nnchat:l1_k_48
data modify storage nnchat:s k[49] set compute default float nnchat:l1_k_49
data modify storage nnchat:s k[50] set compute default float nnchat:l1_k_50
data modify storage nnchat:s k[51] set compute default float nnchat:l1_k_51
data modify storage nnchat:s k[52] set compute default float nnchat:l1_k_52
data modify storage nnchat:s k[53] set compute default float nnchat:l1_k_53
data modify storage nnchat:s k[54] set compute default float nnchat:l1_k_54
data modify storage nnchat:s k[55] set compute default float nnchat:l1_k_55
data modify storage nnchat:s k[56] set compute default float nnchat:l1_k_56
data modify storage nnchat:s k[57] set compute default float nnchat:l1_k_57
data modify storage nnchat:s k[58] set compute default float nnchat:l1_k_58
data modify storage nnchat:s k[59] set compute default float nnchat:l1_k_59
data modify storage nnchat:s k[60] set compute default float nnchat:l1_k_60
data modify storage nnchat:s k[61] set compute default float nnchat:l1_k_61
data modify storage nnchat:s k[62] set compute default float nnchat:l1_k_62
data modify storage nnchat:s k[63] set compute default float nnchat:l1_k_63
data modify storage nnchat:s v[0] set compute default float nnchat:l1_v_0
data modify storage nnchat:s v[1] set compute default float nnchat:l1_v_1
data modify storage nnchat:s v[2] set compute default float nnchat:l1_v_2
data modify storage nnchat:s v[3] set compute default float nnchat:l1_v_3
data modify storage nnchat:s v[4] set compute default float nnchat:l1_v_4
data modify storage nnchat:s v[5] set compute default float nnchat:l1_v_5
data modify storage nnchat:s v[6] set compute default float nnchat:l1_v_6
data modify storage nnchat:s v[7] set compute default float nnchat:l1_v_7
data modify storage nnchat:s v[8] set compute default float nnchat:l1_v_8
data modify storage nnchat:s v[9] set compute default float nnchat:l1_v_9
data modify storage nnchat:s v[10] set compute default float nnchat:l1_v_10
data modify storage nnchat:s v[11] set compute default float nnchat:l1_v_11
data modify storage nnchat:s v[12] set compute default float nnchat:l1_v_12
data modify storage nnchat:s v[13] set compute default float nnchat:l1_v_13
data modify storage nnchat:s v[14] set compute default float nnchat:l1_v_14
data modify storage nnchat:s v[15] set compute default float nnchat:l1_v_15
data modify storage nnchat:s v[16] set compute default float nnchat:l1_v_16
data modify storage nnchat:s v[17] set compute default float nnchat:l1_v_17
data modify storage nnchat:s v[18] set compute default float nnchat:l1_v_18
data modify storage nnchat:s v[19] set compute default float nnchat:l1_v_19
data modify storage nnchat:s v[20] set compute default float nnchat:l1_v_20
data modify storage nnchat:s v[21] set compute default float nnchat:l1_v_21
data modify storage nnchat:s v[22] set compute default float nnchat:l1_v_22
data modify storage nnchat:s v[23] set compute default float nnchat:l1_v_23
data modify storage nnchat:s v[24] set compute default float nnchat:l1_v_24
data modify storage nnchat:s v[25] set compute default float nnchat:l1_v_25
data modify storage nnchat:s v[26] set compute default float nnchat:l1_v_26
data modify storage nnchat:s v[27] set compute default float nnchat:l1_v_27
data modify storage nnchat:s v[28] set compute default float nnchat:l1_v_28
data modify storage nnchat:s v[29] set compute default float nnchat:l1_v_29
data modify storage nnchat:s v[30] set compute default float nnchat:l1_v_30
data modify storage nnchat:s v[31] set compute default float nnchat:l1_v_31
data modify storage nnchat:s v[32] set compute default float nnchat:l1_v_32
data modify storage nnchat:s v[33] set compute default float nnchat:l1_v_33
data modify storage nnchat:s v[34] set compute default float nnchat:l1_v_34
data modify storage nnchat:s v[35] set compute default float nnchat:l1_v_35
data modify storage nnchat:s v[36] set compute default float nnchat:l1_v_36
data modify storage nnchat:s v[37] set compute default float nnchat:l1_v_37
data modify storage nnchat:s v[38] set compute default float nnchat:l1_v_38
data modify storage nnchat:s v[39] set compute default float nnchat:l1_v_39
data modify storage nnchat:s v[40] set compute default float nnchat:l1_v_40
data modify storage nnchat:s v[41] set compute default float nnchat:l1_v_41
data modify storage nnchat:s v[42] set compute default float nnchat:l1_v_42
data modify storage nnchat:s v[43] set compute default float nnchat:l1_v_43
data modify storage nnchat:s v[44] set compute default float nnchat:l1_v_44
data modify storage nnchat:s v[45] set compute default float nnchat:l1_v_45
data modify storage nnchat:s v[46] set compute default float nnchat:l1_v_46
data modify storage nnchat:s v[47] set compute default float nnchat:l1_v_47
data modify storage nnchat:s v[48] set compute default float nnchat:l1_v_48
data modify storage nnchat:s v[49] set compute default float nnchat:l1_v_49
data modify storage nnchat:s v[50] set compute default float nnchat:l1_v_50
data modify storage nnchat:s v[51] set compute default float nnchat:l1_v_51
data modify storage nnchat:s v[52] set compute default float nnchat:l1_v_52
data modify storage nnchat:s v[53] set compute default float nnchat:l1_v_53
data modify storage nnchat:s v[54] set compute default float nnchat:l1_v_54
data modify storage nnchat:s v[55] set compute default float nnchat:l1_v_55
data modify storage nnchat:s v[56] set compute default float nnchat:l1_v_56
data modify storage nnchat:s v[57] set compute default float nnchat:l1_v_57
data modify storage nnchat:s v[58] set compute default float nnchat:l1_v_58
data modify storage nnchat:s v[59] set compute default float nnchat:l1_v_59
data modify storage nnchat:s v[60] set compute default float nnchat:l1_v_60
data modify storage nnchat:s v[61] set compute default float nnchat:l1_v_61
data modify storage nnchat:s v[62] set compute default float nnchat:l1_v_62
data modify storage nnchat:s v[63] set compute default float nnchat:l1_v_63
data modify storage nnchat:s kc1 append from storage nnchat:s k
data modify storage nnchat:s vc1 append from storage nnchat:s v
# --- 层 1: 注意力 ---
data modify storage nnchat:s s0[0] set compute default float nnchat:l1_s0_0
data modify storage nnchat:s s0[1] set compute default float nnchat:l1_s0_1
data modify storage nnchat:s s0[2] set compute default float nnchat:l1_s0_2
data modify storage nnchat:s s0[3] set compute default float nnchat:l1_s0_3
data modify storage nnchat:s s0[4] set compute default float nnchat:l1_s0_4
data modify storage nnchat:s s0[5] set compute default float nnchat:l1_s0_5
data modify storage nnchat:s s0[6] set compute default float nnchat:l1_s0_6
data modify storage nnchat:s s0[7] set compute default float nnchat:l1_s0_7
data modify storage nnchat:s s0[8] set compute default float nnchat:l1_s0_8
data modify storage nnchat:s s0[9] set compute default float nnchat:l1_s0_9
data modify storage nnchat:s s0[10] set compute default float nnchat:l1_s0_10
data modify storage nnchat:s s0[11] set compute default float nnchat:l1_s0_11
data modify storage nnchat:s s0[12] set compute default float nnchat:l1_s0_12
data modify storage nnchat:s s0[13] set compute default float nnchat:l1_s0_13
data modify storage nnchat:s s0[14] set compute default float nnchat:l1_s0_14
data modify storage nnchat:s s0[15] set compute default float nnchat:l1_s0_15
data modify storage nnchat:s s0[16] set compute default float nnchat:l1_s0_16
data modify storage nnchat:s s0[17] set compute default float nnchat:l1_s0_17
data modify storage nnchat:s s0[18] set compute default float nnchat:l1_s0_18
data modify storage nnchat:s s0[19] set compute default float nnchat:l1_s0_19
data modify storage nnchat:s s0[20] set compute default float nnchat:l1_s0_20
data modify storage nnchat:s s0[21] set compute default float nnchat:l1_s0_21
data modify storage nnchat:s s0[22] set compute default float nnchat:l1_s0_22
data modify storage nnchat:s s0[23] set compute default float nnchat:l1_s0_23
data modify storage nnchat:s s0[24] set compute default float nnchat:l1_s0_24
data modify storage nnchat:s s0[25] set compute default float nnchat:l1_s0_25
data modify storage nnchat:s s0[26] set compute default float nnchat:l1_s0_26
data modify storage nnchat:s s0[27] set compute default float nnchat:l1_s0_27
data modify storage nnchat:s s0[28] set compute default float nnchat:l1_s0_28
data modify storage nnchat:s s0[29] set compute default float nnchat:l1_s0_29
data modify storage nnchat:s s0[30] set compute default float nnchat:l1_s0_30
data modify storage nnchat:s s0[31] set compute default float nnchat:l1_s0_31
data modify storage nnchat:s s0[32] set compute default float nnchat:l1_s0_32
data modify storage nnchat:s s0[33] set compute default float nnchat:l1_s0_33
data modify storage nnchat:s s0[34] set compute default float nnchat:l1_s0_34
data modify storage nnchat:s s0[35] set compute default float nnchat:l1_s0_35
data modify storage nnchat:s s0[36] set compute default float nnchat:l1_s0_36
data modify storage nnchat:s s0[37] set compute default float nnchat:l1_s0_37
data modify storage nnchat:s s0[38] set compute default float nnchat:l1_s0_38
data modify storage nnchat:s s0[39] set compute default float nnchat:l1_s0_39
data modify storage nnchat:s s0[40] set compute default float nnchat:l1_s0_40
data modify storage nnchat:s s0[41] set compute default float nnchat:l1_s0_41
data modify storage nnchat:s s0[42] set compute default float nnchat:l1_s0_42
data modify storage nnchat:s s0[43] set compute default float nnchat:l1_s0_43
data modify storage nnchat:s s0[44] set compute default float nnchat:l1_s0_44
data modify storage nnchat:s s0[45] set compute default float nnchat:l1_s0_45
data modify storage nnchat:s s0[46] set compute default float nnchat:l1_s0_46
data modify storage nnchat:s s0[47] set compute default float nnchat:l1_s0_47
data modify storage nnchat:s s0[48] set compute default float nnchat:l1_s0_48
data modify storage nnchat:s s0[49] set compute default float nnchat:l1_s0_49
data modify storage nnchat:s s0[50] set compute default float nnchat:l1_s0_50
data modify storage nnchat:s s0[51] set compute default float nnchat:l1_s0_51
data modify storage nnchat:s s0[52] set compute default float nnchat:l1_s0_52
data modify storage nnchat:s s0[53] set compute default float nnchat:l1_s0_53
data modify storage nnchat:s s0[54] set compute default float nnchat:l1_s0_54
data modify storage nnchat:s s0[55] set compute default float nnchat:l1_s0_55
data modify storage nnchat:s s0[56] set compute default float nnchat:l1_s0_56
data modify storage nnchat:s s0[57] set compute default float nnchat:l1_s0_57
data modify storage nnchat:s s0[58] set compute default float nnchat:l1_s0_58
data modify storage nnchat:s s0[59] set compute default float nnchat:l1_s0_59
data modify storage nnchat:s s0[60] set compute default float nnchat:l1_s0_60
data modify storage nnchat:s s0[61] set compute default float nnchat:l1_s0_61
data modify storage nnchat:s s0[62] set compute default float nnchat:l1_s0_62
data modify storage nnchat:s s0[63] set compute default float nnchat:l1_s0_63
data modify storage nnchat:s s1[0] set compute default float nnchat:l1_s1_0
data modify storage nnchat:s s1[1] set compute default float nnchat:l1_s1_1
data modify storage nnchat:s s1[2] set compute default float nnchat:l1_s1_2
data modify storage nnchat:s s1[3] set compute default float nnchat:l1_s1_3
data modify storage nnchat:s s1[4] set compute default float nnchat:l1_s1_4
data modify storage nnchat:s s1[5] set compute default float nnchat:l1_s1_5
data modify storage nnchat:s s1[6] set compute default float nnchat:l1_s1_6
data modify storage nnchat:s s1[7] set compute default float nnchat:l1_s1_7
data modify storage nnchat:s s1[8] set compute default float nnchat:l1_s1_8
data modify storage nnchat:s s1[9] set compute default float nnchat:l1_s1_9
data modify storage nnchat:s s1[10] set compute default float nnchat:l1_s1_10
data modify storage nnchat:s s1[11] set compute default float nnchat:l1_s1_11
data modify storage nnchat:s s1[12] set compute default float nnchat:l1_s1_12
data modify storage nnchat:s s1[13] set compute default float nnchat:l1_s1_13
data modify storage nnchat:s s1[14] set compute default float nnchat:l1_s1_14
data modify storage nnchat:s s1[15] set compute default float nnchat:l1_s1_15
data modify storage nnchat:s s1[16] set compute default float nnchat:l1_s1_16
data modify storage nnchat:s s1[17] set compute default float nnchat:l1_s1_17
data modify storage nnchat:s s1[18] set compute default float nnchat:l1_s1_18
data modify storage nnchat:s s1[19] set compute default float nnchat:l1_s1_19
data modify storage nnchat:s s1[20] set compute default float nnchat:l1_s1_20
data modify storage nnchat:s s1[21] set compute default float nnchat:l1_s1_21
data modify storage nnchat:s s1[22] set compute default float nnchat:l1_s1_22
data modify storage nnchat:s s1[23] set compute default float nnchat:l1_s1_23
data modify storage nnchat:s s1[24] set compute default float nnchat:l1_s1_24
data modify storage nnchat:s s1[25] set compute default float nnchat:l1_s1_25
data modify storage nnchat:s s1[26] set compute default float nnchat:l1_s1_26
data modify storage nnchat:s s1[27] set compute default float nnchat:l1_s1_27
data modify storage nnchat:s s1[28] set compute default float nnchat:l1_s1_28
data modify storage nnchat:s s1[29] set compute default float nnchat:l1_s1_29
data modify storage nnchat:s s1[30] set compute default float nnchat:l1_s1_30
data modify storage nnchat:s s1[31] set compute default float nnchat:l1_s1_31
data modify storage nnchat:s s1[32] set compute default float nnchat:l1_s1_32
data modify storage nnchat:s s1[33] set compute default float nnchat:l1_s1_33
data modify storage nnchat:s s1[34] set compute default float nnchat:l1_s1_34
data modify storage nnchat:s s1[35] set compute default float nnchat:l1_s1_35
data modify storage nnchat:s s1[36] set compute default float nnchat:l1_s1_36
data modify storage nnchat:s s1[37] set compute default float nnchat:l1_s1_37
data modify storage nnchat:s s1[38] set compute default float nnchat:l1_s1_38
data modify storage nnchat:s s1[39] set compute default float nnchat:l1_s1_39
data modify storage nnchat:s s1[40] set compute default float nnchat:l1_s1_40
data modify storage nnchat:s s1[41] set compute default float nnchat:l1_s1_41
data modify storage nnchat:s s1[42] set compute default float nnchat:l1_s1_42
data modify storage nnchat:s s1[43] set compute default float nnchat:l1_s1_43
data modify storage nnchat:s s1[44] set compute default float nnchat:l1_s1_44
data modify storage nnchat:s s1[45] set compute default float nnchat:l1_s1_45
data modify storage nnchat:s s1[46] set compute default float nnchat:l1_s1_46
data modify storage nnchat:s s1[47] set compute default float nnchat:l1_s1_47
data modify storage nnchat:s s1[48] set compute default float nnchat:l1_s1_48
data modify storage nnchat:s s1[49] set compute default float nnchat:l1_s1_49
data modify storage nnchat:s s1[50] set compute default float nnchat:l1_s1_50
data modify storage nnchat:s s1[51] set compute default float nnchat:l1_s1_51
data modify storage nnchat:s s1[52] set compute default float nnchat:l1_s1_52
data modify storage nnchat:s s1[53] set compute default float nnchat:l1_s1_53
data modify storage nnchat:s s1[54] set compute default float nnchat:l1_s1_54
data modify storage nnchat:s s1[55] set compute default float nnchat:l1_s1_55
data modify storage nnchat:s s1[56] set compute default float nnchat:l1_s1_56
data modify storage nnchat:s s1[57] set compute default float nnchat:l1_s1_57
data modify storage nnchat:s s1[58] set compute default float nnchat:l1_s1_58
data modify storage nnchat:s s1[59] set compute default float nnchat:l1_s1_59
data modify storage nnchat:s s1[60] set compute default float nnchat:l1_s1_60
data modify storage nnchat:s s1[61] set compute default float nnchat:l1_s1_61
data modify storage nnchat:s s1[62] set compute default float nnchat:l1_s1_62
data modify storage nnchat:s s1[63] set compute default float nnchat:l1_s1_63
data modify storage nnchat:s mx0 set compute default float nnchat:l1_mx0
data modify storage nnchat:s mx1 set compute default float nnchat:l1_mx1
data modify storage nnchat:s e0[0] set compute default float nnchat:l1_e0_0
data modify storage nnchat:s e0[1] set compute default float nnchat:l1_e0_1
data modify storage nnchat:s e0[2] set compute default float nnchat:l1_e0_2
data modify storage nnchat:s e0[3] set compute default float nnchat:l1_e0_3
data modify storage nnchat:s e0[4] set compute default float nnchat:l1_e0_4
data modify storage nnchat:s e0[5] set compute default float nnchat:l1_e0_5
data modify storage nnchat:s e0[6] set compute default float nnchat:l1_e0_6
data modify storage nnchat:s e0[7] set compute default float nnchat:l1_e0_7
data modify storage nnchat:s e0[8] set compute default float nnchat:l1_e0_8
data modify storage nnchat:s e0[9] set compute default float nnchat:l1_e0_9
data modify storage nnchat:s e0[10] set compute default float nnchat:l1_e0_10
data modify storage nnchat:s e0[11] set compute default float nnchat:l1_e0_11
data modify storage nnchat:s e0[12] set compute default float nnchat:l1_e0_12
data modify storage nnchat:s e0[13] set compute default float nnchat:l1_e0_13
data modify storage nnchat:s e0[14] set compute default float nnchat:l1_e0_14
data modify storage nnchat:s e0[15] set compute default float nnchat:l1_e0_15
data modify storage nnchat:s e0[16] set compute default float nnchat:l1_e0_16
data modify storage nnchat:s e0[17] set compute default float nnchat:l1_e0_17
data modify storage nnchat:s e0[18] set compute default float nnchat:l1_e0_18
data modify storage nnchat:s e0[19] set compute default float nnchat:l1_e0_19
data modify storage nnchat:s e0[20] set compute default float nnchat:l1_e0_20
data modify storage nnchat:s e0[21] set compute default float nnchat:l1_e0_21
data modify storage nnchat:s e0[22] set compute default float nnchat:l1_e0_22
data modify storage nnchat:s e0[23] set compute default float nnchat:l1_e0_23
data modify storage nnchat:s e0[24] set compute default float nnchat:l1_e0_24
data modify storage nnchat:s e0[25] set compute default float nnchat:l1_e0_25
data modify storage nnchat:s e0[26] set compute default float nnchat:l1_e0_26
data modify storage nnchat:s e0[27] set compute default float nnchat:l1_e0_27
data modify storage nnchat:s e0[28] set compute default float nnchat:l1_e0_28
data modify storage nnchat:s e0[29] set compute default float nnchat:l1_e0_29
data modify storage nnchat:s e0[30] set compute default float nnchat:l1_e0_30
data modify storage nnchat:s e0[31] set compute default float nnchat:l1_e0_31
data modify storage nnchat:s e0[32] set compute default float nnchat:l1_e0_32
data modify storage nnchat:s e0[33] set compute default float nnchat:l1_e0_33
data modify storage nnchat:s e0[34] set compute default float nnchat:l1_e0_34
data modify storage nnchat:s e0[35] set compute default float nnchat:l1_e0_35
data modify storage nnchat:s e0[36] set compute default float nnchat:l1_e0_36
data modify storage nnchat:s e0[37] set compute default float nnchat:l1_e0_37
data modify storage nnchat:s e0[38] set compute default float nnchat:l1_e0_38
data modify storage nnchat:s e0[39] set compute default float nnchat:l1_e0_39
data modify storage nnchat:s e0[40] set compute default float nnchat:l1_e0_40
data modify storage nnchat:s e0[41] set compute default float nnchat:l1_e0_41
data modify storage nnchat:s e0[42] set compute default float nnchat:l1_e0_42
data modify storage nnchat:s e0[43] set compute default float nnchat:l1_e0_43
data modify storage nnchat:s e0[44] set compute default float nnchat:l1_e0_44
data modify storage nnchat:s e0[45] set compute default float nnchat:l1_e0_45
data modify storage nnchat:s e0[46] set compute default float nnchat:l1_e0_46
data modify storage nnchat:s e0[47] set compute default float nnchat:l1_e0_47
data modify storage nnchat:s e0[48] set compute default float nnchat:l1_e0_48
data modify storage nnchat:s e0[49] set compute default float nnchat:l1_e0_49
data modify storage nnchat:s e0[50] set compute default float nnchat:l1_e0_50
data modify storage nnchat:s e0[51] set compute default float nnchat:l1_e0_51
data modify storage nnchat:s e0[52] set compute default float nnchat:l1_e0_52
data modify storage nnchat:s e0[53] set compute default float nnchat:l1_e0_53
data modify storage nnchat:s e0[54] set compute default float nnchat:l1_e0_54
data modify storage nnchat:s e0[55] set compute default float nnchat:l1_e0_55
data modify storage nnchat:s e0[56] set compute default float nnchat:l1_e0_56
data modify storage nnchat:s e0[57] set compute default float nnchat:l1_e0_57
data modify storage nnchat:s e0[58] set compute default float nnchat:l1_e0_58
data modify storage nnchat:s e0[59] set compute default float nnchat:l1_e0_59
data modify storage nnchat:s e0[60] set compute default float nnchat:l1_e0_60
data modify storage nnchat:s e0[61] set compute default float nnchat:l1_e0_61
data modify storage nnchat:s e0[62] set compute default float nnchat:l1_e0_62
data modify storage nnchat:s e0[63] set compute default float nnchat:l1_e0_63
data modify storage nnchat:s e1[0] set compute default float nnchat:l1_e1_0
data modify storage nnchat:s e1[1] set compute default float nnchat:l1_e1_1
data modify storage nnchat:s e1[2] set compute default float nnchat:l1_e1_2
data modify storage nnchat:s e1[3] set compute default float nnchat:l1_e1_3
data modify storage nnchat:s e1[4] set compute default float nnchat:l1_e1_4
data modify storage nnchat:s e1[5] set compute default float nnchat:l1_e1_5
data modify storage nnchat:s e1[6] set compute default float nnchat:l1_e1_6
data modify storage nnchat:s e1[7] set compute default float nnchat:l1_e1_7
data modify storage nnchat:s e1[8] set compute default float nnchat:l1_e1_8
data modify storage nnchat:s e1[9] set compute default float nnchat:l1_e1_9
data modify storage nnchat:s e1[10] set compute default float nnchat:l1_e1_10
data modify storage nnchat:s e1[11] set compute default float nnchat:l1_e1_11
data modify storage nnchat:s e1[12] set compute default float nnchat:l1_e1_12
data modify storage nnchat:s e1[13] set compute default float nnchat:l1_e1_13
data modify storage nnchat:s e1[14] set compute default float nnchat:l1_e1_14
data modify storage nnchat:s e1[15] set compute default float nnchat:l1_e1_15
data modify storage nnchat:s e1[16] set compute default float nnchat:l1_e1_16
data modify storage nnchat:s e1[17] set compute default float nnchat:l1_e1_17
data modify storage nnchat:s e1[18] set compute default float nnchat:l1_e1_18
data modify storage nnchat:s e1[19] set compute default float nnchat:l1_e1_19
data modify storage nnchat:s e1[20] set compute default float nnchat:l1_e1_20
data modify storage nnchat:s e1[21] set compute default float nnchat:l1_e1_21
data modify storage nnchat:s e1[22] set compute default float nnchat:l1_e1_22
data modify storage nnchat:s e1[23] set compute default float nnchat:l1_e1_23
data modify storage nnchat:s e1[24] set compute default float nnchat:l1_e1_24
data modify storage nnchat:s e1[25] set compute default float nnchat:l1_e1_25
data modify storage nnchat:s e1[26] set compute default float nnchat:l1_e1_26
data modify storage nnchat:s e1[27] set compute default float nnchat:l1_e1_27
data modify storage nnchat:s e1[28] set compute default float nnchat:l1_e1_28
data modify storage nnchat:s e1[29] set compute default float nnchat:l1_e1_29
data modify storage nnchat:s e1[30] set compute default float nnchat:l1_e1_30
data modify storage nnchat:s e1[31] set compute default float nnchat:l1_e1_31
data modify storage nnchat:s e1[32] set compute default float nnchat:l1_e1_32
data modify storage nnchat:s e1[33] set compute default float nnchat:l1_e1_33
data modify storage nnchat:s e1[34] set compute default float nnchat:l1_e1_34
data modify storage nnchat:s e1[35] set compute default float nnchat:l1_e1_35
data modify storage nnchat:s e1[36] set compute default float nnchat:l1_e1_36
data modify storage nnchat:s e1[37] set compute default float nnchat:l1_e1_37
data modify storage nnchat:s e1[38] set compute default float nnchat:l1_e1_38
data modify storage nnchat:s e1[39] set compute default float nnchat:l1_e1_39
data modify storage nnchat:s e1[40] set compute default float nnchat:l1_e1_40
data modify storage nnchat:s e1[41] set compute default float nnchat:l1_e1_41
data modify storage nnchat:s e1[42] set compute default float nnchat:l1_e1_42
data modify storage nnchat:s e1[43] set compute default float nnchat:l1_e1_43
data modify storage nnchat:s e1[44] set compute default float nnchat:l1_e1_44
data modify storage nnchat:s e1[45] set compute default float nnchat:l1_e1_45
data modify storage nnchat:s e1[46] set compute default float nnchat:l1_e1_46
data modify storage nnchat:s e1[47] set compute default float nnchat:l1_e1_47
data modify storage nnchat:s e1[48] set compute default float nnchat:l1_e1_48
data modify storage nnchat:s e1[49] set compute default float nnchat:l1_e1_49
data modify storage nnchat:s e1[50] set compute default float nnchat:l1_e1_50
data modify storage nnchat:s e1[51] set compute default float nnchat:l1_e1_51
data modify storage nnchat:s e1[52] set compute default float nnchat:l1_e1_52
data modify storage nnchat:s e1[53] set compute default float nnchat:l1_e1_53
data modify storage nnchat:s e1[54] set compute default float nnchat:l1_e1_54
data modify storage nnchat:s e1[55] set compute default float nnchat:l1_e1_55
data modify storage nnchat:s e1[56] set compute default float nnchat:l1_e1_56
data modify storage nnchat:s e1[57] set compute default float nnchat:l1_e1_57
data modify storage nnchat:s e1[58] set compute default float nnchat:l1_e1_58
data modify storage nnchat:s e1[59] set compute default float nnchat:l1_e1_59
data modify storage nnchat:s e1[60] set compute default float nnchat:l1_e1_60
data modify storage nnchat:s e1[61] set compute default float nnchat:l1_e1_61
data modify storage nnchat:s e1[62] set compute default float nnchat:l1_e1_62
data modify storage nnchat:s e1[63] set compute default float nnchat:l1_e1_63
data modify storage nnchat:s dn0 set compute default float nnchat:l1_dn0
data modify storage nnchat:s dn1 set compute default float nnchat:l1_dn1
data modify storage nnchat:s p0[0] set compute default float nnchat:l1_p0_0
data modify storage nnchat:s p0[1] set compute default float nnchat:l1_p0_1
data modify storage nnchat:s p0[2] set compute default float nnchat:l1_p0_2
data modify storage nnchat:s p0[3] set compute default float nnchat:l1_p0_3
data modify storage nnchat:s p0[4] set compute default float nnchat:l1_p0_4
data modify storage nnchat:s p0[5] set compute default float nnchat:l1_p0_5
data modify storage nnchat:s p0[6] set compute default float nnchat:l1_p0_6
data modify storage nnchat:s p0[7] set compute default float nnchat:l1_p0_7
data modify storage nnchat:s p0[8] set compute default float nnchat:l1_p0_8
data modify storage nnchat:s p0[9] set compute default float nnchat:l1_p0_9
data modify storage nnchat:s p0[10] set compute default float nnchat:l1_p0_10
data modify storage nnchat:s p0[11] set compute default float nnchat:l1_p0_11
data modify storage nnchat:s p0[12] set compute default float nnchat:l1_p0_12
data modify storage nnchat:s p0[13] set compute default float nnchat:l1_p0_13
data modify storage nnchat:s p0[14] set compute default float nnchat:l1_p0_14
data modify storage nnchat:s p0[15] set compute default float nnchat:l1_p0_15
data modify storage nnchat:s p0[16] set compute default float nnchat:l1_p0_16
data modify storage nnchat:s p0[17] set compute default float nnchat:l1_p0_17
data modify storage nnchat:s p0[18] set compute default float nnchat:l1_p0_18
data modify storage nnchat:s p0[19] set compute default float nnchat:l1_p0_19
data modify storage nnchat:s p0[20] set compute default float nnchat:l1_p0_20
data modify storage nnchat:s p0[21] set compute default float nnchat:l1_p0_21
data modify storage nnchat:s p0[22] set compute default float nnchat:l1_p0_22
data modify storage nnchat:s p0[23] set compute default float nnchat:l1_p0_23
data modify storage nnchat:s p0[24] set compute default float nnchat:l1_p0_24
data modify storage nnchat:s p0[25] set compute default float nnchat:l1_p0_25
data modify storage nnchat:s p0[26] set compute default float nnchat:l1_p0_26
data modify storage nnchat:s p0[27] set compute default float nnchat:l1_p0_27
data modify storage nnchat:s p0[28] set compute default float nnchat:l1_p0_28
data modify storage nnchat:s p0[29] set compute default float nnchat:l1_p0_29
data modify storage nnchat:s p0[30] set compute default float nnchat:l1_p0_30
data modify storage nnchat:s p0[31] set compute default float nnchat:l1_p0_31
data modify storage nnchat:s p0[32] set compute default float nnchat:l1_p0_32
data modify storage nnchat:s p0[33] set compute default float nnchat:l1_p0_33
data modify storage nnchat:s p0[34] set compute default float nnchat:l1_p0_34
data modify storage nnchat:s p0[35] set compute default float nnchat:l1_p0_35
data modify storage nnchat:s p0[36] set compute default float nnchat:l1_p0_36
data modify storage nnchat:s p0[37] set compute default float nnchat:l1_p0_37
data modify storage nnchat:s p0[38] set compute default float nnchat:l1_p0_38
data modify storage nnchat:s p0[39] set compute default float nnchat:l1_p0_39
data modify storage nnchat:s p0[40] set compute default float nnchat:l1_p0_40
data modify storage nnchat:s p0[41] set compute default float nnchat:l1_p0_41
data modify storage nnchat:s p0[42] set compute default float nnchat:l1_p0_42
data modify storage nnchat:s p0[43] set compute default float nnchat:l1_p0_43
data modify storage nnchat:s p0[44] set compute default float nnchat:l1_p0_44
data modify storage nnchat:s p0[45] set compute default float nnchat:l1_p0_45
data modify storage nnchat:s p0[46] set compute default float nnchat:l1_p0_46
data modify storage nnchat:s p0[47] set compute default float nnchat:l1_p0_47
data modify storage nnchat:s p0[48] set compute default float nnchat:l1_p0_48
data modify storage nnchat:s p0[49] set compute default float nnchat:l1_p0_49
data modify storage nnchat:s p0[50] set compute default float nnchat:l1_p0_50
data modify storage nnchat:s p0[51] set compute default float nnchat:l1_p0_51
data modify storage nnchat:s p0[52] set compute default float nnchat:l1_p0_52
data modify storage nnchat:s p0[53] set compute default float nnchat:l1_p0_53
data modify storage nnchat:s p0[54] set compute default float nnchat:l1_p0_54
data modify storage nnchat:s p0[55] set compute default float nnchat:l1_p0_55
data modify storage nnchat:s p0[56] set compute default float nnchat:l1_p0_56
data modify storage nnchat:s p0[57] set compute default float nnchat:l1_p0_57
data modify storage nnchat:s p0[58] set compute default float nnchat:l1_p0_58
data modify storage nnchat:s p0[59] set compute default float nnchat:l1_p0_59
data modify storage nnchat:s p0[60] set compute default float nnchat:l1_p0_60
data modify storage nnchat:s p0[61] set compute default float nnchat:l1_p0_61
data modify storage nnchat:s p0[62] set compute default float nnchat:l1_p0_62
data modify storage nnchat:s p0[63] set compute default float nnchat:l1_p0_63
data modify storage nnchat:s p1[0] set compute default float nnchat:l1_p1_0
data modify storage nnchat:s p1[1] set compute default float nnchat:l1_p1_1
data modify storage nnchat:s p1[2] set compute default float nnchat:l1_p1_2
data modify storage nnchat:s p1[3] set compute default float nnchat:l1_p1_3
data modify storage nnchat:s p1[4] set compute default float nnchat:l1_p1_4
data modify storage nnchat:s p1[5] set compute default float nnchat:l1_p1_5
data modify storage nnchat:s p1[6] set compute default float nnchat:l1_p1_6
data modify storage nnchat:s p1[7] set compute default float nnchat:l1_p1_7
data modify storage nnchat:s p1[8] set compute default float nnchat:l1_p1_8
data modify storage nnchat:s p1[9] set compute default float nnchat:l1_p1_9
data modify storage nnchat:s p1[10] set compute default float nnchat:l1_p1_10
data modify storage nnchat:s p1[11] set compute default float nnchat:l1_p1_11
data modify storage nnchat:s p1[12] set compute default float nnchat:l1_p1_12
data modify storage nnchat:s p1[13] set compute default float nnchat:l1_p1_13
data modify storage nnchat:s p1[14] set compute default float nnchat:l1_p1_14
data modify storage nnchat:s p1[15] set compute default float nnchat:l1_p1_15
data modify storage nnchat:s p1[16] set compute default float nnchat:l1_p1_16
data modify storage nnchat:s p1[17] set compute default float nnchat:l1_p1_17
data modify storage nnchat:s p1[18] set compute default float nnchat:l1_p1_18
data modify storage nnchat:s p1[19] set compute default float nnchat:l1_p1_19
data modify storage nnchat:s p1[20] set compute default float nnchat:l1_p1_20
data modify storage nnchat:s p1[21] set compute default float nnchat:l1_p1_21
data modify storage nnchat:s p1[22] set compute default float nnchat:l1_p1_22
data modify storage nnchat:s p1[23] set compute default float nnchat:l1_p1_23
data modify storage nnchat:s p1[24] set compute default float nnchat:l1_p1_24
data modify storage nnchat:s p1[25] set compute default float nnchat:l1_p1_25
data modify storage nnchat:s p1[26] set compute default float nnchat:l1_p1_26
data modify storage nnchat:s p1[27] set compute default float nnchat:l1_p1_27
data modify storage nnchat:s p1[28] set compute default float nnchat:l1_p1_28
data modify storage nnchat:s p1[29] set compute default float nnchat:l1_p1_29
data modify storage nnchat:s p1[30] set compute default float nnchat:l1_p1_30
data modify storage nnchat:s p1[31] set compute default float nnchat:l1_p1_31
data modify storage nnchat:s p1[32] set compute default float nnchat:l1_p1_32
data modify storage nnchat:s p1[33] set compute default float nnchat:l1_p1_33
data modify storage nnchat:s p1[34] set compute default float nnchat:l1_p1_34
data modify storage nnchat:s p1[35] set compute default float nnchat:l1_p1_35
data modify storage nnchat:s p1[36] set compute default float nnchat:l1_p1_36
data modify storage nnchat:s p1[37] set compute default float nnchat:l1_p1_37
data modify storage nnchat:s p1[38] set compute default float nnchat:l1_p1_38
data modify storage nnchat:s p1[39] set compute default float nnchat:l1_p1_39
data modify storage nnchat:s p1[40] set compute default float nnchat:l1_p1_40
data modify storage nnchat:s p1[41] set compute default float nnchat:l1_p1_41
data modify storage nnchat:s p1[42] set compute default float nnchat:l1_p1_42
data modify storage nnchat:s p1[43] set compute default float nnchat:l1_p1_43
data modify storage nnchat:s p1[44] set compute default float nnchat:l1_p1_44
data modify storage nnchat:s p1[45] set compute default float nnchat:l1_p1_45
data modify storage nnchat:s p1[46] set compute default float nnchat:l1_p1_46
data modify storage nnchat:s p1[47] set compute default float nnchat:l1_p1_47
data modify storage nnchat:s p1[48] set compute default float nnchat:l1_p1_48
data modify storage nnchat:s p1[49] set compute default float nnchat:l1_p1_49
data modify storage nnchat:s p1[50] set compute default float nnchat:l1_p1_50
data modify storage nnchat:s p1[51] set compute default float nnchat:l1_p1_51
data modify storage nnchat:s p1[52] set compute default float nnchat:l1_p1_52
data modify storage nnchat:s p1[53] set compute default float nnchat:l1_p1_53
data modify storage nnchat:s p1[54] set compute default float nnchat:l1_p1_54
data modify storage nnchat:s p1[55] set compute default float nnchat:l1_p1_55
data modify storage nnchat:s p1[56] set compute default float nnchat:l1_p1_56
data modify storage nnchat:s p1[57] set compute default float nnchat:l1_p1_57
data modify storage nnchat:s p1[58] set compute default float nnchat:l1_p1_58
data modify storage nnchat:s p1[59] set compute default float nnchat:l1_p1_59
data modify storage nnchat:s p1[60] set compute default float nnchat:l1_p1_60
data modify storage nnchat:s p1[61] set compute default float nnchat:l1_p1_61
data modify storage nnchat:s p1[62] set compute default float nnchat:l1_p1_62
data modify storage nnchat:s p1[63] set compute default float nnchat:l1_p1_63
data modify storage nnchat:s ao[0] set compute default float nnchat:l1_ao_0
data modify storage nnchat:s ao[1] set compute default float nnchat:l1_ao_1
data modify storage nnchat:s ao[2] set compute default float nnchat:l1_ao_2
data modify storage nnchat:s ao[3] set compute default float nnchat:l1_ao_3
data modify storage nnchat:s ao[4] set compute default float nnchat:l1_ao_4
data modify storage nnchat:s ao[5] set compute default float nnchat:l1_ao_5
data modify storage nnchat:s ao[6] set compute default float nnchat:l1_ao_6
data modify storage nnchat:s ao[7] set compute default float nnchat:l1_ao_7
data modify storage nnchat:s ao[8] set compute default float nnchat:l1_ao_8
data modify storage nnchat:s ao[9] set compute default float nnchat:l1_ao_9
data modify storage nnchat:s ao[10] set compute default float nnchat:l1_ao_10
data modify storage nnchat:s ao[11] set compute default float nnchat:l1_ao_11
data modify storage nnchat:s ao[12] set compute default float nnchat:l1_ao_12
data modify storage nnchat:s ao[13] set compute default float nnchat:l1_ao_13
data modify storage nnchat:s ao[14] set compute default float nnchat:l1_ao_14
data modify storage nnchat:s ao[15] set compute default float nnchat:l1_ao_15
data modify storage nnchat:s ao[16] set compute default float nnchat:l1_ao_16
data modify storage nnchat:s ao[17] set compute default float nnchat:l1_ao_17
data modify storage nnchat:s ao[18] set compute default float nnchat:l1_ao_18
data modify storage nnchat:s ao[19] set compute default float nnchat:l1_ao_19
data modify storage nnchat:s ao[20] set compute default float nnchat:l1_ao_20
data modify storage nnchat:s ao[21] set compute default float nnchat:l1_ao_21
data modify storage nnchat:s ao[22] set compute default float nnchat:l1_ao_22
data modify storage nnchat:s ao[23] set compute default float nnchat:l1_ao_23
data modify storage nnchat:s ao[24] set compute default float nnchat:l1_ao_24
data modify storage nnchat:s ao[25] set compute default float nnchat:l1_ao_25
data modify storage nnchat:s ao[26] set compute default float nnchat:l1_ao_26
data modify storage nnchat:s ao[27] set compute default float nnchat:l1_ao_27
data modify storage nnchat:s ao[28] set compute default float nnchat:l1_ao_28
data modify storage nnchat:s ao[29] set compute default float nnchat:l1_ao_29
data modify storage nnchat:s ao[30] set compute default float nnchat:l1_ao_30
data modify storage nnchat:s ao[31] set compute default float nnchat:l1_ao_31
data modify storage nnchat:s ao[32] set compute default float nnchat:l1_ao_32
data modify storage nnchat:s ao[33] set compute default float nnchat:l1_ao_33
data modify storage nnchat:s ao[34] set compute default float nnchat:l1_ao_34
data modify storage nnchat:s ao[35] set compute default float nnchat:l1_ao_35
data modify storage nnchat:s ao[36] set compute default float nnchat:l1_ao_36
data modify storage nnchat:s ao[37] set compute default float nnchat:l1_ao_37
data modify storage nnchat:s ao[38] set compute default float nnchat:l1_ao_38
data modify storage nnchat:s ao[39] set compute default float nnchat:l1_ao_39
data modify storage nnchat:s ao[40] set compute default float nnchat:l1_ao_40
data modify storage nnchat:s ao[41] set compute default float nnchat:l1_ao_41
data modify storage nnchat:s ao[42] set compute default float nnchat:l1_ao_42
data modify storage nnchat:s ao[43] set compute default float nnchat:l1_ao_43
data modify storage nnchat:s ao[44] set compute default float nnchat:l1_ao_44
data modify storage nnchat:s ao[45] set compute default float nnchat:l1_ao_45
data modify storage nnchat:s ao[46] set compute default float nnchat:l1_ao_46
data modify storage nnchat:s ao[47] set compute default float nnchat:l1_ao_47
data modify storage nnchat:s ao[48] set compute default float nnchat:l1_ao_48
data modify storage nnchat:s ao[49] set compute default float nnchat:l1_ao_49
data modify storage nnchat:s ao[50] set compute default float nnchat:l1_ao_50
data modify storage nnchat:s ao[51] set compute default float nnchat:l1_ao_51
data modify storage nnchat:s ao[52] set compute default float nnchat:l1_ao_52
data modify storage nnchat:s ao[53] set compute default float nnchat:l1_ao_53
data modify storage nnchat:s ao[54] set compute default float nnchat:l1_ao_54
data modify storage nnchat:s ao[55] set compute default float nnchat:l1_ao_55
data modify storage nnchat:s ao[56] set compute default float nnchat:l1_ao_56
data modify storage nnchat:s ao[57] set compute default float nnchat:l1_ao_57
data modify storage nnchat:s ao[58] set compute default float nnchat:l1_ao_58
data modify storage nnchat:s ao[59] set compute default float nnchat:l1_ao_59
data modify storage nnchat:s ao[60] set compute default float nnchat:l1_ao_60
data modify storage nnchat:s ao[61] set compute default float nnchat:l1_ao_61
data modify storage nnchat:s ao[62] set compute default float nnchat:l1_ao_62
data modify storage nnchat:s ao[63] set compute default float nnchat:l1_ao_63
data modify storage nnchat:s x[0] set compute default float nnchat:l1_o_0
data modify storage nnchat:s x[1] set compute default float nnchat:l1_o_1
data modify storage nnchat:s x[2] set compute default float nnchat:l1_o_2
data modify storage nnchat:s x[3] set compute default float nnchat:l1_o_3
data modify storage nnchat:s x[4] set compute default float nnchat:l1_o_4
data modify storage nnchat:s x[5] set compute default float nnchat:l1_o_5
data modify storage nnchat:s x[6] set compute default float nnchat:l1_o_6
data modify storage nnchat:s x[7] set compute default float nnchat:l1_o_7
data modify storage nnchat:s x[8] set compute default float nnchat:l1_o_8
data modify storage nnchat:s x[9] set compute default float nnchat:l1_o_9
data modify storage nnchat:s x[10] set compute default float nnchat:l1_o_10
data modify storage nnchat:s x[11] set compute default float nnchat:l1_o_11
data modify storage nnchat:s x[12] set compute default float nnchat:l1_o_12
data modify storage nnchat:s x[13] set compute default float nnchat:l1_o_13
data modify storage nnchat:s x[14] set compute default float nnchat:l1_o_14
data modify storage nnchat:s x[15] set compute default float nnchat:l1_o_15
data modify storage nnchat:s x[16] set compute default float nnchat:l1_o_16
data modify storage nnchat:s x[17] set compute default float nnchat:l1_o_17
data modify storage nnchat:s x[18] set compute default float nnchat:l1_o_18
data modify storage nnchat:s x[19] set compute default float nnchat:l1_o_19
data modify storage nnchat:s x[20] set compute default float nnchat:l1_o_20
data modify storage nnchat:s x[21] set compute default float nnchat:l1_o_21
data modify storage nnchat:s x[22] set compute default float nnchat:l1_o_22
data modify storage nnchat:s x[23] set compute default float nnchat:l1_o_23
data modify storage nnchat:s x[24] set compute default float nnchat:l1_o_24
data modify storage nnchat:s x[25] set compute default float nnchat:l1_o_25
data modify storage nnchat:s x[26] set compute default float nnchat:l1_o_26
data modify storage nnchat:s x[27] set compute default float nnchat:l1_o_27
data modify storage nnchat:s x[28] set compute default float nnchat:l1_o_28
data modify storage nnchat:s x[29] set compute default float nnchat:l1_o_29
data modify storage nnchat:s x[30] set compute default float nnchat:l1_o_30
data modify storage nnchat:s x[31] set compute default float nnchat:l1_o_31
data modify storage nnchat:s x[32] set compute default float nnchat:l1_o_32
data modify storage nnchat:s x[33] set compute default float nnchat:l1_o_33
data modify storage nnchat:s x[34] set compute default float nnchat:l1_o_34
data modify storage nnchat:s x[35] set compute default float nnchat:l1_o_35
data modify storage nnchat:s x[36] set compute default float nnchat:l1_o_36
data modify storage nnchat:s x[37] set compute default float nnchat:l1_o_37
data modify storage nnchat:s x[38] set compute default float nnchat:l1_o_38
data modify storage nnchat:s x[39] set compute default float nnchat:l1_o_39
data modify storage nnchat:s x[40] set compute default float nnchat:l1_o_40
data modify storage nnchat:s x[41] set compute default float nnchat:l1_o_41
data modify storage nnchat:s x[42] set compute default float nnchat:l1_o_42
data modify storage nnchat:s x[43] set compute default float nnchat:l1_o_43
data modify storage nnchat:s x[44] set compute default float nnchat:l1_o_44
data modify storage nnchat:s x[45] set compute default float nnchat:l1_o_45
data modify storage nnchat:s x[46] set compute default float nnchat:l1_o_46
data modify storage nnchat:s x[47] set compute default float nnchat:l1_o_47
data modify storage nnchat:s x[48] set compute default float nnchat:l1_o_48
data modify storage nnchat:s x[49] set compute default float nnchat:l1_o_49
data modify storage nnchat:s x[50] set compute default float nnchat:l1_o_50
data modify storage nnchat:s x[51] set compute default float nnchat:l1_o_51
data modify storage nnchat:s x[52] set compute default float nnchat:l1_o_52
data modify storage nnchat:s x[53] set compute default float nnchat:l1_o_53
data modify storage nnchat:s x[54] set compute default float nnchat:l1_o_54
data modify storage nnchat:s x[55] set compute default float nnchat:l1_o_55
data modify storage nnchat:s x[56] set compute default float nnchat:l1_o_56
data modify storage nnchat:s x[57] set compute default float nnchat:l1_o_57
data modify storage nnchat:s x[58] set compute default float nnchat:l1_o_58
data modify storage nnchat:s x[59] set compute default float nnchat:l1_o_59
data modify storage nnchat:s x[60] set compute default float nnchat:l1_o_60
data modify storage nnchat:s x[61] set compute default float nnchat:l1_o_61
data modify storage nnchat:s x[62] set compute default float nnchat:l1_o_62
data modify storage nnchat:s x[63] set compute default float nnchat:l1_o_63
# --- 层 1: LN2 + FFN ---
data modify storage nnchat:s m set compute default float nnchat:l1_m2
data modify storage nnchat:s c[0] set compute default float nnchat:l1_c2_0
data modify storage nnchat:s c[1] set compute default float nnchat:l1_c2_1
data modify storage nnchat:s c[2] set compute default float nnchat:l1_c2_2
data modify storage nnchat:s c[3] set compute default float nnchat:l1_c2_3
data modify storage nnchat:s c[4] set compute default float nnchat:l1_c2_4
data modify storage nnchat:s c[5] set compute default float nnchat:l1_c2_5
data modify storage nnchat:s c[6] set compute default float nnchat:l1_c2_6
data modify storage nnchat:s c[7] set compute default float nnchat:l1_c2_7
data modify storage nnchat:s c[8] set compute default float nnchat:l1_c2_8
data modify storage nnchat:s c[9] set compute default float nnchat:l1_c2_9
data modify storage nnchat:s c[10] set compute default float nnchat:l1_c2_10
data modify storage nnchat:s c[11] set compute default float nnchat:l1_c2_11
data modify storage nnchat:s c[12] set compute default float nnchat:l1_c2_12
data modify storage nnchat:s c[13] set compute default float nnchat:l1_c2_13
data modify storage nnchat:s c[14] set compute default float nnchat:l1_c2_14
data modify storage nnchat:s c[15] set compute default float nnchat:l1_c2_15
data modify storage nnchat:s c[16] set compute default float nnchat:l1_c2_16
data modify storage nnchat:s c[17] set compute default float nnchat:l1_c2_17
data modify storage nnchat:s c[18] set compute default float nnchat:l1_c2_18
data modify storage nnchat:s c[19] set compute default float nnchat:l1_c2_19
data modify storage nnchat:s c[20] set compute default float nnchat:l1_c2_20
data modify storage nnchat:s c[21] set compute default float nnchat:l1_c2_21
data modify storage nnchat:s c[22] set compute default float nnchat:l1_c2_22
data modify storage nnchat:s c[23] set compute default float nnchat:l1_c2_23
data modify storage nnchat:s c[24] set compute default float nnchat:l1_c2_24
data modify storage nnchat:s c[25] set compute default float nnchat:l1_c2_25
data modify storage nnchat:s c[26] set compute default float nnchat:l1_c2_26
data modify storage nnchat:s c[27] set compute default float nnchat:l1_c2_27
data modify storage nnchat:s c[28] set compute default float nnchat:l1_c2_28
data modify storage nnchat:s c[29] set compute default float nnchat:l1_c2_29
data modify storage nnchat:s c[30] set compute default float nnchat:l1_c2_30
data modify storage nnchat:s c[31] set compute default float nnchat:l1_c2_31
data modify storage nnchat:s c[32] set compute default float nnchat:l1_c2_32
data modify storage nnchat:s c[33] set compute default float nnchat:l1_c2_33
data modify storage nnchat:s c[34] set compute default float nnchat:l1_c2_34
data modify storage nnchat:s c[35] set compute default float nnchat:l1_c2_35
data modify storage nnchat:s c[36] set compute default float nnchat:l1_c2_36
data modify storage nnchat:s c[37] set compute default float nnchat:l1_c2_37
data modify storage nnchat:s c[38] set compute default float nnchat:l1_c2_38
data modify storage nnchat:s c[39] set compute default float nnchat:l1_c2_39
data modify storage nnchat:s c[40] set compute default float nnchat:l1_c2_40
data modify storage nnchat:s c[41] set compute default float nnchat:l1_c2_41
data modify storage nnchat:s c[42] set compute default float nnchat:l1_c2_42
data modify storage nnchat:s c[43] set compute default float nnchat:l1_c2_43
data modify storage nnchat:s c[44] set compute default float nnchat:l1_c2_44
data modify storage nnchat:s c[45] set compute default float nnchat:l1_c2_45
data modify storage nnchat:s c[46] set compute default float nnchat:l1_c2_46
data modify storage nnchat:s c[47] set compute default float nnchat:l1_c2_47
data modify storage nnchat:s c[48] set compute default float nnchat:l1_c2_48
data modify storage nnchat:s c[49] set compute default float nnchat:l1_c2_49
data modify storage nnchat:s c[50] set compute default float nnchat:l1_c2_50
data modify storage nnchat:s c[51] set compute default float nnchat:l1_c2_51
data modify storage nnchat:s c[52] set compute default float nnchat:l1_c2_52
data modify storage nnchat:s c[53] set compute default float nnchat:l1_c2_53
data modify storage nnchat:s c[54] set compute default float nnchat:l1_c2_54
data modify storage nnchat:s c[55] set compute default float nnchat:l1_c2_55
data modify storage nnchat:s c[56] set compute default float nnchat:l1_c2_56
data modify storage nnchat:s c[57] set compute default float nnchat:l1_c2_57
data modify storage nnchat:s c[58] set compute default float nnchat:l1_c2_58
data modify storage nnchat:s c[59] set compute default float nnchat:l1_c2_59
data modify storage nnchat:s c[60] set compute default float nnchat:l1_c2_60
data modify storage nnchat:s c[61] set compute default float nnchat:l1_c2_61
data modify storage nnchat:s c[62] set compute default float nnchat:l1_c2_62
data modify storage nnchat:s c[63] set compute default float nnchat:l1_c2_63
data modify storage nnchat:s var set compute default float nnchat:l1_var2
data modify storage nnchat:s inv set compute default float nnchat:l1_inv2
data modify storage nnchat:s n[0] set compute default float nnchat:l1_n2_0
data modify storage nnchat:s n[1] set compute default float nnchat:l1_n2_1
data modify storage nnchat:s n[2] set compute default float nnchat:l1_n2_2
data modify storage nnchat:s n[3] set compute default float nnchat:l1_n2_3
data modify storage nnchat:s n[4] set compute default float nnchat:l1_n2_4
data modify storage nnchat:s n[5] set compute default float nnchat:l1_n2_5
data modify storage nnchat:s n[6] set compute default float nnchat:l1_n2_6
data modify storage nnchat:s n[7] set compute default float nnchat:l1_n2_7
data modify storage nnchat:s n[8] set compute default float nnchat:l1_n2_8
data modify storage nnchat:s n[9] set compute default float nnchat:l1_n2_9
data modify storage nnchat:s n[10] set compute default float nnchat:l1_n2_10
data modify storage nnchat:s n[11] set compute default float nnchat:l1_n2_11
data modify storage nnchat:s n[12] set compute default float nnchat:l1_n2_12
data modify storage nnchat:s n[13] set compute default float nnchat:l1_n2_13
data modify storage nnchat:s n[14] set compute default float nnchat:l1_n2_14
data modify storage nnchat:s n[15] set compute default float nnchat:l1_n2_15
data modify storage nnchat:s n[16] set compute default float nnchat:l1_n2_16
data modify storage nnchat:s n[17] set compute default float nnchat:l1_n2_17
data modify storage nnchat:s n[18] set compute default float nnchat:l1_n2_18
data modify storage nnchat:s n[19] set compute default float nnchat:l1_n2_19
data modify storage nnchat:s n[20] set compute default float nnchat:l1_n2_20
data modify storage nnchat:s n[21] set compute default float nnchat:l1_n2_21
data modify storage nnchat:s n[22] set compute default float nnchat:l1_n2_22
data modify storage nnchat:s n[23] set compute default float nnchat:l1_n2_23
data modify storage nnchat:s n[24] set compute default float nnchat:l1_n2_24
data modify storage nnchat:s n[25] set compute default float nnchat:l1_n2_25
data modify storage nnchat:s n[26] set compute default float nnchat:l1_n2_26
data modify storage nnchat:s n[27] set compute default float nnchat:l1_n2_27
data modify storage nnchat:s n[28] set compute default float nnchat:l1_n2_28
data modify storage nnchat:s n[29] set compute default float nnchat:l1_n2_29
data modify storage nnchat:s n[30] set compute default float nnchat:l1_n2_30
data modify storage nnchat:s n[31] set compute default float nnchat:l1_n2_31
data modify storage nnchat:s n[32] set compute default float nnchat:l1_n2_32
data modify storage nnchat:s n[33] set compute default float nnchat:l1_n2_33
data modify storage nnchat:s n[34] set compute default float nnchat:l1_n2_34
data modify storage nnchat:s n[35] set compute default float nnchat:l1_n2_35
data modify storage nnchat:s n[36] set compute default float nnchat:l1_n2_36
data modify storage nnchat:s n[37] set compute default float nnchat:l1_n2_37
data modify storage nnchat:s n[38] set compute default float nnchat:l1_n2_38
data modify storage nnchat:s n[39] set compute default float nnchat:l1_n2_39
data modify storage nnchat:s n[40] set compute default float nnchat:l1_n2_40
data modify storage nnchat:s n[41] set compute default float nnchat:l1_n2_41
data modify storage nnchat:s n[42] set compute default float nnchat:l1_n2_42
data modify storage nnchat:s n[43] set compute default float nnchat:l1_n2_43
data modify storage nnchat:s n[44] set compute default float nnchat:l1_n2_44
data modify storage nnchat:s n[45] set compute default float nnchat:l1_n2_45
data modify storage nnchat:s n[46] set compute default float nnchat:l1_n2_46
data modify storage nnchat:s n[47] set compute default float nnchat:l1_n2_47
data modify storage nnchat:s n[48] set compute default float nnchat:l1_n2_48
data modify storage nnchat:s n[49] set compute default float nnchat:l1_n2_49
data modify storage nnchat:s n[50] set compute default float nnchat:l1_n2_50
data modify storage nnchat:s n[51] set compute default float nnchat:l1_n2_51
data modify storage nnchat:s n[52] set compute default float nnchat:l1_n2_52
data modify storage nnchat:s n[53] set compute default float nnchat:l1_n2_53
data modify storage nnchat:s n[54] set compute default float nnchat:l1_n2_54
data modify storage nnchat:s n[55] set compute default float nnchat:l1_n2_55
data modify storage nnchat:s n[56] set compute default float nnchat:l1_n2_56
data modify storage nnchat:s n[57] set compute default float nnchat:l1_n2_57
data modify storage nnchat:s n[58] set compute default float nnchat:l1_n2_58
data modify storage nnchat:s n[59] set compute default float nnchat:l1_n2_59
data modify storage nnchat:s n[60] set compute default float nnchat:l1_n2_60
data modify storage nnchat:s n[61] set compute default float nnchat:l1_n2_61
data modify storage nnchat:s n[62] set compute default float nnchat:l1_n2_62
data modify storage nnchat:s n[63] set compute default float nnchat:l1_n2_63
data modify storage nnchat:s f[0] set compute default float nnchat:l1_f_0
data modify storage nnchat:s f[1] set compute default float nnchat:l1_f_1
data modify storage nnchat:s f[2] set compute default float nnchat:l1_f_2
data modify storage nnchat:s f[3] set compute default float nnchat:l1_f_3
data modify storage nnchat:s f[4] set compute default float nnchat:l1_f_4
data modify storage nnchat:s f[5] set compute default float nnchat:l1_f_5
data modify storage nnchat:s f[6] set compute default float nnchat:l1_f_6
data modify storage nnchat:s f[7] set compute default float nnchat:l1_f_7
data modify storage nnchat:s f[8] set compute default float nnchat:l1_f_8
data modify storage nnchat:s f[9] set compute default float nnchat:l1_f_9
data modify storage nnchat:s f[10] set compute default float nnchat:l1_f_10
data modify storage nnchat:s f[11] set compute default float nnchat:l1_f_11
data modify storage nnchat:s f[12] set compute default float nnchat:l1_f_12
data modify storage nnchat:s f[13] set compute default float nnchat:l1_f_13
data modify storage nnchat:s f[14] set compute default float nnchat:l1_f_14
data modify storage nnchat:s f[15] set compute default float nnchat:l1_f_15
data modify storage nnchat:s f[16] set compute default float nnchat:l1_f_16
data modify storage nnchat:s f[17] set compute default float nnchat:l1_f_17
data modify storage nnchat:s f[18] set compute default float nnchat:l1_f_18
data modify storage nnchat:s f[19] set compute default float nnchat:l1_f_19
data modify storage nnchat:s f[20] set compute default float nnchat:l1_f_20
data modify storage nnchat:s f[21] set compute default float nnchat:l1_f_21
data modify storage nnchat:s f[22] set compute default float nnchat:l1_f_22
data modify storage nnchat:s f[23] set compute default float nnchat:l1_f_23
data modify storage nnchat:s f[24] set compute default float nnchat:l1_f_24
data modify storage nnchat:s f[25] set compute default float nnchat:l1_f_25
data modify storage nnchat:s f[26] set compute default float nnchat:l1_f_26
data modify storage nnchat:s f[27] set compute default float nnchat:l1_f_27
data modify storage nnchat:s f[28] set compute default float nnchat:l1_f_28
data modify storage nnchat:s f[29] set compute default float nnchat:l1_f_29
data modify storage nnchat:s f[30] set compute default float nnchat:l1_f_30
data modify storage nnchat:s f[31] set compute default float nnchat:l1_f_31
data modify storage nnchat:s f[32] set compute default float nnchat:l1_f_32
data modify storage nnchat:s f[33] set compute default float nnchat:l1_f_33
data modify storage nnchat:s f[34] set compute default float nnchat:l1_f_34
data modify storage nnchat:s f[35] set compute default float nnchat:l1_f_35
data modify storage nnchat:s f[36] set compute default float nnchat:l1_f_36
data modify storage nnchat:s f[37] set compute default float nnchat:l1_f_37
data modify storage nnchat:s f[38] set compute default float nnchat:l1_f_38
data modify storage nnchat:s f[39] set compute default float nnchat:l1_f_39
data modify storage nnchat:s f[40] set compute default float nnchat:l1_f_40
data modify storage nnchat:s f[41] set compute default float nnchat:l1_f_41
data modify storage nnchat:s f[42] set compute default float nnchat:l1_f_42
data modify storage nnchat:s f[43] set compute default float nnchat:l1_f_43
data modify storage nnchat:s f[44] set compute default float nnchat:l1_f_44
data modify storage nnchat:s f[45] set compute default float nnchat:l1_f_45
data modify storage nnchat:s f[46] set compute default float nnchat:l1_f_46
data modify storage nnchat:s f[47] set compute default float nnchat:l1_f_47
data modify storage nnchat:s f[48] set compute default float nnchat:l1_f_48
data modify storage nnchat:s f[49] set compute default float nnchat:l1_f_49
data modify storage nnchat:s f[50] set compute default float nnchat:l1_f_50
data modify storage nnchat:s f[51] set compute default float nnchat:l1_f_51
data modify storage nnchat:s f[52] set compute default float nnchat:l1_f_52
data modify storage nnchat:s f[53] set compute default float nnchat:l1_f_53
data modify storage nnchat:s f[54] set compute default float nnchat:l1_f_54
data modify storage nnchat:s f[55] set compute default float nnchat:l1_f_55
data modify storage nnchat:s f[56] set compute default float nnchat:l1_f_56
data modify storage nnchat:s f[57] set compute default float nnchat:l1_f_57
data modify storage nnchat:s f[58] set compute default float nnchat:l1_f_58
data modify storage nnchat:s f[59] set compute default float nnchat:l1_f_59
data modify storage nnchat:s f[60] set compute default float nnchat:l1_f_60
data modify storage nnchat:s f[61] set compute default float nnchat:l1_f_61
data modify storage nnchat:s f[62] set compute default float nnchat:l1_f_62
data modify storage nnchat:s f[63] set compute default float nnchat:l1_f_63
data modify storage nnchat:s f[64] set compute default float nnchat:l1_f_64
data modify storage nnchat:s f[65] set compute default float nnchat:l1_f_65
data modify storage nnchat:s f[66] set compute default float nnchat:l1_f_66
data modify storage nnchat:s f[67] set compute default float nnchat:l1_f_67
data modify storage nnchat:s f[68] set compute default float nnchat:l1_f_68
data modify storage nnchat:s f[69] set compute default float nnchat:l1_f_69
data modify storage nnchat:s f[70] set compute default float nnchat:l1_f_70
data modify storage nnchat:s f[71] set compute default float nnchat:l1_f_71
data modify storage nnchat:s f[72] set compute default float nnchat:l1_f_72
data modify storage nnchat:s f[73] set compute default float nnchat:l1_f_73
data modify storage nnchat:s f[74] set compute default float nnchat:l1_f_74
data modify storage nnchat:s f[75] set compute default float nnchat:l1_f_75
data modify storage nnchat:s f[76] set compute default float nnchat:l1_f_76
data modify storage nnchat:s f[77] set compute default float nnchat:l1_f_77
data modify storage nnchat:s f[78] set compute default float nnchat:l1_f_78
data modify storage nnchat:s f[79] set compute default float nnchat:l1_f_79
data modify storage nnchat:s f[80] set compute default float nnchat:l1_f_80
data modify storage nnchat:s f[81] set compute default float nnchat:l1_f_81
data modify storage nnchat:s f[82] set compute default float nnchat:l1_f_82
data modify storage nnchat:s f[83] set compute default float nnchat:l1_f_83
data modify storage nnchat:s f[84] set compute default float nnchat:l1_f_84
data modify storage nnchat:s f[85] set compute default float nnchat:l1_f_85
data modify storage nnchat:s f[86] set compute default float nnchat:l1_f_86
data modify storage nnchat:s f[87] set compute default float nnchat:l1_f_87
data modify storage nnchat:s f[88] set compute default float nnchat:l1_f_88
data modify storage nnchat:s f[89] set compute default float nnchat:l1_f_89
data modify storage nnchat:s f[90] set compute default float nnchat:l1_f_90
data modify storage nnchat:s f[91] set compute default float nnchat:l1_f_91
data modify storage nnchat:s f[92] set compute default float nnchat:l1_f_92
data modify storage nnchat:s f[93] set compute default float nnchat:l1_f_93
data modify storage nnchat:s f[94] set compute default float nnchat:l1_f_94
data modify storage nnchat:s f[95] set compute default float nnchat:l1_f_95
data modify storage nnchat:s f[96] set compute default float nnchat:l1_f_96
data modify storage nnchat:s f[97] set compute default float nnchat:l1_f_97
data modify storage nnchat:s f[98] set compute default float nnchat:l1_f_98
data modify storage nnchat:s f[99] set compute default float nnchat:l1_f_99
data modify storage nnchat:s f[100] set compute default float nnchat:l1_f_100
data modify storage nnchat:s f[101] set compute default float nnchat:l1_f_101
data modify storage nnchat:s f[102] set compute default float nnchat:l1_f_102
data modify storage nnchat:s f[103] set compute default float nnchat:l1_f_103
data modify storage nnchat:s f[104] set compute default float nnchat:l1_f_104
data modify storage nnchat:s f[105] set compute default float nnchat:l1_f_105
data modify storage nnchat:s f[106] set compute default float nnchat:l1_f_106
data modify storage nnchat:s f[107] set compute default float nnchat:l1_f_107
data modify storage nnchat:s f[108] set compute default float nnchat:l1_f_108
data modify storage nnchat:s f[109] set compute default float nnchat:l1_f_109
data modify storage nnchat:s f[110] set compute default float nnchat:l1_f_110
data modify storage nnchat:s f[111] set compute default float nnchat:l1_f_111
data modify storage nnchat:s f[112] set compute default float nnchat:l1_f_112
data modify storage nnchat:s f[113] set compute default float nnchat:l1_f_113
data modify storage nnchat:s f[114] set compute default float nnchat:l1_f_114
data modify storage nnchat:s f[115] set compute default float nnchat:l1_f_115
data modify storage nnchat:s f[116] set compute default float nnchat:l1_f_116
data modify storage nnchat:s f[117] set compute default float nnchat:l1_f_117
data modify storage nnchat:s f[118] set compute default float nnchat:l1_f_118
data modify storage nnchat:s f[119] set compute default float nnchat:l1_f_119
data modify storage nnchat:s f[120] set compute default float nnchat:l1_f_120
data modify storage nnchat:s f[121] set compute default float nnchat:l1_f_121
data modify storage nnchat:s f[122] set compute default float nnchat:l1_f_122
data modify storage nnchat:s f[123] set compute default float nnchat:l1_f_123
data modify storage nnchat:s f[124] set compute default float nnchat:l1_f_124
data modify storage nnchat:s f[125] set compute default float nnchat:l1_f_125
data modify storage nnchat:s f[126] set compute default float nnchat:l1_f_126
data modify storage nnchat:s f[127] set compute default float nnchat:l1_f_127
data modify storage nnchat:s x[0] set compute default float nnchat:l1_g_0
data modify storage nnchat:s x[1] set compute default float nnchat:l1_g_1
data modify storage nnchat:s x[2] set compute default float nnchat:l1_g_2
data modify storage nnchat:s x[3] set compute default float nnchat:l1_g_3
data modify storage nnchat:s x[4] set compute default float nnchat:l1_g_4
data modify storage nnchat:s x[5] set compute default float nnchat:l1_g_5
data modify storage nnchat:s x[6] set compute default float nnchat:l1_g_6
data modify storage nnchat:s x[7] set compute default float nnchat:l1_g_7
data modify storage nnchat:s x[8] set compute default float nnchat:l1_g_8
data modify storage nnchat:s x[9] set compute default float nnchat:l1_g_9
data modify storage nnchat:s x[10] set compute default float nnchat:l1_g_10
data modify storage nnchat:s x[11] set compute default float nnchat:l1_g_11
data modify storage nnchat:s x[12] set compute default float nnchat:l1_g_12
data modify storage nnchat:s x[13] set compute default float nnchat:l1_g_13
data modify storage nnchat:s x[14] set compute default float nnchat:l1_g_14
data modify storage nnchat:s x[15] set compute default float nnchat:l1_g_15
data modify storage nnchat:s x[16] set compute default float nnchat:l1_g_16
data modify storage nnchat:s x[17] set compute default float nnchat:l1_g_17
data modify storage nnchat:s x[18] set compute default float nnchat:l1_g_18
data modify storage nnchat:s x[19] set compute default float nnchat:l1_g_19
data modify storage nnchat:s x[20] set compute default float nnchat:l1_g_20
data modify storage nnchat:s x[21] set compute default float nnchat:l1_g_21
data modify storage nnchat:s x[22] set compute default float nnchat:l1_g_22
data modify storage nnchat:s x[23] set compute default float nnchat:l1_g_23
data modify storage nnchat:s x[24] set compute default float nnchat:l1_g_24
data modify storage nnchat:s x[25] set compute default float nnchat:l1_g_25
data modify storage nnchat:s x[26] set compute default float nnchat:l1_g_26
data modify storage nnchat:s x[27] set compute default float nnchat:l1_g_27
data modify storage nnchat:s x[28] set compute default float nnchat:l1_g_28
data modify storage nnchat:s x[29] set compute default float nnchat:l1_g_29
data modify storage nnchat:s x[30] set compute default float nnchat:l1_g_30
data modify storage nnchat:s x[31] set compute default float nnchat:l1_g_31
data modify storage nnchat:s x[32] set compute default float nnchat:l1_g_32
data modify storage nnchat:s x[33] set compute default float nnchat:l1_g_33
data modify storage nnchat:s x[34] set compute default float nnchat:l1_g_34
data modify storage nnchat:s x[35] set compute default float nnchat:l1_g_35
data modify storage nnchat:s x[36] set compute default float nnchat:l1_g_36
data modify storage nnchat:s x[37] set compute default float nnchat:l1_g_37
data modify storage nnchat:s x[38] set compute default float nnchat:l1_g_38
data modify storage nnchat:s x[39] set compute default float nnchat:l1_g_39
data modify storage nnchat:s x[40] set compute default float nnchat:l1_g_40
data modify storage nnchat:s x[41] set compute default float nnchat:l1_g_41
data modify storage nnchat:s x[42] set compute default float nnchat:l1_g_42
data modify storage nnchat:s x[43] set compute default float nnchat:l1_g_43
data modify storage nnchat:s x[44] set compute default float nnchat:l1_g_44
data modify storage nnchat:s x[45] set compute default float nnchat:l1_g_45
data modify storage nnchat:s x[46] set compute default float nnchat:l1_g_46
data modify storage nnchat:s x[47] set compute default float nnchat:l1_g_47
data modify storage nnchat:s x[48] set compute default float nnchat:l1_g_48
data modify storage nnchat:s x[49] set compute default float nnchat:l1_g_49
data modify storage nnchat:s x[50] set compute default float nnchat:l1_g_50
data modify storage nnchat:s x[51] set compute default float nnchat:l1_g_51
data modify storage nnchat:s x[52] set compute default float nnchat:l1_g_52
data modify storage nnchat:s x[53] set compute default float nnchat:l1_g_53
data modify storage nnchat:s x[54] set compute default float nnchat:l1_g_54
data modify storage nnchat:s x[55] set compute default float nnchat:l1_g_55
data modify storage nnchat:s x[56] set compute default float nnchat:l1_g_56
data modify storage nnchat:s x[57] set compute default float nnchat:l1_g_57
data modify storage nnchat:s x[58] set compute default float nnchat:l1_g_58
data modify storage nnchat:s x[59] set compute default float nnchat:l1_g_59
data modify storage nnchat:s x[60] set compute default float nnchat:l1_g_60
data modify storage nnchat:s x[61] set compute default float nnchat:l1_g_61
data modify storage nnchat:s x[62] set compute default float nnchat:l1_g_62
data modify storage nnchat:s x[63] set compute default float nnchat:l1_g_63
# --- 最终 LN + 绑定输出头 ---
data modify storage nnchat:s m set compute default float nnchat:f_m
data modify storage nnchat:s c[0] set compute default float nnchat:f_c_0
data modify storage nnchat:s c[1] set compute default float nnchat:f_c_1
data modify storage nnchat:s c[2] set compute default float nnchat:f_c_2
data modify storage nnchat:s c[3] set compute default float nnchat:f_c_3
data modify storage nnchat:s c[4] set compute default float nnchat:f_c_4
data modify storage nnchat:s c[5] set compute default float nnchat:f_c_5
data modify storage nnchat:s c[6] set compute default float nnchat:f_c_6
data modify storage nnchat:s c[7] set compute default float nnchat:f_c_7
data modify storage nnchat:s c[8] set compute default float nnchat:f_c_8
data modify storage nnchat:s c[9] set compute default float nnchat:f_c_9
data modify storage nnchat:s c[10] set compute default float nnchat:f_c_10
data modify storage nnchat:s c[11] set compute default float nnchat:f_c_11
data modify storage nnchat:s c[12] set compute default float nnchat:f_c_12
data modify storage nnchat:s c[13] set compute default float nnchat:f_c_13
data modify storage nnchat:s c[14] set compute default float nnchat:f_c_14
data modify storage nnchat:s c[15] set compute default float nnchat:f_c_15
data modify storage nnchat:s c[16] set compute default float nnchat:f_c_16
data modify storage nnchat:s c[17] set compute default float nnchat:f_c_17
data modify storage nnchat:s c[18] set compute default float nnchat:f_c_18
data modify storage nnchat:s c[19] set compute default float nnchat:f_c_19
data modify storage nnchat:s c[20] set compute default float nnchat:f_c_20
data modify storage nnchat:s c[21] set compute default float nnchat:f_c_21
data modify storage nnchat:s c[22] set compute default float nnchat:f_c_22
data modify storage nnchat:s c[23] set compute default float nnchat:f_c_23
data modify storage nnchat:s c[24] set compute default float nnchat:f_c_24
data modify storage nnchat:s c[25] set compute default float nnchat:f_c_25
data modify storage nnchat:s c[26] set compute default float nnchat:f_c_26
data modify storage nnchat:s c[27] set compute default float nnchat:f_c_27
data modify storage nnchat:s c[28] set compute default float nnchat:f_c_28
data modify storage nnchat:s c[29] set compute default float nnchat:f_c_29
data modify storage nnchat:s c[30] set compute default float nnchat:f_c_30
data modify storage nnchat:s c[31] set compute default float nnchat:f_c_31
data modify storage nnchat:s c[32] set compute default float nnchat:f_c_32
data modify storage nnchat:s c[33] set compute default float nnchat:f_c_33
data modify storage nnchat:s c[34] set compute default float nnchat:f_c_34
data modify storage nnchat:s c[35] set compute default float nnchat:f_c_35
data modify storage nnchat:s c[36] set compute default float nnchat:f_c_36
data modify storage nnchat:s c[37] set compute default float nnchat:f_c_37
data modify storage nnchat:s c[38] set compute default float nnchat:f_c_38
data modify storage nnchat:s c[39] set compute default float nnchat:f_c_39
data modify storage nnchat:s c[40] set compute default float nnchat:f_c_40
data modify storage nnchat:s c[41] set compute default float nnchat:f_c_41
data modify storage nnchat:s c[42] set compute default float nnchat:f_c_42
data modify storage nnchat:s c[43] set compute default float nnchat:f_c_43
data modify storage nnchat:s c[44] set compute default float nnchat:f_c_44
data modify storage nnchat:s c[45] set compute default float nnchat:f_c_45
data modify storage nnchat:s c[46] set compute default float nnchat:f_c_46
data modify storage nnchat:s c[47] set compute default float nnchat:f_c_47
data modify storage nnchat:s c[48] set compute default float nnchat:f_c_48
data modify storage nnchat:s c[49] set compute default float nnchat:f_c_49
data modify storage nnchat:s c[50] set compute default float nnchat:f_c_50
data modify storage nnchat:s c[51] set compute default float nnchat:f_c_51
data modify storage nnchat:s c[52] set compute default float nnchat:f_c_52
data modify storage nnchat:s c[53] set compute default float nnchat:f_c_53
data modify storage nnchat:s c[54] set compute default float nnchat:f_c_54
data modify storage nnchat:s c[55] set compute default float nnchat:f_c_55
data modify storage nnchat:s c[56] set compute default float nnchat:f_c_56
data modify storage nnchat:s c[57] set compute default float nnchat:f_c_57
data modify storage nnchat:s c[58] set compute default float nnchat:f_c_58
data modify storage nnchat:s c[59] set compute default float nnchat:f_c_59
data modify storage nnchat:s c[60] set compute default float nnchat:f_c_60
data modify storage nnchat:s c[61] set compute default float nnchat:f_c_61
data modify storage nnchat:s c[62] set compute default float nnchat:f_c_62
data modify storage nnchat:s c[63] set compute default float nnchat:f_c_63
data modify storage nnchat:s var set compute default float nnchat:f_var
data modify storage nnchat:s inv set compute default float nnchat:f_inv
data modify storage nnchat:s n[0] set compute default float nnchat:f_n_0
data modify storage nnchat:s n[1] set compute default float nnchat:f_n_1
data modify storage nnchat:s n[2] set compute default float nnchat:f_n_2
data modify storage nnchat:s n[3] set compute default float nnchat:f_n_3
data modify storage nnchat:s n[4] set compute default float nnchat:f_n_4
data modify storage nnchat:s n[5] set compute default float nnchat:f_n_5
data modify storage nnchat:s n[6] set compute default float nnchat:f_n_6
data modify storage nnchat:s n[7] set compute default float nnchat:f_n_7
data modify storage nnchat:s n[8] set compute default float nnchat:f_n_8
data modify storage nnchat:s n[9] set compute default float nnchat:f_n_9
data modify storage nnchat:s n[10] set compute default float nnchat:f_n_10
data modify storage nnchat:s n[11] set compute default float nnchat:f_n_11
data modify storage nnchat:s n[12] set compute default float nnchat:f_n_12
data modify storage nnchat:s n[13] set compute default float nnchat:f_n_13
data modify storage nnchat:s n[14] set compute default float nnchat:f_n_14
data modify storage nnchat:s n[15] set compute default float nnchat:f_n_15
data modify storage nnchat:s n[16] set compute default float nnchat:f_n_16
data modify storage nnchat:s n[17] set compute default float nnchat:f_n_17
data modify storage nnchat:s n[18] set compute default float nnchat:f_n_18
data modify storage nnchat:s n[19] set compute default float nnchat:f_n_19
data modify storage nnchat:s n[20] set compute default float nnchat:f_n_20
data modify storage nnchat:s n[21] set compute default float nnchat:f_n_21
data modify storage nnchat:s n[22] set compute default float nnchat:f_n_22
data modify storage nnchat:s n[23] set compute default float nnchat:f_n_23
data modify storage nnchat:s n[24] set compute default float nnchat:f_n_24
data modify storage nnchat:s n[25] set compute default float nnchat:f_n_25
data modify storage nnchat:s n[26] set compute default float nnchat:f_n_26
data modify storage nnchat:s n[27] set compute default float nnchat:f_n_27
data modify storage nnchat:s n[28] set compute default float nnchat:f_n_28
data modify storage nnchat:s n[29] set compute default float nnchat:f_n_29
data modify storage nnchat:s n[30] set compute default float nnchat:f_n_30
data modify storage nnchat:s n[31] set compute default float nnchat:f_n_31
data modify storage nnchat:s n[32] set compute default float nnchat:f_n_32
data modify storage nnchat:s n[33] set compute default float nnchat:f_n_33
data modify storage nnchat:s n[34] set compute default float nnchat:f_n_34
data modify storage nnchat:s n[35] set compute default float nnchat:f_n_35
data modify storage nnchat:s n[36] set compute default float nnchat:f_n_36
data modify storage nnchat:s n[37] set compute default float nnchat:f_n_37
data modify storage nnchat:s n[38] set compute default float nnchat:f_n_38
data modify storage nnchat:s n[39] set compute default float nnchat:f_n_39
data modify storage nnchat:s n[40] set compute default float nnchat:f_n_40
data modify storage nnchat:s n[41] set compute default float nnchat:f_n_41
data modify storage nnchat:s n[42] set compute default float nnchat:f_n_42
data modify storage nnchat:s n[43] set compute default float nnchat:f_n_43
data modify storage nnchat:s n[44] set compute default float nnchat:f_n_44
data modify storage nnchat:s n[45] set compute default float nnchat:f_n_45
data modify storage nnchat:s n[46] set compute default float nnchat:f_n_46
data modify storage nnchat:s n[47] set compute default float nnchat:f_n_47
data modify storage nnchat:s n[48] set compute default float nnchat:f_n_48
data modify storage nnchat:s n[49] set compute default float nnchat:f_n_49
data modify storage nnchat:s n[50] set compute default float nnchat:f_n_50
data modify storage nnchat:s n[51] set compute default float nnchat:f_n_51
data modify storage nnchat:s n[52] set compute default float nnchat:f_n_52
data modify storage nnchat:s n[53] set compute default float nnchat:f_n_53
data modify storage nnchat:s n[54] set compute default float nnchat:f_n_54
data modify storage nnchat:s n[55] set compute default float nnchat:f_n_55
data modify storage nnchat:s n[56] set compute default float nnchat:f_n_56
data modify storage nnchat:s n[57] set compute default float nnchat:f_n_57
data modify storage nnchat:s n[58] set compute default float nnchat:f_n_58
data modify storage nnchat:s n[59] set compute default float nnchat:f_n_59
data modify storage nnchat:s n[60] set compute default float nnchat:f_n_60
data modify storage nnchat:s n[61] set compute default float nnchat:f_n_61
data modify storage nnchat:s n[62] set compute default float nnchat:f_n_62
data modify storage nnchat:s n[63] set compute default float nnchat:f_n_63
scoreboard players set #best nn -2147483648
scoreboard players set #btok nn 0
execute store result score #v nn run compute default float nnchat:logit_0 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:0}
execute store result score #v nn run compute default float nnchat:logit_1 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:1}
execute store result score #v nn run compute default float nnchat:logit_2 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:2}
execute store result score #v nn run compute default float nnchat:logit_3 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:3}
execute store result score #v nn run compute default float nnchat:logit_4 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:4}
execute store result score #v nn run compute default float nnchat:logit_5 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:5}
execute store result score #v nn run compute default float nnchat:logit_6 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:6}
execute store result score #v nn run compute default float nnchat:logit_7 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:7}
execute store result score #v nn run compute default float nnchat:logit_8 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:8}
execute store result score #v nn run compute default float nnchat:logit_9 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:9}
execute store result score #v nn run compute default float nnchat:logit_10 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:10}
execute store result score #v nn run compute default float nnchat:logit_11 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:11}
execute store result score #v nn run compute default float nnchat:logit_12 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:12}
execute store result score #v nn run compute default float nnchat:logit_13 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:13}
execute store result score #v nn run compute default float nnchat:logit_14 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:14}
execute store result score #v nn run compute default float nnchat:logit_15 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:15}
execute store result score #v nn run compute default float nnchat:logit_16 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:16}
execute store result score #v nn run compute default float nnchat:logit_17 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:17}
execute store result score #v nn run compute default float nnchat:logit_18 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:18}
execute store result score #v nn run compute default float nnchat:logit_19 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:19}
execute store result score #v nn run compute default float nnchat:logit_20 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:20}
execute store result score #v nn run compute default float nnchat:logit_21 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:21}
execute store result score #v nn run compute default float nnchat:logit_22 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:22}
execute store result score #v nn run compute default float nnchat:logit_23 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:23}
execute store result score #v nn run compute default float nnchat:logit_24 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:24}
execute store result score #v nn run compute default float nnchat:logit_25 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:25}
execute store result score #v nn run compute default float nnchat:logit_26 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:26}
execute store result score #v nn run compute default float nnchat:logit_27 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:27}
execute store result score #v nn run compute default float nnchat:logit_28 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:28}
execute store result score #v nn run compute default float nnchat:logit_29 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:29}
execute store result score #v nn run compute default float nnchat:logit_30 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:30}
execute store result score #v nn run compute default float nnchat:logit_31 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:31}
execute store result score #v nn run compute default float nnchat:logit_32 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:32}
execute store result score #v nn run compute default float nnchat:logit_33 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:33}
execute store result score #v nn run compute default float nnchat:logit_34 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:34}
execute store result score #v nn run compute default float nnchat:logit_35 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:35}
execute store result score #v nn run compute default float nnchat:logit_36 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:36}
execute store result score #v nn run compute default float nnchat:logit_37 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:37}
execute store result score #v nn run compute default float nnchat:logit_38 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:38}
execute store result score #v nn run compute default float nnchat:logit_39 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:39}
execute store result score #v nn run compute default float nnchat:logit_40 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:40}
execute store result score #v nn run compute default float nnchat:logit_41 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:41}
execute store result score #v nn run compute default float nnchat:logit_42 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:42}
execute store result score #v nn run compute default float nnchat:logit_43 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:43}
execute store result score #v nn run compute default float nnchat:logit_44 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:44}
execute store result score #v nn run compute default float nnchat:logit_45 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:45}
execute store result score #v nn run compute default float nnchat:logit_46 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:46}
execute store result score #v nn run compute default float nnchat:logit_47 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:47}
execute store result score #v nn run compute default float nnchat:logit_48 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:48}
execute store result score #v nn run compute default float nnchat:logit_49 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:49}
execute store result score #v nn run compute default float nnchat:logit_50 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:50}
execute store result score #v nn run compute default float nnchat:logit_51 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:51}
execute store result score #v nn run compute default float nnchat:logit_52 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:52}
execute store result score #v nn run compute default float nnchat:logit_53 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:53}
execute store result score #v nn run compute default float nnchat:logit_54 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:54}
execute store result score #v nn run compute default float nnchat:logit_55 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:55}
execute store result score #v nn run compute default float nnchat:logit_56 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:56}
execute store result score #v nn run compute default float nnchat:logit_57 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:57}
execute store result score #v nn run compute default float nnchat:logit_58 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:58}
execute store result score #v nn run compute default float nnchat:logit_59 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:59}
execute store result score #v nn run compute default float nnchat:logit_60 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:60}
execute store result score #v nn run compute default float nnchat:logit_61 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:61}
execute store result score #v nn run compute default float nnchat:logit_62 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:62}
execute store result score #v nn run compute default float nnchat:logit_63 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:63}
execute store result score #v nn run compute default float nnchat:logit_64 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:64}
execute store result score #v nn run compute default float nnchat:logit_65 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:65}
execute store result score #v nn run compute default float nnchat:logit_66 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:66}
execute store result score #v nn run compute default float nnchat:logit_67 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:67}
execute store result score #v nn run compute default float nnchat:logit_68 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:68}
execute store result score #v nn run compute default float nnchat:logit_69 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:69}
execute store result score #v nn run compute default float nnchat:logit_70 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:70}
execute store result score #v nn run compute default float nnchat:logit_71 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:71}
execute store result score #v nn run compute default float nnchat:logit_72 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:72}
execute store result score #v nn run compute default float nnchat:logit_73 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:73}
execute store result score #v nn run compute default float nnchat:logit_74 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:74}
execute store result score #v nn run compute default float nnchat:logit_75 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:75}
execute store result score #v nn run compute default float nnchat:logit_76 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:76}
execute store result score #v nn run compute default float nnchat:logit_77 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:77}
execute store result score #v nn run compute default float nnchat:logit_78 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:78}
execute store result score #v nn run compute default float nnchat:logit_79 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:79}
execute store result score #v nn run compute default float nnchat:logit_80 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:80}
execute store result score #v nn run compute default float nnchat:logit_81 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:81}
execute store result score #v nn run compute default float nnchat:logit_82 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:82}
execute store result score #v nn run compute default float nnchat:logit_83 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:83}
execute store result score #v nn run compute default float nnchat:logit_84 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:84}
execute store result score #v nn run compute default float nnchat:logit_85 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:85}
execute store result score #v nn run compute default float nnchat:logit_86 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:86}
execute store result score #v nn run compute default float nnchat:logit_87 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:87}
execute store result score #v nn run compute default float nnchat:logit_88 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:88}
execute store result score #v nn run compute default float nnchat:logit_89 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:89}
execute store result score #v nn run compute default float nnchat:logit_90 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:90}
execute store result score #v nn run compute default float nnchat:logit_91 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:91}
execute store result score #v nn run compute default float nnchat:logit_92 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:92}
execute store result score #v nn run compute default float nnchat:logit_93 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:93}
execute store result score #v nn run compute default float nnchat:logit_94 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:94}
execute store result score #v nn run compute default float nnchat:logit_95 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:95}
execute store result score #v nn run compute default float nnchat:logit_96 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:96}
execute store result score #v nn run compute default float nnchat:logit_97 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:97}
execute store result score #v nn run compute default float nnchat:logit_98 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:98}
execute store result score #v nn run compute default float nnchat:logit_99 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:99}
execute store result score #v nn run compute default float nnchat:logit_100 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:100}
execute store result score #v nn run compute default float nnchat:logit_101 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:101}
execute store result score #v nn run compute default float nnchat:logit_102 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:102}
execute store result score #v nn run compute default float nnchat:logit_103 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:103}
execute store result score #v nn run compute default float nnchat:logit_104 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:104}
execute store result score #v nn run compute default float nnchat:logit_105 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:105}
execute store result score #v nn run compute default float nnchat:logit_106 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:106}
execute store result score #v nn run compute default float nnchat:logit_107 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:107}
execute store result score #v nn run compute default float nnchat:logit_108 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:108}
execute store result score #v nn run compute default float nnchat:logit_109 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:109}
execute store result score #v nn run compute default float nnchat:logit_110 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:110}
execute store result score #v nn run compute default float nnchat:logit_111 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:111}
execute store result score #v nn run compute default float nnchat:logit_112 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:112}
execute store result score #v nn run compute default float nnchat:logit_113 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:113}
execute store result score #v nn run compute default float nnchat:logit_114 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:114}
execute store result score #v nn run compute default float nnchat:logit_115 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:115}
execute store result score #v nn run compute default float nnchat:logit_116 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:116}
execute store result score #v nn run compute default float nnchat:logit_117 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:117}
execute store result score #v nn run compute default float nnchat:logit_118 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:118}
execute store result score #v nn run compute default float nnchat:logit_119 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:119}
execute store result score #v nn run compute default float nnchat:logit_120 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:120}
execute store result score #v nn run compute default float nnchat:logit_121 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:121}
execute store result score #v nn run compute default float nnchat:logit_122 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:122}
execute store result score #v nn run compute default float nnchat:logit_123 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:123}
execute store result score #v nn run compute default float nnchat:logit_124 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:124}
execute store result score #v nn run compute default float nnchat:logit_125 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:125}
execute store result score #v nn run compute default float nnchat:logit_126 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:126}
execute store result score #v nn run compute default float nnchat:logit_127 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:127}
execute store result score #v nn run compute default float nnchat:logit_128 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:128}
execute store result score #v nn run compute default float nnchat:logit_129 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:129}
execute store result score #v nn run compute default float nnchat:logit_130 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:130}
execute store result score #v nn run compute default float nnchat:logit_131 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:131}
execute store result score #v nn run compute default float nnchat:logit_132 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:132}
execute store result score #v nn run compute default float nnchat:logit_133 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:133}
execute store result score #v nn run compute default float nnchat:logit_134 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:134}
execute store result score #v nn run compute default float nnchat:logit_135 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:135}
execute store result score #v nn run compute default float nnchat:logit_136 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:136}
execute store result score #v nn run compute default float nnchat:logit_137 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:137}
execute store result score #v nn run compute default float nnchat:logit_138 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:138}
execute store result score #v nn run compute default float nnchat:logit_139 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:139}
execute store result score #v nn run compute default float nnchat:logit_140 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:140}
execute store result score #v nn run compute default float nnchat:logit_141 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:141}
execute store result score #v nn run compute default float nnchat:logit_142 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:142}
execute store result score #v nn run compute default float nnchat:logit_143 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:143}
execute store result score #v nn run compute default float nnchat:logit_144 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:144}
execute store result score #v nn run compute default float nnchat:logit_145 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:145}
execute store result score #v nn run compute default float nnchat:logit_146 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:146}
execute store result score #v nn run compute default float nnchat:logit_147 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:147}
execute store result score #v nn run compute default float nnchat:logit_148 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:148}
execute store result score #v nn run compute default float nnchat:logit_149 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:149}
execute store result score #v nn run compute default float nnchat:logit_150 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:150}
execute store result score #v nn run compute default float nnchat:logit_151 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:151}
execute store result score #v nn run compute default float nnchat:logit_152 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:152}
execute store result score #v nn run compute default float nnchat:logit_153 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:153}
execute store result score #v nn run compute default float nnchat:logit_154 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:154}
execute store result score #v nn run compute default float nnchat:logit_155 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:155}
execute store result score #v nn run compute default float nnchat:logit_156 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:156}
execute store result score #v nn run compute default float nnchat:logit_157 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:157}
execute store result score #v nn run compute default float nnchat:logit_158 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:158}
execute store result score #v nn run compute default float nnchat:logit_159 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:159}
execute store result score #v nn run compute default float nnchat:logit_160 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:160}
execute store result score #v nn run compute default float nnchat:logit_161 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:161}
execute store result score #v nn run compute default float nnchat:logit_162 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:162}
execute store result score #v nn run compute default float nnchat:logit_163 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:163}
execute store result score #v nn run compute default float nnchat:logit_164 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:164}
execute store result score #v nn run compute default float nnchat:logit_165 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:165}
execute store result score #v nn run compute default float nnchat:logit_166 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:166}
execute store result score #v nn run compute default float nnchat:logit_167 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:167}
execute store result score #v nn run compute default float nnchat:logit_168 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:168}
execute store result score #v nn run compute default float nnchat:logit_169 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:169}
execute store result score #v nn run compute default float nnchat:logit_170 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:170}
execute store result score #v nn run compute default float nnchat:logit_171 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:171}
execute store result score #v nn run compute default float nnchat:logit_172 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:172}
execute store result score #v nn run compute default float nnchat:logit_173 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:173}
execute store result score #v nn run compute default float nnchat:logit_174 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:174}
execute store result score #v nn run compute default float nnchat:logit_175 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:175}
execute store result score #v nn run compute default float nnchat:logit_176 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:176}
execute store result score #v nn run compute default float nnchat:logit_177 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:177}
execute store result score #v nn run compute default float nnchat:logit_178 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:178}
execute store result score #v nn run compute default float nnchat:logit_179 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:179}
execute store result score #v nn run compute default float nnchat:logit_180 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:180}
execute store result score #v nn run compute default float nnchat:logit_181 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:181}
execute store result score #v nn run compute default float nnchat:logit_182 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:182}
execute store result score #v nn run compute default float nnchat:logit_183 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:183}
execute store result score #v nn run compute default float nnchat:logit_184 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:184}
execute store result score #v nn run compute default float nnchat:logit_185 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:185}
execute store result score #v nn run compute default float nnchat:logit_186 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:186}
execute store result score #v nn run compute default float nnchat:logit_187 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:187}
execute store result score #v nn run compute default float nnchat:logit_188 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:188}
execute store result score #v nn run compute default float nnchat:logit_189 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:189}
execute store result score #v nn run compute default float nnchat:logit_190 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:190}
execute store result score #v nn run compute default float nnchat:logit_191 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:191}
execute store result score #v nn run compute default float nnchat:logit_192 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:192}
execute store result score #v nn run compute default float nnchat:logit_193 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:193}
execute store result score #v nn run compute default float nnchat:logit_194 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:194}
execute store result score #v nn run compute default float nnchat:logit_195 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:195}
execute store result score #v nn run compute default float nnchat:logit_196 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:196}
execute store result score #v nn run compute default float nnchat:logit_197 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:197}
execute store result score #v nn run compute default float nnchat:logit_198 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:198}
execute store result score #v nn run compute default float nnchat:logit_199 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:199}
execute store result score #v nn run compute default float nnchat:logit_200 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:200}
execute store result score #v nn run compute default float nnchat:logit_201 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:201}
execute store result score #v nn run compute default float nnchat:logit_202 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:202}
execute store result score #v nn run compute default float nnchat:logit_203 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:203}
execute store result score #v nn run compute default float nnchat:logit_204 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:204}
execute store result score #v nn run compute default float nnchat:logit_205 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:205}
execute store result score #v nn run compute default float nnchat:logit_206 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:206}
execute store result score #v nn run compute default float nnchat:logit_207 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:207}
execute store result score #v nn run compute default float nnchat:logit_208 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:208}
execute store result score #v nn run compute default float nnchat:logit_209 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:209}
execute store result score #v nn run compute default float nnchat:logit_210 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:210}
execute store result score #v nn run compute default float nnchat:logit_211 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:211}
execute store result score #v nn run compute default float nnchat:logit_212 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:212}
execute store result score #v nn run compute default float nnchat:logit_213 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:213}
execute store result score #v nn run compute default float nnchat:logit_214 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:214}
execute store result score #v nn run compute default float nnchat:logit_215 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:215}
execute store result score #v nn run compute default float nnchat:logit_216 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:216}
execute store result score #v nn run compute default float nnchat:logit_217 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:217}
execute store result score #v nn run compute default float nnchat:logit_218 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:218}
execute store result score #v nn run compute default float nnchat:logit_219 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:219}
execute store result score #v nn run compute default float nnchat:logit_220 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:220}
execute store result score #v nn run compute default float nnchat:logit_221 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:221}
execute store result score #v nn run compute default float nnchat:logit_222 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:222}
execute store result score #v nn run compute default float nnchat:logit_223 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:223}
execute store result score #v nn run compute default float nnchat:logit_224 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:224}
execute store result score #v nn run compute default float nnchat:logit_225 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:225}
execute store result score #v nn run compute default float nnchat:logit_226 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:226}
execute store result score #v nn run compute default float nnchat:logit_227 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:227}
execute store result score #v nn run compute default float nnchat:logit_228 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:228}
execute store result score #v nn run compute default float nnchat:logit_229 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:229}
execute store result score #v nn run compute default float nnchat:logit_230 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:230}
execute store result score #v nn run compute default float nnchat:logit_231 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:231}
execute store result score #v nn run compute default float nnchat:logit_232 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:232}
execute store result score #v nn run compute default float nnchat:logit_233 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:233}
execute store result score #v nn run compute default float nnchat:logit_234 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:234}
execute store result score #v nn run compute default float nnchat:logit_235 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:235}
execute store result score #v nn run compute default float nnchat:logit_236 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:236}
execute store result score #v nn run compute default float nnchat:logit_237 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:237}
execute store result score #v nn run compute default float nnchat:logit_238 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:238}
execute store result score #v nn run compute default float nnchat:logit_239 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:239}
execute store result score #v nn run compute default float nnchat:logit_240 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:240}
execute store result score #v nn run compute default float nnchat:logit_241 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:241}
execute store result score #v nn run compute default float nnchat:logit_242 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:242}
execute store result score #v nn run compute default float nnchat:logit_243 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:243}
execute store result score #v nn run compute default float nnchat:logit_244 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:244}
execute store result score #v nn run compute default float nnchat:logit_245 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:245}
execute store result score #v nn run compute default float nnchat:logit_246 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:246}
execute store result score #v nn run compute default float nnchat:logit_247 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:247}
execute store result score #v nn run compute default float nnchat:logit_248 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:248}
execute store result score #v nn run compute default float nnchat:logit_249 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:249}
execute store result score #v nn run compute default float nnchat:logit_250 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:250}
execute store result score #v nn run compute default float nnchat:logit_251 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:251}
execute store result score #v nn run compute default float nnchat:logit_252 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:252}
execute store result score #v nn run compute default float nnchat:logit_253 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:253}
execute store result score #v nn run compute default float nnchat:logit_254 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:254}
execute store result score #v nn run compute default float nnchat:logit_255 10000
execute if score #v nn > #best nn run function nnchat:amax {tok:255}
