$data modify storage nnchat:s px set from storage nnchat:w P[$(i)]
