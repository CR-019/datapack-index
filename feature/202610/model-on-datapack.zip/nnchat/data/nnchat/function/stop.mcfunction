# 紧急停止生成循环
schedule clear nnchat:feed
schedule clear nnchat:gen
scoreboard players set 状态 nnh 0
tellraw @a {"text":"[nnchat] 已停止所有推理任务","color":"red"}
