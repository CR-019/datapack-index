execute store result score #btok nn run data get storage nnchat:s tokens[0]
data remove storage nnchat:s tokens[0]
function nnchat:forward
scoreboard players add #t nn 1
scoreboard players operation 位置 nnh = #t nn
execute if score #t nn < #len nn run schedule function nnchat:feed 1t
execute unless score #t nn < #len nn run schedule function nnchat:gen 1t
