$data modify storage nnchat:s ex set from storage nnchat:w E[$(i)]
