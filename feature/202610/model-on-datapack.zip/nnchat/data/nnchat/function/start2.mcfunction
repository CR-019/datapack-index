data modify storage nnchat:s out set value []
data modify storage nnchat:s kc0 set value []
data modify storage nnchat:s kc1 set value []
data modify storage nnchat:s vc0 set value []
data modify storage nnchat:s vc1 set value []
scoreboard players set #t nn 0
scoreboard players set 状态 nnh 1
scoreboard players operation 总长 nnh = #len nn
scoreboard players set 位置 nnh 0
scoreboard players set 生成 nnh 0
tellraw @a [{"text":"[nnchat] 开始推理, 提示长度 ","color":"green"},{"score":{"name":"#len","objective":"nn"},"color":"yellow"}]
schedule function nnchat:feed 1t
