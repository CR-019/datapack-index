# 用法: function nnchat:ask {text:"问:你好|答:"}   (| 代表换行)
scoreboard objectives add nn dummy
$data modify storage nnchat:s in set value "$(text)"
data modify storage nnchat:s tokens set value []
scoreboard players set #pos nn 0
function nnchat:enc_loop
