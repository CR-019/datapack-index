$scoreboard players set #btok nn $(tok)
scoreboard players operation #best nn = #v nn
