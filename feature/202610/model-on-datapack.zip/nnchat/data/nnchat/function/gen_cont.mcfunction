execute store result storage nnchat:s tmp int 1 run scoreboard players get #btok nn
data modify storage nnchat:s out append from storage nnchat:s tmp
scoreboard players set 状态 nnh 2
execute store result score 生成 nnh run data get storage nnchat:s out
function nnchat:forward
scoreboard players add #t nn 1
scoreboard players operation 位置 nnh = #t nn
schedule function nnchat:gen 1t
