tellraw @s {"text":"[nnchat] pong! 数据包函数加载正常","color":"green"}
