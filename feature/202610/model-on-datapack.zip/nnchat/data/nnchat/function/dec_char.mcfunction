execute store result score #b0 nn run data get storage nnchat:s out[0]
data remove storage nnchat:s out[0]
execute if score #b0 nn matches 128.. run function nnchat:dec_cjk
execute unless score #b0 nn matches 128.. run function nnchat:dec_ascii
function nnchat:dec_loop
