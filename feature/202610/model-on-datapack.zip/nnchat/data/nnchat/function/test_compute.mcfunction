# 冒烟测试: 计算 (0.5+0.25)*8 = 6
scoreboard objectives add nn dummy
execute store result score #v nn run compute default float nnchat:test_compute 8
tellraw @s [{"text":"[nnchat] test_compute = ","color":"green"},{"score":{"name":"#v","objective":"nn"},"color":"yellow"},{"text":" (期望 6)","color":"gray"}]
