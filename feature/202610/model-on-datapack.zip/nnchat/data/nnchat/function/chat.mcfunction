# 用法: function nnchat:chat {tokens:[...]}  (tools/chat.py encode 生成)
scoreboard objectives add nn dummy
$data modify storage nnchat:s tokens set value $(tokens)
function nnchat:start
