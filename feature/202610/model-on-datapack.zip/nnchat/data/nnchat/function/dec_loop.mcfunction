execute unless data storage nnchat:s out[0] run function nnchat:dec_done
execute if data storage nnchat:s out[0] run function nnchat:dec_char
