# 先置空: set string 越界会抛异常(不改变 ch), 以此检测字符串结束
data modify storage nnchat:s ch set value ""
$data modify storage nnchat:s ch set string storage nnchat:s in $(p) $(p1)
execute if data storage nnchat:s {ch:""} run function nnchat:start
execute unless data storage nnchat:s {ch:""} run function nnchat:enc_char
