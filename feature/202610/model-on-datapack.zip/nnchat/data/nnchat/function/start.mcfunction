# 共享启动器: tokens 已就绪后调用
execute store result score #len nn run data get storage nnchat:s tokens
execute if score #len nn matches 63.. run scoreboard players set #len nn 63
execute if score #len nn matches 0 run tellraw @a {"text":"[nnchat] 错误: 输入为空","color":"red"}
execute unless score #len nn matches 0 run function nnchat:start2
