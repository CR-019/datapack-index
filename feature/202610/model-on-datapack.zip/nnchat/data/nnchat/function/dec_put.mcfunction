$data modify storage nnchat:s parts append value {"text":"$(ch)"}
