# 兜底: 超过 63 字直接结束编码
execute if score #pos nn matches 63.. run function nnchat:start
execute unless score #pos nn matches 63.. run function nnchat:enc_loop2
