tellraw @a [{"text":"[nnchat] 回答: ","color":"green"},{"nbt":"parts","storage":"nnchat:s","interpret":true,"color":"yellow"}]
