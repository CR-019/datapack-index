scoreboard players set 状态 nnh 3
tellraw @a [{"text":"[nnchat] 输出 token: ","color":"gray"},{"nbt":"out","storage":"nnchat:s","color":"gray"}]
data modify storage nnchat:s parts set value []
function nnchat:dec_loop
