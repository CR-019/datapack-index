scoreboard players operation #pos1 nn = #pos nn
scoreboard players add #pos1 nn 1
execute store result storage nnchat:s ep.p int 1 run scoreboard players get #pos nn
execute store result storage nnchat:s ep.p1 int 1 run scoreboard players get #pos1 nn
function nnchat:enc_step with storage nnchat:s ep
