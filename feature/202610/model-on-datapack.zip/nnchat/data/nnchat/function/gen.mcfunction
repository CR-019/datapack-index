execute if score #btok nn matches 0 run function nnchat:done
execute if score #t nn matches 64.. run function nnchat:done
execute unless score #btok nn matches 0 unless score #t nn matches 64.. run function nnchat:gen_cont
