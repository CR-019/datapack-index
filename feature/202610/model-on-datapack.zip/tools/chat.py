# -*- coding: utf-8 -*-
"""编解码辅助: 在文本与字节 token 列表之间转换。

用法:
  py -3 tools/chat.py encode 问:你好\\n答:
      -> 打印可粘贴进游戏的 function nnchat:chat {...} 命令
  py -3 tools/chat.py decode 229,165,189,...
      -> 把 /data get storage nnchat:s out 的输出解码成文本
"""
import sys


def encode(text):
    text = text.replace("\\n", "\n")
    toks = list(text.encode("utf-8"))
    if len(toks) > 63:
        print("警告: 提示词 %d 字节, 将被截断到 63" % len(toks))
        toks = toks[:63]
    print("提示词: %r" % text)
    print("字节数: %d" % len(toks))
    print("")
    print("在游戏中执行:")
    print("function nnchat:chat {tokens:[%s]}" % ",".join(str(t) for t in toks))


def decode(s):
    s = s.strip().strip("[]")
    toks = [int(x) for x in s.replace(" ", "").split(",") if x]
    raw = bytes(toks)
    print("文本: %s" % raw.decode("utf-8", errors="replace"))


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    cmd = sys.argv[1]
    arg = " ".join(sys.argv[2:])
    if cmd == "encode":
        encode(arg)
    elif cmd == "decode":
        decode(arg)
    else:
        print(__doc__)
