# -*- coding: utf-8 -*-
"""对生成的数据包做静态自检(无游戏环境):
1. 所有提供器 JSON 可解析;
2. 函数中引用的提供器 ID 全部存在;
3. 提供器引用的 storage 路径与权重/暂存结构一致;
4. 权重文本无 NaN/Inf;
5. 统计体积与 /compute 调用次数。
"""
import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "out", "nnchat")
NS = "nnchat"

W = json.load(open(os.path.join(ROOT, "weights.json"), encoding="utf-8"))["weights"]
META = json.load(open(os.path.join(ROOT, "weights.json"), encoding="utf-8"))["meta"]
V, T, D, H, F, L = META["V"], META["T"], META["D"], META["H"], META["F"], META["L"]

SCRATCH_64 = ["x", "c", "n", "q", "k", "v", "ao", "ex", "px"]
SCRATCH_T = ["s0", "s1", "e0", "e1", "p0", "p1"]
SCALARS = ["m", "var", "inv", "mx0", "mx1", "dn0", "dn1"]

errors = []
warnings = []


def shape(key):
    def sh(v):
        if isinstance(v, list):
            return [len(v)] + sh(v[0]) if v else [0]
        return []

    return sh(W[key])


def check_w_path(path):
    m = re.match(r"^([A-Za-z0-9_]+)((\[\d+\])*)$", path)
    if not m:
        errors.append("权重路径无法解析: %s" % path)
        return
    key = m.group(1)
    idx = [int(x) for x in re.findall(r"\[(\d+)\]", path)]
    if key not in W:
        errors.append("权重不存在: %s" % key)
        return
    dims = shape(key)
    if len(idx) > len(dims):
        errors.append("权重路径维度过多: %s (shape=%s)" % (path, dims))
        return
    for i, d in enumerate(idx):
        if d >= dims[i]:
            errors.append("权重路径越界: %s (shape=%s)" % (path, dims))
            return


def check_s_path(path):
    m = re.match(r"^([A-Za-z0-9_]+)((\[\d+\])*)$", path)
    if not m:
        errors.append("状态路径无法解析: %s" % path)
        return
    name = m.group(1)
    idx = [int(x) for x in re.findall(r"\[(\d+)\]", path)]
    if name in SCRATCH_64:
        if len(idx) != 1 or idx[0] >= D:
            errors.append("状态路径越界: %s" % path)
    elif name in SCRATCH_T:
        if len(idx) != 1 or idx[0] >= T:
            errors.append("状态路径越界: %s" % path)
    elif name == "f":
        if len(idx) != 1 or idx[0] >= F:
            errors.append("状态路径越界: %s" % path)
    elif name in SCALARS:
        if idx:
            errors.append("标量不应带索引: %s" % path)
    elif re.match(r"^(kc|vc)\d$", name):
        l = int(name[2])
        if l >= L:
            errors.append("缓存层越界: %s" % path)
        if len(idx) != 2 or idx[0] >= T or idx[1] >= D:
            errors.append("缓存路径越界: %s" % path)
    elif name in ("tokens", "out", "tmp"):
        pass
    else:
        errors.append("未知状态字段: %s" % name)


def walk(obj):
    if isinstance(obj, dict):
        if obj.get("type") == "storage":
            yield obj
        for v in obj.values():
            yield from walk(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from walk(v)


def main():
    prov_dir = os.path.join(OUT, "data", NS, "context_float_provider")
    func_dir = os.path.join(OUT, "data", NS, "function")
    provs = {}
    for fn in os.listdir(prov_dir):
        with open(os.path.join(prov_dir, fn), encoding="utf-8") as f:
            try:
                provs[fn[:-5]] = json.load(f)
            except Exception as e:
                errors.append("JSON 解析失败 %s: %s" % (fn, e))
    print("提供器: %d 个, JSON 均可解析" % len(provs))

    # storage 路径检查
    n_storage = 0
    for name, obj in provs.items():
        for s in walk(obj):
            n_storage += 1
            if s["storage"] == "nnchat:w":
                check_w_path(s["path"])
            elif s["storage"] == "nnchat:s":
                check_s_path(s["path"])
            else:
                errors.append("未知 storage id: %s" % s["storage"])
    print("storage 引用: %d 处已核对" % n_storage)

    # 函数中引用的提供器存在性 + /compute 次数
    n_compute = 0
    for fn in os.listdir(func_dir):
        text = open(os.path.join(func_dir, fn), encoding="utf-8").read()
        for m in re.finditer(r"compute default float %s:([a-z0-9_]+)" % NS, text):
            n_compute += 1
            if m.group(1) not in provs:
                errors.append("函数 %s 引用了不存在的提供器 %s" % (fn, m.group(1)))
    print("/compute 调用(每 token): %d 次" % n_compute)

    # 括号平衡粗检(先剥离引号内的字符串内容)
    def strip_strings(line):
        return re.sub(r'"([^"\\]|\\.)*"', '""', line)

    for fn in os.listdir(func_dir):
        text = open(os.path.join(func_dir, fn), encoding="utf-8").read()
        for i, line in enumerate(text.splitlines()):
            s = strip_strings(line)
            if s.count("{") != s.count("}") or s.count("[") != s.count("]"):
                errors.append("%s:%d 括号不平衡: %s" % (fn, i + 1, line[:120]))

    size = sum(os.path.getsize(os.path.join(dp, f)) for dp, _, fs in os.walk(OUT) for f in fs)
    nfiles = sum(len(fs) for _, _, fs in os.walk(OUT))
    print("数据包总大小: %.1f MB, %d 个文件" % (size / 1e6, nfiles))

    for w_ in warnings:
        print("警告: " + w_)
    if errors:
        print("\n发现 %d 个错误:" % len(errors))
        for e in errors[:50]:
            print("  " + e)
        sys.exit(1)
    print("\n静态自检通过。")


if __name__ == "__main__":
    main()
