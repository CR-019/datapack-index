# -*- coding: utf-8 -*-
"""训练一个字节级微型 Transformer，用于 26.3 数据包 /compute 推理。

用法:
  py -3 tools/train.py [--steps 3000] [--gradcheck] [--out weights.json]

模型: 2 层, d_model=64, 2 头(d_head=32), FFN=128, ctx=64, 词表=256(字节),
嵌入与输出头权重绑定(E), 学习式位置编码 P, LayerNorm, ReLU FFN。
推理语义(数据包) 与训练图严格一致; simulate_chat() 按数据包的
量化/缓存/掩码行为逐步复现, 用于离线验证。
"""
import json
import math
import sys
import time

import numpy as np

# ---------------- 配置 ----------------
V, T, D, H, F = 256, 64, 64, 2, 128
L = 2
DH = D // H
EPS = 1e-5
ATTN_SCALE = 1.0 / math.sqrt(DH)
EOS = 0
QSCALE = 10000.0  # 数据包定点量化刻度

HERE = __file__.rsplit("\\", 1)[0].rsplit("/", 1)[0]
ROOT = HERE.rsplit("\\", 1)[0].rsplit("/", 1)[0]


def load_corpus(path=ROOT + "/corpus.txt"):
    samples = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.rstrip("\n")
            if not line or line.startswith("#"):
                continue
            q, a = line.split("\t")
            text = "问:" + q + "\n答:" + a + "\n"
            toks = list(text.encode("utf-8")) + [EOS]
            assert len(toks) <= T + 1, "样本超长(%d bytes): %r" % (len(toks), text)
            samples.append(toks)
    return samples


# ---------------- 权重 ----------------
def init_weights(seed=42):
    rng = np.random.default_rng(seed)
    w = {}

    def n(*shape, s=0.02):
        return (rng.standard_normal(shape) * s).astype(np.float32)

    w["E"] = n(V, D)
    w["P"] = n(T, D)
    rs = 0.02 / math.sqrt(2 * L)
    for l in range(L):
        p = "l%d_" % l
        w[p + "g1"] = np.ones(D, np.float32)
        w[p + "b1"] = np.zeros(D, np.float32)
        w[p + "Wq"], w[p + "Wk"], w[p + "Wv"] = n(D, D), n(D, D), n(D, D)
        w[p + "bq"], w[p + "bk"], w[p + "bv"] = (np.zeros(D, np.float32) for _ in range(3))
        w[p + "Wo"] = n(D, D, s=rs)
        w[p + "bo"] = np.zeros(D, np.float32)
        w[p + "g2"] = np.ones(D, np.float32)
        w[p + "b2"] = np.zeros(D, np.float32)
        w[p + "W1"] = n(D, F)
        w[p + "bf1"] = np.zeros(F, np.float32)
        w[p + "W2"] = n(F, D, s=rs)
        w[p + "bf2"] = np.zeros(D, np.float32)
    w["gf"] = np.ones(D, np.float32)
    w["bf"] = np.zeros(D, np.float32)
    return w


# ---------------- 前向(训练, 带掩码) ----------------
def layernorm(x, g, b):
    mu = x.mean(-1, keepdims=True)
    xc = x - mu
    var = (xc * xc).mean(-1, keepdims=True)
    inv = 1.0 / np.sqrt(var + EPS)
    return xc * inv * g + b, (xc, inv, g)


def ln_backward(dy, cache):
    xc, inv, g = cache
    n = xc.shape[-1]
    dg = (dy * xc * inv).sum(axis=tuple(range(dy.ndim - 1)))
    db = dy.sum(axis=tuple(range(dy.ndim - 1)))
    dxhat = dy * g
    dvar = (dxhat * xc * -0.5 * inv**3).sum(-1, keepdims=True)
    dmean = (dxhat * -inv).sum(-1, keepdims=True)  # mean(xc)=0, 第二项为 0
    dx = dxhat * inv + dvar * 2.0 * xc / n + dmean / n
    return dx, dg, db


def softmax(s):
    e = np.exp(s - s.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)


def forward(w, x, kmask):
    """x: [B,Tt] int; kmask: [B,Tt] 1=有效key. 返回 logits [B,Tt,V] 与 cache。"""
    B, Tt = x.shape
    c = {"E_in": w["E"][x], "x_in": x}
    h = c["E_in"] + w["P"][np.arange(Tt)]
    c["layers"] = []
    for l in range(L):
        p = "l%d_" % l
        lc = {}
        n1, lc["ln1"] = layernorm(h, w[p + "g1"], w[p + "b1"])
        q = n1 @ w[p + "Wq"] + w[p + "bq"]
        k = n1 @ w[p + "Wk"] + w[p + "bk"]
        v = n1 @ w[p + "Wv"] + w[p + "bv"]
        lc["n1"] = n1
        qh = q.reshape(B, Tt, H, DH).transpose(0, 2, 1, 3)
        kh = k.reshape(B, Tt, H, DH).transpose(0, 2, 1, 3)
        vh = v.reshape(B, Tt, H, DH).transpose(0, 2, 1, 3)
        s = qh @ kh.transpose(0, 1, 3, 2) * ATTN_SCALE  # [B,H,Tt,Tt]
        causal = np.tril(np.ones((Tt, Tt), bool))
        s = np.where(causal[None, None] & kmask[:, None, None, :], s, -1e30)
        pr = softmax(s)
        ao = (pr @ vh).transpose(0, 2, 1, 3).reshape(B, Tt, D)
        lc.update(qh=qh, kh=kh, vh=vh, pr=pr, ao=ao)
        o = ao @ w[p + "Wo"] + w[p + "bo"]
        h = h + o
        lc["h_after_o"] = h
        n2, lc["ln2"] = layernorm(h, w[p + "g2"], w[p + "b2"])
        fpre = n2 @ w[p + "W1"] + w[p + "bf1"]
        f = np.maximum(fpre, 0.0)
        lc.update(n2=n2, f=f)
        h = h + f @ w[p + "W2"] + w[p + "bf2"]
        c["layers"].append(lc)
    nf, c["lnf"] = layernorm(h, w["gf"], w["bf"])
    c["nf"] = nf
    logits = nf @ w["E"].T
    c["h_final"] = h
    return logits, c


def loss_and_grad(w, x, y, ymask, kmask):
    logits, c = forward(w, x, kmask)
    B, Tt, _ = logits.shape
    z = logits.reshape(B * Tt, V)
    z = z - z.max(-1, keepdims=True)
    ez = np.exp(z)
    pr = ez / ez.sum(-1, keepdims=True)
    flat_y = y.reshape(-1)
    flat_m = ymask.reshape(-1).astype(np.float32)
    nll = -np.log(pr[np.arange(B * Tt), np.clip(flat_y, 0, V - 1)] + 1e-12) * flat_m
    loss = nll.sum() / flat_m.sum()
    dz = pr
    dz[np.arange(B * Tt), np.clip(flat_y, 0, V - 1)] -= 1.0
    dz *= (flat_m / flat_m.sum())[:, None]
    dlogits = dz.reshape(B, Tt, V)

    g = {k: np.zeros_like(v) for k, v in w.items()}
    g["E"] += np.einsum("btv,btd->vd", dlogits, c["nf"])
    # 即 sum_b,t dlogits[b,t,c] * nf[b,t,:] -> dE[c,:]
    dnf = dlogits @ w["E"]
    dh, g["gf"], g["bf"] = ln_backward(dnf, c["lnf"])

    for l in reversed(range(L)):
        p = "l%d_" % l
        lc = c["layers"][l]
        # h = h2 + f@W2 + bf2 ; dh 是最终 h 的梯度
        g[p + "W2"] += lc["f"].reshape(-1, F).T @ dh.reshape(-1, D)
        g[p + "bf2"] += dh.sum(axis=(0, 1))
        df = dh @ w[p + "W2"].T
        df[lc["f"] <= 0] = 0.0  # relu
        dh2 = dh.copy()
        g[p + "W1"] += lc["n2"].reshape(-1, D).T @ df.reshape(-1, F)
        g[p + "bf1"] += df.sum(axis=(0, 1))
        dn2 = df @ w[p + "W1"].T
        dh_ln2, g[p + "g2"], g[p + "b2"] = ln_backward(dn2, lc["ln2"])
        dh2 += dh_ln2
        # h_after_o = h_in + o; dh2 流向 o 与 h_in
        dao = dh2 @ w[p + "Wo"].T
        g[p + "Wo"] += lc["ao"].reshape(-1, D).T @ dh2.reshape(-1, D)
        g[p + "bo"] += dh2.sum(axis=(0, 1))
        # ao = pr @ vh (merge heads)
        B2, Tt2, _ = lc["ao"].shape
        dao_h = dao.reshape(B2, Tt2, H, DH).transpose(0, 2, 1, 3)
        dpr = dao_h @ lc["vh"].transpose(0, 1, 3, 2)
        dvh = lc["pr"].transpose(0, 1, 3, 2) @ dao_h
        # softmax backward
        pr = lc["pr"]
        ds = pr * (dpr - (dpr * pr).sum(-1, keepdims=True))
        ds *= ATTN_SCALE
        dqh = ds @ lc["kh"]
        dkh = ds.transpose(0, 1, 3, 2) @ lc["qh"]
        dq = dqh.transpose(0, 2, 1, 3).reshape(B2, Tt2, D)
        dk = dkh.transpose(0, 2, 1, 3).reshape(B2, Tt2, D)
        dv = dvh.transpose(0, 2, 1, 3).reshape(B2, Tt2, D)
        n1 = lc["n1"]
        g[p + "Wq"] += n1.reshape(-1, D).T @ dq.reshape(-1, D)
        g[p + "Wk"] += n1.reshape(-1, D).T @ dk.reshape(-1, D)
        g[p + "Wv"] += n1.reshape(-1, D).T @ dv.reshape(-1, D)
        g[p + "bq"] += dq.sum(axis=(0, 1))
        g[p + "bk"] += dk.sum(axis=(0, 1))
        g[p + "bv"] += dv.sum(axis=(0, 1))
        dn1 = dq @ w[p + "Wq"].T + dk @ w[p + "Wk"].T + dv @ w[p + "Wv"].T
        dh_in, g[p + "g1"], g[p + "b1"] = ln_backward(dn1, lc["ln1"])
        dh = dh2 + dh_in  # 残差: h_in 还直接连到 h_after_o
    # 嵌入
    g["P"][: x.shape[1]] += dh.sum(axis=0)
    np.add.at(g["E"], c["x_in"].reshape(-1), dh.reshape(-1, D))
    return loss, g


# ---------------- 优化器 ----------------
class Adam:
    def __init__(self, w, lr=3e-3, b1=0.9, b2=0.95, eps=1e-8):
        self.m = {k: np.zeros_like(v) for k, v in w.items()}
        self.v = {k: np.zeros_like(v) for k, v in w.items()}
        self.lr, self.b1, self.b2, self.eps = lr, b1, b2, eps
        self.t = 0

    def step(self, w, g, lr=None):
        self.t += 1
        lr = lr or self.lr
        for k in w:
            self.m[k] = self.b1 * self.m[k] + (1 - self.b1) * g[k]
            self.v[k] = self.b2 * self.v[k] + (1 - self.b2) * g[k] * g[k]
            mh = self.m[k] / (1 - self.b1**self.t)
            vh = self.v[k] / (1 - self.b2**self.t)
            w[k] -= lr * mh / (np.sqrt(vh) + self.eps)


def make_batch(samples, rng, B=16):
    x = np.zeros((B, T), np.int64)
    y = np.zeros((B, T), np.int64)
    ym = np.zeros((B, T), np.int64)
    km = np.zeros((B, T), np.int64)
    for i in range(B):
        s = samples[rng.integers(len(samples))]
        n = min(len(s), T + 1)
        seq = s[:n]
        inp = seq[:-1]
        tgt = seq[1:]
        x[i, : len(inp)] = inp
        y[i, : len(tgt)] = tgt
        ym[i, : len(tgt)] = 1
        km[i, : len(inp)] = 1
    return x, y, ym, km


def gradcheck(w):
    w = {k: v.astype(np.float64) for k, v in w.items()}
    samples = load_corpus()
    x, y, ym, km = make_batch(samples, np.random.default_rng(0), B=2)
    loss, g = loss_and_grad(w, x, y, ym, km)
    keys = ["E", "P", "l0_Wq", "l0_W2", "l1_g1", "l1_W1", "gf", "l0_Wo", "l1_Wk"]
    eps = 1e-5
    ok = True
    for k in keys:
        flat = w[k].reshape(-1)
        gf = g[k].reshape(-1)
        idxs = np.linspace(0, flat.size - 1, 4).astype(int)
        for i in idxs:
            old = flat[i]
            flat[i] = old + eps
            lp, _ = loss_and_grad(w, x, y, ym, km)
            flat[i] = old - eps
            lm, _ = loss_and_grad(w, x, y, ym, km)
            flat[i] = old
            num = (lp - lm) / (2 * eps)
            rel = abs(num - gf[i]) / max(1e-6, abs(num) + abs(gf[i]))
            status = "OK " if rel < 2e-2 else "BAD"
            if rel >= 2e-2:
                ok = False
            print("  %s %-8s [%d] analytic=%.5f numeric=%.5f rel=%.4f" % (status, k, i, gf[i], num, rel))
    print("梯度检查: %s" % ("通过" if ok else "失败"))
    return ok


# ---------------- 数据包语义推理模拟 ----------------
ACT_QUANT = True  # False = 模拟 data modify ... set compute 的 float32 直写


def q32(v):
    """float32 + 可选的 floor 量化(对应 execute store 链路)。"""
    if not ACT_QUANT:
        return np.float32(v)
    return np.float32(np.floor(np.float32(v) * QSCALE) / QSCALE)


def simulate_step(w, caches, tok, t):
    """对位置 t 的 token 做一步前向(数据包语义), 返回下一 token 的 argmax。"""
    x = np.array([q32(w["E"][tok][j] + w["P"][t][j]) for j in range(D)], np.float32)
    for l in range(L):
        p = "l%d_" % l

        def ln(xin, g, b):
            m = q32(np.float32(xin.mean()))
            c = np.array([q32(xin[j] - m) for j in range(D)], np.float32)
            var = q32(np.float32((c * c).mean()))
            inv = q32(np.float32((var + EPS) ** -0.5))
            return np.array([q32(np.float32(np.float32(c[j] * inv) * g[j] + b[j])) for j in range(D)], np.float32)

        def dot(a, brow, bias=0.0):
            acc = np.float32(0.0)
            for j in range(len(a)):
                acc = np.float32(acc + np.float32(a[j] * brow[j]))
            return q32(acc + np.float32(bias))

        n1 = ln(x, w[p + "g1"], w[p + "b1"])
        qv = np.array([dot(n1, w[p + "Wq"][:, i], w[p + "bq"][i]) for i in range(D)], np.float32)
        kv = np.array([dot(n1, w[p + "Wk"][:, i], w[p + "bk"][i]) for i in range(D)], np.float32)
        vv = np.array([dot(n1, w[p + "Wv"][:, i], w[p + "bv"][i]) for i in range(D)], np.float32)
        kcache, vcache = caches[l]
        kcache.append(kv)
        vcache.append(vv)
        ao = np.zeros(D, np.float32)
        for h in range(H):
            s = np.full(T, -1e30, np.float32)
            for j in range(t + 1):
                acc = np.float32(0.0)
                for u in range(DH):
                    acc = np.float32(acc + np.float32(qv[h * DH + u] * kcache[j][h * DH + u]))
                s[j] = q32(acc * np.float32(ATTN_SCALE))
            mx = q32(s.max())
            e = np.array([q32(np.float32(math.e) ** q32(s[j] - mx)) for j in range(T)], np.float32)
            dn = q32(np.float32(e.sum()))
            pr = np.array([q32(e[j] / dn) for j in range(T)], np.float32)
            for d in range(DH):
                acc = np.float32(0.0)
                for j in range(T):
                    pj = pr[j]
                    vij = vcache[j][h * DH + d] if j < len(vcache) else np.float32(0.0)
                    acc = np.float32(acc + np.float32(pj * vij))
                ao[h * DH + d] = q32(acc)
        x = np.array([q32(dot(ao, w[p + "Wo"][:, i]) + np.float32(w[p + "bo"][i]) + x[i]) for i in range(D)], np.float32)
        n2 = ln(x, w[p + "g2"], w[p + "b2"])
        f = np.array([max(q32(dot(n2, w[p + "W1"][:, i], w[p + "bf1"][i])), np.float32(0.0)) for i in range(F)], np.float32)
        x = np.array([q32(dot(f, w[p + "W2"][:, i]) + np.float32(w[p + "bf2"][i]) + x[i]) for i in range(D)], np.float32)
    # 最终 LN + 绑定头
    m = q32(np.float32(x.mean()))
    c = np.array([q32(x[j] - m) for j in range(D)], np.float32)
    var = q32(np.float32((c * c).mean()))
    inv = q32(np.float32((var + EPS) ** -0.5))
    nf = np.array([q32(np.float32(np.float32(c[j] * inv) * w["gf"][j] + w["bf"][j])) for j in range(D)], np.float32)
    best, btok = -2**31, 0
    for tkn in range(V):
        acc = np.float32(0.0)
        for j in range(D):
            acc = np.float32(acc + np.float32(nf[j] * w["E"][tkn][j]))
        sc = int(np.floor(np.float32(acc) * QSCALE))
        if sc > best:
            best, btok = sc, tkn
    return btok


def simulate_chat(w, prompt_text, max_gen=T, verbose=True):
    caches = [([], []) for _ in range(L)]
    toks = list(prompt_text.encode("utf-8"))
    assert len(toks) < T
    btok = toks[0]
    out = []
    pos = 0
    # 喂入提示词
    for t in range(len(toks)):
        nxt = simulate_step(w, caches, toks[t], t)
        pos = t + 1
    btok = nxt
    while btok != EOS and pos < T and len(out) < max_gen:
        out.append(btok)
        btok = simulate_step(w, caches, btok, pos)
        pos += 1
    raw = bytes(out)
    text = raw.decode("utf-8", errors="replace")
    if verbose:
        print("  提示: %r -> 输出: %r (bytes=%s)" % (prompt_text, text, out[:24]))
    return text, out


# ---------------- 导出 ----------------
def export(w, path):
    out = {}
    for k, v in w.items():
        out[k] = np.asarray(v, np.float32).tolist()
    meta = {"V": V, "T": T, "D": D, "H": H, "F": F, "L": L, "eps": EPS, "qscale": QSCALE}
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"meta": meta, "weights": out}, f)
    n = sum(np.asarray(v).size for v in w.values())
    print("已导出 %s (%d 参数)" % (path, n))


def main():
    global ACT_QUANT
    steps = 3000
    out_path = ROOT + "/weights.json"
    do_check = "--gradcheck" in sys.argv
    if "--no-quant" in sys.argv:
        ACT_QUANT = False
    for i, a in enumerate(sys.argv):
        if a == "--steps":
            steps = int(sys.argv[i + 1])
        if a == "--out":
            out_path = sys.argv[i + 1]
    if "--sim-only" in sys.argv:
        # 从 weights.json 恢复权重, 仅跑数据包语义模拟
        raw = json.load(open(out_path, encoding="utf-8"))["weights"]
        w = {k: np.asarray(v, np.float32) for k, v in raw.items()}
        print("模拟模式: %s" % ("float32 直写(set compute)" if not ACT_QUANT else "floor 量化(/compute+store)"))
        for q in ["问:你好\n答:", "问:你是谁\n答:", "问:什么是红石\n答:", "问:讲个笑话\n答:", "问:再见\n答:"]:
            simulate_chat(w, q)
        return
    samples = load_corpus()
    print("语料: %d 条样本" % len(samples))
    w = init_weights()
    if do_check:
        if not gradcheck(w):
            sys.exit(1)
        return
    rng = np.random.default_rng(1)
    opt = Adam(w)
    t0 = time.time()
    for step in range(1, steps + 1):
        x, y, ym, km = make_batch(samples, rng)
        loss, g = loss_and_grad(w, x, y, ym, km)
        # 梯度裁剪
        norm = math.sqrt(sum(float((v * v).sum()) for v in g.values()))
        if norm > 1.0:
            for k in g:
                g[k] *= 1.0 / norm
        lr = 3e-3 * (0.5 * (1 + math.cos(math.pi * step / steps))) + 3e-4
        opt.step(w, g, lr=lr)
        if step % 200 == 0 or step == 1:
            print("step %4d/%d loss=%.4f gnorm=%.3f (%.1fs)" % (step, steps, loss, norm, time.time() - t0))
    print("训练完成, 最终 loss=%.4f" % loss)
    print("---- 数据包语义模拟自测 ----")
    for q in ["问:你好\n答:", "问:你是谁\n答:", "问:什么是红石\n答:", "问:讲个笑话\n答:", "问:再见\n答:"]:
        simulate_chat(w, q)
    export(w, out_path)


if __name__ == "__main__":
    main()
