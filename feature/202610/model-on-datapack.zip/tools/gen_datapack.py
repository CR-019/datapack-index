# -*- coding: utf-8 -*-
"""把 weights.json 编译成 Minecraft Java 26.3 数据包 (out/nnchat)。

推理全部通过 /compute + context_float_provider 完成, 激活值以定点
(floor(v*10000)*0.0001) 存进命令存储 nnchat:s, 权重存 nnchat:w。
KV cache: 每层 kc{l}/vc{l} 为 64 维向量列表, 逐位置 append。
控制流(嵌入查表/argmax/生成循环)由 mcfunction 完成。

用法: py -3 tools/gen_datapack.py [weights.json]
"""
import json
import math
import os
import shutil
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "out", "nnchat")
NS = "nnchat"
WS = "nnchat:w"  # 权重存储
SS = "nnchat:s"  # 状态存储
QS = 10000       # /compute 量化刻度

W = json.load(open(os.path.join(ROOT, "weights.json"), encoding="utf-8"))["weights"] \
    if len(sys.argv) < 2 else json.load(open(sys.argv[1], encoding="utf-8"))["weights"]
META = json.load(open(os.path.join(ROOT, "weights.json"), encoding="utf-8"))["meta"] \
    if len(sys.argv) < 2 else json.load(open(sys.argv[1], encoding="utf-8"))["meta"]
V, T, D, H, F, L = META["V"], META["T"], META["D"], META["H"], META["F"], META["L"]
DH = D // H
ATTN_SCALE = 1.0 / math.sqrt(DH)
E_CONST = 2.718281828459045

PROVIDERS = {}  # name -> json


def stw(path):
    return {"type": "storage", "storage": WS, "path": path}


def sts(path):
    return {"type": "storage", "storage": SS, "path": path}


def add(*xs):
    return {"type": "add", "inputs": list(xs)}


def mul(a, b):
    return {"type": "mul", "inputs": [a, b]}


def sub(a, b):
    return {"type": "sub", "left": a, "right": b}


def div(a, b):
    return {"type": "div", "left": a, "right": b}


def powp(a, b):
    return {"type": "pow", "base": a, "exponent": b}


def maxp(*xs):
    return {"type": "max", "inputs": list(xs)}


def avgp(*xs):
    return {"type": "avg", "inputs": list(xs)}


def dot(name, wpath_fmt, inpath_fmt, n, bias_path=None, extra=None, relu=False, scale=None):
    """生成点积提供器: sum_j mul(W[wpath_fmt(j)], S[inpath_fmt(j)]) + bias + extra"""
    inputs = [mul(stw(wpath_fmt % j), sts(inpath_fmt % j)) for j in range(n)]
    if bias_path:
        inputs.append(stw(bias_path))
    if extra:
        inputs.extend(extra)
    body = add(*inputs)
    if scale is not None:
        body = mul(body, scale)
    if relu:
        body = maxp(body, 0.0)
    PROVIDERS[name] = body


def emit_layer(l):
    p = "l%d_" % l
    # ---- LN1: n = ln(x) ----
    PROVIDERS[p + "m1"] = avgp(*[sts("x[%d]" % j) for j in range(D)])
    for j in range(D):
        PROVIDERS[p + "c1_%d" % j] = sub(sts("x[%d]" % j), sts("m"))
    PROVIDERS[p + "var1"] = avgp(*[powp(sts("c[%d]" % j), 2.0) for j in range(D)])
    PROVIDERS[p + "inv1"] = powp(add(sts("var"), 1e-05), -0.5)
    for j in range(D):
        PROVIDERS[p + "n1_%d" % j] = add(
            mul(mul(sts("c[%d]" % j), sts("inv")), stw(p + "g1[%d]" % j)), stw(p + "b1[%d]" % j)
        )
    # ---- QKV ----
    for i in range(D):
        dot(p + "q_%d" % i, p + "Wq[%d][" + "%d" % i + "]", "n[%d]", D, p + "bq[%d]" % i)
    for i in range(D):
        dot(p + "k_%d" % i, p + "Wk[%d][" + "%d" % i + "]", "n[%d]", D, p + "bk[%d]" % i)
    for i in range(D):
        dot(p + "v_%d" % i, p + "Wv[%d][" + "%d" % i + "]", "n[%d]", D, p + "bv[%d]" % i)
    # ---- 注意力分数(带因果/长度掩码) ----
    for h in range(H):
        for j in range(T):
            body = add(*[mul(sts("q[%d]" % (h * DH + u)), sts("kc%d[%d][%d]" % (l, j, h * DH + u))) for u in range(DH)])
            cond = {
                "type": "int_value_check",
                "value": {"type": "score", "target": {"type": "fixed", "name": "#t"}, "score": "nn"},
                "test": {"min": j},
            }
            PROVIDERS[p + "s%d_%d" % (h, j)] = {
                "type": "conditional",
                "condition": cond,
                "on_true": mul(body, ATTN_SCALE),
                "on_false": -1e30,
            }
    for h in range(H):
        PROVIDERS[p + "mx%d" % h] = maxp(*[sts("s%d[%d]" % (h, j)) for j in range(T)])
    for h in range(H):
        for j in range(T):
            PROVIDERS[p + "e%d_%d" % (h, j)] = powp(
                E_CONST, sub(sts("s%d[%d]" % (h, j)), sts("mx%d" % h))
            )
    for h in range(H):
        PROVIDERS[p + "dn%d" % h] = add(*[sts("e%d[%d]" % (h, j)) for j in range(T)])
    for h in range(H):
        for j in range(T):
            PROVIDERS[p + "p%d_%d" % (h, j)] = div(sts("e%d[%d]" % (h, j)), sts("dn%d" % h))
    # ---- 注意力加权和 ----
    for d in range(D):
        h = d // DH
        PROVIDERS[p + "ao_%d" % d] = add(
            *[mul(sts("p%d[%d]" % (h, j)), sts("vc%d[%d][%d]" % (l, j, d))) for j in range(T)]
        )
    # ---- 输出投影 + 残差 ----
    for i in range(D):
        dot(p + "o_%d" % i, p + "Wo[%d][" + "%d" % i + "]", "ao[%d]", D, p + "bo[%d]" % i, extra=[sts("x[%d]" % i)])
    # ---- LN2 ----
    PROVIDERS[p + "m2"] = avgp(*[sts("x[%d]" % j) for j in range(D)])
    for j in range(D):
        PROVIDERS[p + "c2_%d" % j] = sub(sts("x[%d]" % j), sts("m"))
    PROVIDERS[p + "var2"] = avgp(*[powp(sts("c[%d]" % j), 2.0) for j in range(D)])
    PROVIDERS[p + "inv2"] = powp(add(sts("var"), 1e-05), -0.5)
    for j in range(D):
        PROVIDERS[p + "n2_%d" % j] = add(
            mul(mul(sts("c[%d]" % j), sts("inv")), stw(p + "g2[%d]" % j)), stw(p + "b2[%d]" % j)
        )
    # ---- FFN ----
    for i in range(F):
        dot(p + "f_%d" % i, p + "W1[%d][" + "%d" % i + "]", "n[%d]", D, p + "bf1[%d]" % i, relu=True)
    for i in range(D):
        dot(p + "g_%d" % i, p + "W2[%d][" + "%d" % i + "]", "f[%d]", F, p + "bf2[%d]" % i, extra=[sts("x[%d]" % i)])


def emit_final_and_head():
    PROVIDERS["f_m"] = avgp(*[sts("x[%d]" % j) for j in range(D)])
    for j in range(D):
        PROVIDERS["f_c_%d" % j] = sub(sts("x[%d]" % j), sts("m"))
    PROVIDERS["f_var"] = avgp(*[powp(sts("c[%d]" % j), 2.0) for j in range(D)])
    PROVIDERS["f_inv"] = powp(add(sts("var"), 1e-05), -0.5)
    for j in range(D):
        PROVIDERS["f_n_%d" % j] = add(
            mul(mul(sts("c[%d]" % j), sts("inv")), stw("gf[%d]" % j)), stw("bf[%d]" % j)
        )
    for c in range(V):
        dot("logit_%d" % c, "E[" + "%d][" % c + "%d]", "n[%d]", D)


def emit_embed():
    for j in range(D):
        PROVIDERS["emb_%d" % j] = add(sts("ex[%d]" % j), sts("px[%d]" % j))
    PROVIDERS["test_compute"] = add(0.5, 0.25)


# ---------------- mcfunction ----------------
def compute_line(prov, store_path):
    # data modify ... set compute: 直接写入 float32, 无 /compute 的 int 量化
    return "data modify storage %s %s set compute default float %s:%s" % (SS, store_path, NS, prov)


def gen_forward():
    L_ = []
    A = L_.append
    A("# --- 词嵌入/位置嵌入查表 (宏代入运行时下标) ---")
    A("execute store result storage %s ei.i int 1 run scoreboard players get #btok nn" % SS)
    A("function %s:emb_tok with storage %s ei" % (NS, SS))
    A("execute store result storage %s ei.i int 1 run scoreboard players get #t nn" % SS)
    A("function %s:emb_pos with storage %s ei" % (NS, SS))
    for j in range(D):
        A(compute_line("emb_%d" % j, "x[%d]" % j))
    for l in range(L):
        p = "l%d_" % l
        A("# --- 层 %d: LN1 ---" % l)
        A(compute_line(p + "m1", "m"))
        for j in range(D):
            A(compute_line(p + "c1_%d" % j, "c[%d]" % j))
        A(compute_line(p + "var1", "var"))
        A(compute_line(p + "inv1", "inv"))
        for j in range(D):
            A(compute_line(p + "n1_%d" % j, "n[%d]" % j))
        A("# --- 层 %d: QKV ---" % l)
        for i in range(D):
            A(compute_line(p + "q_%d" % i, "q[%d]" % i))
        for i in range(D):
            A(compute_line(p + "k_%d" % i, "k[%d]" % i))
        for i in range(D):
            A(compute_line(p + "v_%d" % i, "v[%d]" % i))
        A("data modify storage %s kc%d append from storage %s k" % (SS, l, SS))
        A("data modify storage %s vc%d append from storage %s v" % (SS, l, SS))
        A("# --- 层 %d: 注意力 ---" % l)
        for h in range(H):
            for j in range(T):
                A(compute_line(p + "s%d_%d" % (h, j), "s%d[%d]" % (h, j)))
        A(compute_line(p + "mx0", "mx0"))
        A(compute_line(p + "mx1", "mx1"))
        for h in range(H):
            for j in range(T):
                A(compute_line(p + "e%d_%d" % (h, j), "e%d[%d]" % (h, j)))
        A(compute_line(p + "dn0", "dn0"))
        A(compute_line(p + "dn1", "dn1"))
        for h in range(H):
            for j in range(T):
                A(compute_line(p + "p%d_%d" % (h, j), "p%d[%d]" % (h, j)))
        for d in range(D):
            A(compute_line(p + "ao_%d" % d, "ao[%d]" % d))
        for i in range(D):
            A(compute_line(p + "o_%d" % i, "x[%d]" % i))
        A("# --- 层 %d: LN2 + FFN ---" % l)
        A(compute_line(p + "m2", "m"))
        for j in range(D):
            A(compute_line(p + "c2_%d" % j, "c[%d]" % j))
        A(compute_line(p + "var2", "var"))
        A(compute_line(p + "inv2", "inv"))
        for j in range(D):
            A(compute_line(p + "n2_%d" % j, "n[%d]" % j))
        for i in range(F):
            A(compute_line(p + "f_%d" % i, "f[%d]" % i))
        for i in range(D):
            A(compute_line(p + "g_%d" % i, "x[%d]" % i))
    A("# --- 最终 LN + 绑定输出头 ---")
    A(compute_line("f_m", "m"))
    for j in range(D):
        A(compute_line("f_c_%d" % j, "c[%d]" % j))
    A(compute_line("f_var", "var"))
    A(compute_line("f_inv", "inv"))
    for j in range(D):
        A(compute_line("f_n_%d" % j, "n[%d]" % j))
    A("scoreboard players set #best nn -2147483648")
    A("scoreboard players set #btok nn 0")
    for c in range(V):
        A("execute store result score #v nn run compute default float %s:logit_%d %d" % (NS, c, QS))
        A("execute if score #v nn > #best nn run function %s:amax {tok:%d}" % (NS, c))
    return L_


def fmt_d(x):
    v = float(x)
    assert math.isfinite(v)
    s = "%.8g" % v
    if "e" in s or "." in s:
        return s + "d"
    return s + ".0d" if abs(v) < 1e16 else s + "d"


def snbt(value):
    if isinstance(value, list):
        return "[" + ",".join(snbt(x) for x in value) + "]"
    return fmt_d(value)


def gen_init():
    L_ = ["scoreboard objectives add nn dummy",
          'scoreboard objectives add nnh dummy {"text":"nnchat 推理","color":"aqua"}',
          "scoreboard objectives setdisplay sidebar nnh",
          "scoreboard players set 状态 nnh 0",
          "scoreboard players set 位置 nnh 0",
          "scoreboard players set 生成 nnh 0",
          "scoreboard players set 总长 nnh 0"]
    for k in sorted(W.keys()):
        L_.append("data modify storage %s %s set value %s" % (WS, k, snbt(W[k])))
    zeros64 = "[" + ",".join(["0.0d"] * D) + "]"
    zerosF = "[" + ",".join(["0.0d"] * F) + "]"
    zerosT = "[" + ",".join(["0.0d"] * T) + "]"
    for name in ["x", "c", "n", "q", "k", "v", "ao", "ex", "px"]:
        L_.append("data modify storage %s %s set value %s" % (SS, name, zeros64))
    for name in ["s0", "s1", "e0", "e1", "p0", "p1"]:
        L_.append("data modify storage %s %s set value %s" % (SS, name, zerosT))
    L_.append("data modify storage %s f set value %s" % (SS, zerosF))
    for name in ["m", "var", "inv", "mx0", "mx1", "dn0", "dn1"]:
        L_.append("data modify storage %s %s set value 0.0d" % (SS, name))
    L_.append("data modify storage %s tmp set value 0" % SS)
    L_.append("data modify storage %s tokens set value []" % SS)
    L_.append("data modify storage %s out set value []" % SS)
    for l in range(L):
        L_.append("data modify storage %s kc%d set value []" % (SS, l))
        L_.append("data modify storage %s vc%d set value []" % (SS, l))
    L_.append('tellraw @a {"text":"[nnchat] 权重已加载 (%d 参数)","color":"green"}' % sum(
        _count(v) for v in W.values()))
    return L_


def _count(v):
    if isinstance(v, list):
        return sum(_count(x) for x in v)
    return 1


def build_charset():
    """从语料提取字符集(模型只认识这些字), 加上可打印 ASCII。"""
    chars = set()
    with open(os.path.join(ROOT, "corpus.txt"), encoding="utf-8") as f:
        for line in f:
            line = line.rstrip("\n")
            if not line or line.startswith("#"):
                continue
            q, a = line.split("\t")
            chars.update("问:" + q + "答:" + a)
    for i in range(32, 127):
        chars.add(chr(i))
    chars.discard('"')   # SNBT 字符串定界符
    chars.discard("\\")  # SNBT 转义符
    chars.discard("|")   # 保留作换行占位符
    return sorted(chars)


CHARSET = build_charset()
CJK = [c for c in CHARSET if len(c.encode("utf-8")) == 3]
ASCII = [c for c in CHARSET if len(c.encode("utf-8")) == 1]


def gen_codec_functions():
    """数据包内编解码: ask(文本输入) + done(输出解码渲染)。"""
    # ---- 编码: 文本 -> UTF-8 字节列表 ----
    FUNCTIONS["ask"] = [
        "# 用法: function nnchat:ask {text:\"问:你好|答:\"}   (| 代表换行)",
        "scoreboard objectives add nn dummy",
        '$data modify storage %s in set value "$(text)"' % SS,
        "data modify storage %s tokens set value []" % SS,
        "scoreboard players set #pos nn 0",
        "function %s:enc_loop" % NS,
    ]
    FUNCTIONS["enc_loop"] = [
        "# 兜底: 超过 63 字直接结束编码",
        "execute if score #pos nn matches 63.. run function %s:start" % NS,
        "execute unless score #pos nn matches 63.. run function %s:enc_loop2" % NS,
    ]
    FUNCTIONS["enc_loop2"] = [
        "scoreboard players operation #pos1 nn = #pos nn",
        "scoreboard players add #pos1 nn 1",
        "execute store result storage %s ep.p int 1 run scoreboard players get #pos nn" % SS,
        "execute store result storage %s ep.p1 int 1 run scoreboard players get #pos1 nn" % SS,
        "function %s:enc_step with storage %s ep" % (NS, SS),
    ]
    FUNCTIONS["enc_step"] = [
        "# 先置空: set string 越界会抛异常(不改变 ch), 以此检测字符串结束",
        'data modify storage %s ch set value ""' % SS,
        "$data modify storage %s ch set string storage %s in $(p) $(p1)" % (SS, SS),
        'execute if data storage %s {ch:""} run function %s:start' % (SS, NS),
        'execute unless data storage %s {ch:""} run function %s:enc_char' % (SS, NS),
    ]
    enc = ["scoreboard players set #m nn 0"]
    for c in CHARSET + ["|"]:
        bs = [10] if c == "|" else list(c.encode("utf-8"))
        cond = 'execute if data storage %s {ch:"%s"}' % (SS, c)
        for k, b in enumerate(bs):
            line = cond + (" store success score #m nn" if k == 0 else "")
            line += " run data modify storage %s tokens append value %d" % (SS, b)
            enc.append(line)
    enc += [
        "# 未知字符 -> '?'",
        "execute if score #m nn matches 0 run data modify storage %s tokens append value 63" % SS,
        "scoreboard players add #pos nn 1",
        "function %s:enc_loop" % NS,
    ]
    FUNCTIONS["enc_char"] = enc
    # ---- 解码: 字节列表 -> 文本组件渲染 ----
    FUNCTIONS["dec_loop"] = [
        "execute unless data storage %s out[0] run function %s:dec_done" % (SS, NS),
        "execute if data storage %s out[0] run function %s:dec_char" % (SS, NS),
    ]
    FUNCTIONS["dec_char"] = [
        "execute store result score #b0 nn run data get storage %s out[0]" % SS,
        "data remove storage %s out[0]" % SS,
        "execute if score #b0 nn matches 128.. run function %s:dec_cjk" % NS,
        "execute unless score #b0 nn matches 128.. run function %s:dec_ascii" % NS,
        "function %s:dec_loop" % NS,
    ]
    cjk = [
        "execute store result score #b1 nn run data get storage %s out[0]" % SS,
        "data remove storage %s out[0]" % SS,
        "execute store result score #b2 nn run data get storage %s out[0]" % SS,
        "data remove storage %s out[0]" % SS,
        "execute store result storage %s tk.b0 int 1 run scoreboard players get #b0 nn" % SS,
        "execute store result storage %s tk.b1 int 1 run scoreboard players get #b1 nn" % SS,
        "execute store result storage %s tk.b2 int 1 run scoreboard players get #b2 nn" % SS,
        "scoreboard players set #m nn 0",
    ]
    for c in CJK:
        b0, b1, b2 = c.encode("utf-8")
        cjk.append(
            "execute if data storage %s {tk:{b0:%d,b1:%d,b2:%d}} store success score #m nn run function %s:dec_put {ch:\"%s\"}"
            % (SS, b0, b1, b2, NS, c)
        )
    cjk.append('execute if score #m nn matches 0 run function %s:dec_put {ch:"?"}' % NS)
    FUNCTIONS["dec_cjk"] = cjk
    asc = [
        "scoreboard players set #m nn 0",
        "# 换行: 渲染为空(答案自带的结尾换行)",
        "execute if score #b0 nn matches 10 run scoreboard players set #m nn 1",
    ]
    for c in ASCII:
        b = ord(c)
        asc.append(
            'execute if score #b0 nn matches %d store success score #m nn run function %s:dec_put {ch:"%s"}' % (b, NS, c)
        )
    asc.append('execute if score #m nn matches 0 run function %s:dec_put {ch:"?"}' % NS)
    FUNCTIONS["dec_ascii"] = asc
    FUNCTIONS["dec_put"] = [
        '$data modify storage %s parts append value {"text":"$(ch)"}' % SS,
    ]
    FUNCTIONS["dec_done"] = [
        'tellraw @a [{"text":"[nnchat] 回答: ","color":"green"},{"nbt":"parts","storage":"%s","interpret":true,"color":"yellow"}]' % SS,
    ]


FUNCTIONS = {}


def gen_functions():
    FUNCTIONS["init"] = gen_init()
    FUNCTIONS["ping"] = [
        'tellraw @s {"text":"[nnchat] pong! 数据包函数加载正常","color":"green"}',
    ]
    FUNCTIONS["test_compute"] = [
        "# 冒烟测试: 计算 (0.5+0.25)*8 = 6",
        "scoreboard objectives add nn dummy",
        "execute store result score #v nn run compute default float %s:test_compute 8" % NS,
        'tellraw @s [{"text":"[nnchat] test_compute = ","color":"green"},{"score":{"name":"#v","objective":"nn"},"color":"yellow"},{"text":" (期望 6)","color":"gray"}]',
    ]
    FUNCTIONS["forward"] = gen_forward()
    FUNCTIONS["amax"] = [
        "$scoreboard players set #btok nn $(tok)",
        "scoreboard players operation #best nn = #v nn",
    ]
    FUNCTIONS["emb_tok"] = [
        "$data modify storage %s ex set from storage %s E[$(i)]" % (SS, WS),
    ]
    FUNCTIONS["emb_pos"] = [
        "$data modify storage %s px set from storage %s P[$(i)]" % (SS, WS),
    ]
    FUNCTIONS["chat"] = [
        "# 用法: function nnchat:chat {tokens:[...]}  (tools/chat.py encode 生成)",
        "scoreboard objectives add nn dummy",
        "$data modify storage %s tokens set value $(tokens)" % SS,
        "function %s:start" % NS,
    ]
    FUNCTIONS["start"] = [
        "# 共享启动器: tokens 已就绪后调用",
        "execute store result score #len nn run data get storage %s tokens" % SS,
        "execute if score #len nn matches 63.. run scoreboard players set #len nn 63",
        'execute if score #len nn matches 0 run tellraw @a {"text":"[nnchat] 错误: 输入为空","color":"red"}',
        "execute unless score #len nn matches 0 run function %s:start2" % NS,
    ]
    FUNCTIONS["start2"] = [
        "data modify storage %s out set value []" % SS,
        "data modify storage %s kc0 set value []" % SS,
        "data modify storage %s kc1 set value []" % SS,
        "data modify storage %s vc0 set value []" % SS,
        "data modify storage %s vc1 set value []" % SS,
        "scoreboard players set #t nn 0",
        "scoreboard players set 状态 nnh 1",
        "scoreboard players operation 总长 nnh = #len nn",
        "scoreboard players set 位置 nnh 0",
        "scoreboard players set 生成 nnh 0",
        'tellraw @a [{"text":"[nnchat] 开始推理, 提示长度 ","color":"green"},{"score":{"name":"#len","objective":"nn"},"color":"yellow"}]',
        "schedule function %s:feed 1t" % NS,
    ]
    FUNCTIONS["feed"] = [
        "execute store result score #btok nn run data get storage %s tokens[0]" % SS,
        "data remove storage %s tokens[0]" % SS,
        "function %s:forward" % NS,
        "scoreboard players add #t nn 1",
        "scoreboard players operation 位置 nnh = #t nn",
        "execute if score #t nn < #len nn run schedule function %s:feed 1t" % NS,
        "execute unless score #t nn < #len nn run schedule function %s:gen 1t" % NS,
    ]
    FUNCTIONS["gen"] = [
        "execute if score #btok nn matches 0 run function %s:done" % NS,
        "execute if score #t nn matches 64.. run function %s:done" % NS,
        "execute unless score #btok nn matches 0 unless score #t nn matches 64.. run function %s:gen_cont" % NS,
    ]
    FUNCTIONS["gen_cont"] = [
        "execute store result storage %s tmp int 1 run scoreboard players get #btok nn" % SS,
        "data modify storage %s out append from storage %s tmp" % (SS, SS),
        "scoreboard players set 状态 nnh 2",
        "execute store result score 生成 nnh run data get storage %s out" % SS,
        "function %s:forward" % NS,
        "scoreboard players add #t nn 1",
        "scoreboard players operation 位置 nnh = #t nn",
        "schedule function %s:gen 1t" % NS,
    ]
    FUNCTIONS["done"] = [
        "scoreboard players set 状态 nnh 3",
        'tellraw @a [{"text":"[nnchat] 输出 token: ","color":"gray"},{"nbt":"out","storage":"%s","color":"gray"}]' % SS,
        "data modify storage %s parts set value []" % SS,
        "function %s:dec_loop" % NS,
    ]
    FUNCTIONS["stop"] = [
        "# 紧急停止生成循环",
        "schedule clear %s:feed" % NS,
        "schedule clear %s:gen" % NS,
        "scoreboard players set 状态 nnh 0",
        'tellraw @a {"text":"[nnchat] 已停止所有推理任务","color":"red"}',
    ]


def main():
    if os.path.exists(OUT):
        shutil.rmtree(OUT)
    prov_dir = os.path.join(OUT, "data", NS, "context_float_provider")
    func_dir = os.path.join(OUT, "data", NS, "function")
    os.makedirs(prov_dir)
    os.makedirs(func_dir)

    emit_embed()
    for l in range(L):
        emit_layer(l)
    emit_final_and_head()
    gen_functions()
    gen_codec_functions()

    with open(os.path.join(OUT, "pack.mcmeta"), "w", encoding="utf-8") as f:
        json.dump({"pack": {"min_format": 99, "max_format": 99999, "description": "nnchat: /compute 微型中文对话 transformer"}}, f, ensure_ascii=False, indent=2)

    # minecraft:load 标签 -> 进世界/重载时自动执行 nnchat:init
    tag_dir = os.path.join(OUT, "data", "minecraft", "tags", "function")
    os.makedirs(tag_dir)
    with open(os.path.join(tag_dir, "load.json"), "w", encoding="utf-8") as f:
        json.dump({"values": ["nnchat:init"]}, f, indent=2)

    total_bytes = 0
    for name, obj in PROVIDERS.items():
        s = json.dumps(obj, separators=(",", ":"))
        total_bytes += len(s.encode("utf-8"))
        with open(os.path.join(prov_dir, name + ".json"), "w", encoding="utf-8") as f:
            f.write(s)
    func_bytes = 0
    for name, lines in FUNCTIONS.items():
        s = "\n".join(lines) + "\n"
        func_bytes += len(s.encode("utf-8"))
        with open(os.path.join(func_dir, name + ".mcfunction"), "w", encoding="utf-8") as f:
            f.write(s)

    print("数据包已生成: %s" % OUT)
    print("  提供器: %d 个 (%.1f MB)" % (len(PROVIDERS), total_bytes / 1e6))
    print("  函数:   %d 个 (%.1f MB)" % (len(FUNCTIONS), func_bytes / 1e6))
    print("  forward.mcfunction: %d 行" % len(FUNCTIONS["forward"]))
    n_params = sum(_count(v) for v in W.values())
    print("  参数:   %d" % n_params)
    print("  字符集: %d 个 (CJK %d, ASCII %d)" % (len(CHARSET), len(CJK), len(ASCII)))


if __name__ == "__main__":
    main()
