# -*- coding: utf-8 -*-
"""把论文、工具链、语料、权重与数据包打成一个发布压缩包。"""
import os
import shutil
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STAGE = os.path.join(ROOT, "out", "release_stage")
DEST = os.path.join(ROOT, "model-on-datapack.zip")
PAPER = r"C:\Projects\mclans\000_docs\数据包内运行中文对话神经网络-compute命令与上下文数值提供器的实践.md"

if os.path.exists(STAGE):
    shutil.rmtree(STAGE)
os.makedirs(STAGE)

# 顶层文档与数据
for f in ["README.md", "corpus.txt", "weights.json"]:
    shutil.copy2(os.path.join(ROOT, f), STAGE)

# 论文
os.makedirs(os.path.join(STAGE, "docs"))
shutil.copy2(PAPER, os.path.join(STAGE, "docs"))

# 工具链
shutil.copytree(os.path.join(ROOT, "tools"), os.path.join(STAGE, "tools"))

# 数据包: 文件夹形式 + zip 形式
shutil.copytree(os.path.join(ROOT, "out", "nnchat"), os.path.join(STAGE, "nnchat"))
shutil.copy2(os.path.join(ROOT, "out", "nnchat.zip"), STAGE)

if os.path.exists(DEST):
    os.remove(DEST)
with zipfile.ZipFile(DEST, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for dp, _, fs in os.walk(STAGE):
        for f in fs:
            full = os.path.join(dp, f)
            z.write(full, os.path.relpath(full, STAGE))
shutil.rmtree(STAGE)

print("打包完成:", DEST)
print("大小: %.1f MB" % (os.path.getsize(DEST) / 1e6))
with zipfile.ZipFile(DEST) as z:
    names = z.namelist()
    print("文件数:", len(names))
    print("顶层结构:", sorted(set(n.split("/")[0] for n in names)))
