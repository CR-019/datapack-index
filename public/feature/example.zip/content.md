# 《Feature》投稿模板

> 摘要：本文是《Feature》的投稿模板，旨在为投稿者提供一个写作的格式示例。

你可以将图片放在文档同级的文件夹下，然后使用相对路径引用：

![icon](icon.png)

你可以使用vitepress支持的TIP、WARNING、DANGER和DETAIL注释块优化你的文章排版：

::: tip 提示标题
这里是提示的内容。
:::

::: warning 警告标题
这里是警告的内容。
:::

::: danger 错误标题
这里是错误的内容。
:::

::: details 折叠块
这里是被折叠的内容。
:::

当然，你也可以使用如下的替代：

> [!TIP]提示

> [!WARNING]警告

> [!DANGER]危险

香草图书馆增加了mcfunction和mcdoc的代码块语法高亮，你可以和使用其他的编程语言一样使用它们：

```mcfunction
say mcf语法高亮
```

```mcdoc
struct myStruct{
	myInt: int,
	myShort: short,
	myString: string,
}
```